;'use strict';(function(window){var gL10nData={};var gTextProp='textContent';var gLanguage='';var gMacros={};var gReadyState='loading';var gAsyncResourceLoading=true;var gDEBUG=1;function consoleLog(message){if(gDEBUG>=2){console.log('[l10n] '+message);}};function consoleWarn(message){if(gDEBUG){console.warn('[l10n] '+message);}};function getL10nResourceLinks(){return document.querySelectorAll('link[type="application/l10n"]');}
function getL10nDictionary(){var script=document.querySelector('script[type="application/l10n"]');return script?JSON.parse(script.innerHTML):null;}
function getTranslatableChildren(element){return element?element.querySelectorAll('*[data-l10n-id]'):[];}
function getL10nAttributes(element){if(!element)
return{};var l10nId=element.getAttribute('data-l10n-id');var l10nArgs=element.getAttribute('data-l10n-args');var args={};if(l10nArgs){try{args=JSON.parse(l10nArgs);}catch(e){consoleWarn('could not parse arguments for #'+l10nId);}}
return{id:l10nId,args:args};}
function fireL10nReadyEvent(){var evtObject=document.createEvent('Event');evtObject.initEvent('localized',false,false);evtObject.language=gLanguage;window.dispatchEvent(evtObject);}
function parseResource(href,lang,successCallback,failureCallback){var baseURL=href.replace(/\/[^\/]*$/,'/');function evalString(text){if(text.lastIndexOf('\\')<0)
return text;return text.replace(/\\\\/g,'\\').replace(/\\n/g,'\n').replace(/\\r/g,'\r').replace(/\\t/g,'\t').replace(/\\b/g,'\b').replace(/\\f/g,'\f').replace(/\\{/g,'{').replace(/\\}/g,'}').replace(/\\"/g,'"').replace(/\\'/g,"'");}
function parseProperties(text){var dictionary=[];var reBlank=/^\s*|\s*$/;var reComment=/^\s*#|^\s*$/;var reSection=/^\s*\[(.*)\]\s*$/;var reImport=/^\s*@import\s+url\((.*)\)\s*$/i;var reSplit=/^([^=\s]*)\s*=\s*(.+)$/;function parseRawLines(rawText,extendedSyntax){var entries=rawText.replace(reBlank,'').split(/[\r\n]+/);var currentLang='*';var genericLang=lang.replace(/-[a-z]+$/i,'');var skipLang=false;var match='';for(var i=0;i<entries.length;i++){var line=entries[i];if(reComment.test(line))
continue;if(extendedSyntax){if(reSection.test(line)){match=reSection.exec(line);currentLang=match[1];skipLang=(currentLang!=='*')&&(currentLang!==lang)&&(currentLang!==genericLang);continue;}else if(skipLang){continue;}
if(reImport.test(line)){match=reImport.exec(line);loadImport(baseURL+match[1]);}}
var tmp=line.match(reSplit);if(tmp&&tmp.length==3){dictionary[tmp[1]]=evalString(tmp[2]);}}}
function loadImport(url){loadResource(url,function(content){parseRawLines(content,false);},null,false);}
parseRawLines(text,true);return dictionary;}
function loadResource(url,onSuccess,onFailure,asynchronous){onSuccess=onSuccess||function _onSuccess(data){};onFailure=onFailure||function _onFailure(){consoleWarn(url+' not found.');};var xhr=new XMLHttpRequest();xhr.open('GET',url,asynchronous);if(xhr.overrideMimeType){xhr.overrideMimeType('text/plain; charset=utf-8');}
xhr.onreadystatechange=function(){if(xhr.readyState==4){if(xhr.status==200||xhr.status===0){onSuccess(xhr.responseText);}else{onFailure();}}};xhr.onerror=onFailure;xhr.ontimeout=onFailure;try{xhr.send(null);}catch(e){onFailure();}}
loadResource(href,function(response){var data=parseProperties(response);for(var key in data){var id,prop,index=key.lastIndexOf('.');if(index>0){id=key.substring(0,index);prop=key.substr(index+1);}else{id=key;prop=gTextProp;}
if(!gL10nData[id]){gL10nData[id]={};}
gL10nData[id][prop]=data[key];}
if(successCallback){successCallback();}},failureCallback,gAsyncResourceLoading);};function loadLocale(lang,callback){callback=callback||function _callback(){};clear();gLanguage=lang;var langLinks=getL10nResourceLinks();var langCount=langLinks.length;if(langCount==0){var dict=getL10nDictionary();if(dict&&dict.locales&&dict.default_locale){consoleLog('using the embedded JSON directory, early way out');gL10nData=dict.locales[lang]||dict.locales[dict.default_locale];callback();}else{consoleLog('no resource to load, early way out');}
fireL10nReadyEvent(lang);gReadyState='complete';return;}
var onResourceLoaded=null;var gResourceCount=0;onResourceLoaded=function(){gResourceCount++;if(gResourceCount>=langCount){callback();fireL10nReadyEvent(lang);gReadyState='complete';}};function l10nResourceLink(link){var href=link.href;var type=link.type;this.load=function(lang,callback){var applied=lang;parseResource(href,lang,callback,function(){consoleWarn(href+' not found.');applied='';});return applied;};}
for(var i=0;i<langCount;i++){var resource=new l10nResourceLink(langLinks[i]);var rv=resource.load(lang,onResourceLoaded);if(rv!=lang){consoleWarn('"'+lang+'" resource not found');gLanguage='';}}}
function clear(){gL10nData={};gLanguage='';}
function getPluralRules(lang){var locales2rules={'af':3,'ak':4,'am':4,'ar':1,'asa':3,'az':0,'be':11,'bem':3,'bez':3,'bg':3,'bh':4,'bm':0,'bn':3,'bo':0,'br':20,'brx':3,'bs':11,'ca':3,'cgg':3,'chr':3,'cs':12,'cy':17,'da':3,'de':3,'dv':3,'dz':0,'ee':3,'el':3,'en':3,'eo':3,'es':3,'et':3,'eu':3,'fa':0,'ff':5,'fi':3,'fil':4,'fo':3,'fr':5,'fur':3,'fy':3,'ga':8,'gd':24,'gl':3,'gsw':3,'gu':3,'guw':4,'gv':23,'ha':3,'haw':3,'he':2,'hi':4,'hr':11,'hu':0,'id':0,'ig':0,'ii':0,'is':3,'it':3,'iu':7,'ja':0,'jmc':3,'jv':0,'ka':0,'kab':5,'kaj':3,'kcg':3,'kde':0,'kea':0,'kk':3,'kl':3,'km':0,'kn':0,'ko':0,'ksb':3,'ksh':21,'ku':3,'kw':7,'lag':18,'lb':3,'lg':3,'ln':4,'lo':0,'lt':10,'lv':6,'mas':3,'mg':4,'mk':16,'ml':3,'mn':3,'mo':9,'mr':3,'ms':0,'mt':15,'my':0,'nah':3,'naq':7,'nb':3,'nd':3,'ne':3,'nl':3,'nn':3,'no':3,'nr':3,'nso':4,'ny':3,'nyn':3,'om':3,'or':3,'pa':3,'pap':3,'pl':13,'ps':3,'pt':3,'rm':3,'ro':9,'rof':3,'ru':11,'rwk':3,'sah':0,'saq':3,'se':7,'seh':3,'ses':0,'sg':0,'sh':11,'shi':19,'sk':12,'sl':14,'sma':7,'smi':7,'smj':7,'smn':7,'sms':7,'sn':3,'so':3,'sq':3,'sr':11,'ss':3,'ssy':3,'st':3,'sv':3,'sw':3,'syr':3,'ta':3,'te':3,'teo':3,'th':0,'ti':4,'tig':3,'tk':3,'tl':4,'tn':3,'to':0,'tr':0,'ts':3,'tzm':22,'uk':11,'ur':3,'ve':3,'vi':0,'vun':3,'wa':4,'wae':3,'wo':0,'xh':3,'xog':3,'yo':0,'zh':0,'zu':3};function isIn(n,list){return list.indexOf(n)!==-1;}
function isBetween(n,start,end){return start<=n&&n<=end;}
var pluralRules={'0':function(n){return'other';},'1':function(n){if((isBetween((n%100),3,10)))
return'few';if(n===0)
return'zero';if((isBetween((n%100),11,99)))
return'many';if(n==2)
return'two';if(n==1)
return'one';return'other';},'2':function(n){if(n!==0&&(n%10)===0)
return'many';if(n==2)
return'two';if(n==1)
return'one';return'other';},'3':function(n){if(n==1)
return'one';return'other';},'4':function(n){if((isBetween(n,0,1)))
return'one';return'other';},'5':function(n){if((isBetween(n,0,2))&&n!=2)
return'one';return'other';},'6':function(n){if(n===0)
return'zero';if((n%10)==1&&(n%100)!=11)
return'one';return'other';},'7':function(n){if(n==2)
return'two';if(n==1)
return'one';return'other';},'8':function(n){if((isBetween(n,3,6)))
return'few';if((isBetween(n,7,10)))
return'many';if(n==2)
return'two';if(n==1)
return'one';return'other';},'9':function(n){if(n===0||n!=1&&(isBetween((n%100),1,19)))
return'few';if(n==1)
return'one';return'other';},'10':function(n){if((isBetween((n%10),2,9))&&!(isBetween((n%100),11,19)))
return'few';if((n%10)==1&&!(isBetween((n%100),11,19)))
return'one';return'other';},'11':function(n){if((isBetween((n%10),2,4))&&!(isBetween((n%100),12,14)))
return'few';if((n%10)===0||(isBetween((n%10),5,9))||(isBetween((n%100),11,14)))
return'many';if((n%10)==1&&(n%100)!=11)
return'one';return'other';},'12':function(n){if((isBetween(n,2,4)))
return'few';if(n==1)
return'one';return'other';},'13':function(n){if((isBetween((n%10),2,4))&&!(isBetween((n%100),12,14)))
return'few';if(n!=1&&(isBetween((n%10),0,1))||(isBetween((n%10),5,9))||(isBetween((n%100),12,14)))
return'many';if(n==1)
return'one';return'other';},'14':function(n){if((isBetween((n%100),3,4)))
return'few';if((n%100)==2)
return'two';if((n%100)==1)
return'one';return'other';},'15':function(n){if(n===0||(isBetween((n%100),2,10)))
return'few';if((isBetween((n%100),11,19)))
return'many';if(n==1)
return'one';return'other';},'16':function(n){if((n%10)==1&&n!=11)
return'one';return'other';},'17':function(n){if(n==3)
return'few';if(n===0)
return'zero';if(n==6)
return'many';if(n==2)
return'two';if(n==1)
return'one';return'other';},'18':function(n){if(n===0)
return'zero';if((isBetween(n,0,2))&&n!==0&&n!=2)
return'one';return'other';},'19':function(n){if((isBetween(n,2,10)))
return'few';if((isBetween(n,0,1)))
return'one';return'other';},'20':function(n){if((isBetween((n%10),3,4)||((n%10)==9))&&!(isBetween((n%100),10,19)||isBetween((n%100),70,79)||isBetween((n%100),90,99)))
return'few';if((n%1000000)===0&&n!==0)
return'many';if((n%10)==2&&!isIn((n%100),[12,72,92]))
return'two';if((n%10)==1&&!isIn((n%100),[11,71,91]))
return'one';return'other';},'21':function(n){if(n===0)
return'zero';if(n==1)
return'one';return'other';},'22':function(n){if((isBetween(n,0,1))||(isBetween(n,11,99)))
return'one';return'other';},'23':function(n){if((isBetween((n%10),1,2))||(n%20)===0)
return'one';return'other';},'24':function(n){if((isBetween(n,3,10)||isBetween(n,13,19)))
return'few';if(isIn(n,[2,12]))
return'two';if(isIn(n,[1,11]))
return'one';return'other';}};var index=locales2rules[lang.replace(/-.*$/,'')];if(!(index in pluralRules)){consoleWarn('plural form unknown for ['+lang+']');return function(){return'other';};}
return pluralRules[index];}
gMacros.plural=function(str,param,key,prop){var n=parseFloat(param);if(isNaN(n))
return str;if(prop!=gTextProp)
return str;if(!gMacros._pluralRules){gMacros._pluralRules=getPluralRules(gLanguage);}
var index='['+gMacros._pluralRules(n)+']';if(n===0&&(key+'[zero]')in gL10nData){str=gL10nData[key+'[zero]'][prop];}else if(n==1&&(key+'[one]')in gL10nData){str=gL10nData[key+'[one]'][prop];}else if(n==2&&(key+'[two]')in gL10nData){str=gL10nData[key+'[two]'][prop];}else if((key+index)in gL10nData){str=gL10nData[key+index][prop];}else if((key+'[other]')in gL10nData){str=gL10nData[key+'[other]'][prop];}
return str;};function getL10nData(key,args){var data=gL10nData[key];if(!data){consoleWarn('#'+key+' is undefined.');}
var rv={};for(var prop in data){var str=data[prop];str=substIndexes(str,args,key,prop);str=substArguments(str,args,key);rv[prop]=str;}
return rv;}
function substIndexes(str,args,key,prop){var reIndex=/\{\[\s*([a-zA-Z]+)\(([a-zA-Z]+)\)\s*\]\}/;var reMatch=reIndex.exec(str);if(!reMatch||!reMatch.length)
return str;var macroName=reMatch[1];var paramName=reMatch[2];var param;if(args&&paramName in args){param=args[paramName];}else if(paramName in gL10nData){param=gL10nData[paramName];}
if(macroName in gMacros){var macro=gMacros[macroName];str=macro(str,param,key,prop);}
return str;}
function substArguments(str,args,key){var reArgs=/\{\{\s*(.+?)\s*\}\}/;var match=reArgs.exec(str);while(match){if(!match||match.length<2)
return str;var arg=match[1];var sub='';if(args&&arg in args){sub=args[arg];}else if(arg in gL10nData){sub=gL10nData[arg][gTextProp];}else{consoleLog('argument {{'+arg+'}} for #'+key+' is undefined.');return str;}
str=str.substring(0,match.index)+sub+
str.substr(match.index+match[0].length);match=reArgs.exec(str);}
return str;}
function translateElement(element){var l10n=getL10nAttributes(element);if(!l10n.id){return;}
var data=getL10nData(l10n.id,l10n.args);if(!data){consoleWarn('#'+l10n.id+' is undefined.');return;}
if(data[gTextProp]){if(element.children.length===0){element[gTextProp]=data[gTextProp];}else{var children=element.childNodes;var found=false;for(var i=0,l=children.length;i<l;i++){if(children[i].nodeType===3&&/\S/.test(children[i].nodeValue)){if(found){children[i].nodeValue='';}else{children[i].nodeValue=data[gTextProp];found=true;}}}
if(!found){var textNode=document.createTextNode(data[gTextProp]);element.insertBefore(textNode,element.firstChild);}}
delete data[gTextProp];}
for(var k in data){element[k]=data[k];}}
function translateFragment(element){element=element||document.documentElement;var children=getTranslatableChildren(element);var elementCount=children.length;for(var i=0;i<elementCount;i++){translateElement(children[i]);}
translateElement(element);}
function l10nStartup(){gReadyState='interactive';consoleLog('loading ['+navigator.language+'] resources, '+
(gAsyncResourceLoading?'asynchronously.':'synchronously.'));if(document.documentElement.lang===navigator.language){loadLocale(navigator.language);}else{loadLocale(navigator.language,translateFragment);}}
if(typeof(document)!=='undefined'){if(document.readyState==='complete'||document.readyState==='interactive'){window.setTimeout(l10nStartup);}else{document.addEventListener('DOMContentLoaded',l10nStartup);}}
if('mozSettings'in navigator&&navigator.mozSettings){navigator.mozSettings.addObserver('language.current',function(event){loadLocale(event.settingValue,translateFragment);});}
navigator.mozL10n={get:function l10n_get(key,args,fallback){var data=getL10nData(key,args)||fallback;if(data){return'textContent'in data?data.textContent:'';}
return'{{'+key+'}}';},get language(){return{get code(){return gLanguage;},set code(lang){loadLocale(lang,translateFragment);},get direction(){var rtlList=['ar','he','fa','ps','ur'];return(rtlList.indexOf(gLanguage)>=0)?'rtl':'ltr';}};},translate:translateFragment,get dictionary(){return JSON.parse(JSON.stringify(gL10nData));},get readyState(){return gReadyState;},ready:function l10n_ready(callback){if(!callback)
return;if(gReadyState=='complete'){window.setTimeout(callback);}else{window.addEventListener('localized',callback);}}};consoleLog('library loaded.');})(this);;'use strict';var MediaDB=(function(){function MediaDB(mediaType,metadataParser,options){this.mediaType=mediaType;this.metadataParser=metadataParser;if(!options)
options={};this.indexes=options.indexes||[];this.version=options.version||1;this.mimeTypes=options.mimeTypes;this.autoscan=(options.autoscan!==undefined)?options.autoscan:true;this.state=MediaDB.OPENING;this.scanning=false;this.batchHoldTime=options.batchHoldTime||100;this.batchSize=options.batchSize||0;this.dbname='MediaDB/'+this.mediaType+'/';var media=this;this.details={eventListeners:{},pendingInsertions:[],pendingDeletions:[],whenDoneProcessing:[],pendingCreateNotifications:[],pendingDeleteNotifications:[],pendingNotificationTimer:null,newestFileModTime:0};if(!this.metadataParser){this.metadataParser=function(file,callback){setTimeout(function(){callback({});},0);};}
var openRequest=indexedDB.open(this.dbname,this.version*MediaDB.VERSION);openRequest.onerror=function(e){console.error('MediaDB():',openRequest.error.name);};openRequest.onblocked=function(e){console.error('indexedDB.open() is blocked in MediaDB()');};openRequest.onupgradeneeded=function(e){var db=openRequest.result;var existingStoreNames=db.objectStoreNames;for(var i=0;i<existingStoreNames.length;i++){db.deleteObjectStore(existingStoreNames[i]);}
var filestore=db.createObjectStore('files',{keyPath:'name'});filestore.createIndex('date','date');media.indexes.forEach(function(indexName){if(indexName==='name'||indexName==='date')
return;filestore.createIndex(indexName,indexName);});};openRequest.onsuccess=function(e){media.db=openRequest.result;media.db.onerror=function(event){console.error('MediaDB: ',event.target.error&&event.target.error.name);};var cursorRequest=media.db.transaction('files','readonly').objectStore('files').index('date').openCursor(null,'prev');cursorRequest.onerror=function(){console.error('MediaDB initialization error',cursorRequest.error);};cursorRequest.onsuccess=function(){var cursor=cursorRequest.result;if(cursor){media.details.newestFileModTime=cursor.value.date;}
else{media.details.newestFileModTime=0;}
initDeviceStorage();};};function initDeviceStorage(){var details=media.details;media.storage=navigator.getDeviceStorage(mediaType);details.storages=navigator.getDeviceStorages(mediaType);details.availability={};getStorageAvailability();function getStorageAvailability(){var next=0;getNextAvailability();function getNextAvailability(){if(next>=details.storages.length){setupHandlers();return;}
var s=details.storages[next++];var name=s.storageName;var req=s.available();req.onsuccess=function(e){details.availability[name]=req.result;getNextAvailability();};req.onerror=function(e){details.availability[name]='unavailable';getNextAvailability();};}}
function setupHandlers(){for(var i=0;i<details.storages.length;i++)
details.storages[i].addEventListener('change',changeHandler);details.dsEventListener=changeHandler;sendInitialEvent();}
function sendInitialEvent(){var state=getState(details.availability);changeState(media,state);if(media.autoscan)
scan(media);}
function getState(availability){var n=0;var a=0;var u=0;var s=0;for(var name in availability){n++;switch(availability[name]){case'available':a++;break;case'unavailable':u++;break;case'shared':s++;break;}}
if(s>0)
return MediaDB.UNMOUNTED;if(u===n)
return MediaDB.NOCARD;return MediaDB.READY;}
function changeHandler(e){switch(e.reason){case'modified':case'deleted':fileChangeHandler(e);return;case'available':case'unavailable':case'shared':volumeChangeHandler(e);return;default:return;}}
function volumeChangeHandler(e){var storageName=e.target.storageName;if(details.availability[storageName]===e.reason)
return;var oldState=media.state;details.availability[storageName]=e.reason;var newState=getState(details.availability);if(newState!==oldState){changeState(media,newState);if(newState===MediaDB.READY){if(media.autoscan)
scan(media);}
else{endscan(media);}}
else if(newState===MediaDB.READY){if(e.reason==='available'){dispatchEvent(media,'ready');if(media.autoscan)
scan(media);}
else if(e.reason==='unavailable'){dispatchEvent(media,'cardremoved');deleteAllFiles(storageName);}}}
function fileChangeHandler(e){var filename=e.path;if(ignoreName(filename))
return;if(e.reason==='modified')
insertRecord(media,filename);else
deleteRecord(media,filename);}
function deleteAllFiles(storageName){var storagePrefix=storageName?'/'+storageName+'/':'';var store=media.db.transaction('files').objectStore('files');var cursorRequest=store.openCursor();cursorRequest.onsuccess=function(){var cursor=cursorRequest.result;if(cursor){if(cursor.value.name.startsWith(storagePrefix)){deleteRecord(media,cursor.value.name);}
cursor.continue();}};}}}
MediaDB.prototype={close:function close(){this.db.close();for(var i=0;i<this.details.storages.length;i++){var s=this.details.storages[i];s.removeEventListener('change',this.details.dsEventListener);}
changeState(this,MediaDB.CLOSED);},addEventListener:function addEventListener(type,listener){if(!this.details.eventListeners.hasOwnProperty(type))
this.details.eventListeners[type]=[];var listeners=this.details.eventListeners[type];if(listeners.indexOf(listener)!==-1)
return;listeners.push(listener);},removeEventListener:function removeEventListener(type,listener){if(!this.details.eventListeners.hasOwnProperty(type))
return;var listeners=this.details.eventListeners[type];var position=listeners.indexOf(listener);if(position===-1)
return;listeners.splice(position,1);},getFile:function getFile(filename,callback,errback){if(this.state!==MediaDB.READY)
throw Error('MediaDB is not ready. State: '+this.state);var getRequest=this.storage.get(filename);getRequest.onsuccess=function(){callback(getRequest.result);};getRequest.onerror=function(){var errmsg=getRequest.error&&getRequest.error.name;if(errback)
errback(errmsg);else
console.error('MediaDB.getFile:',errmsg);};},deleteFile:function deleteFile(filename){if(this.state!==MediaDB.READY)
throw Error('MediaDB is not ready. State: '+this.state);this.storage.delete(filename).onerror=function(e){console.error('MediaDB.deleteFile(): Failed to delete',filename,'from DeviceStorage:',e.target.error);};},addFile:function addFile(filename,file){if(this.state!==MediaDB.READY)
throw Error('MediaDB is not ready. State: '+this.state);var media=this;var deletereq=media.storage.delete(filename);deletereq.onsuccess=deletereq.onerror=save;function save(){var request=media.storage.addNamed(file,filename);request.onerror=function(){console.error('MediaDB: Failed to store',filename,'in DeviceStorage:',request.error);};}},updateMetadata:function(filename,metadata,callback){if(this.state===MediaDB.OPENING)
throw Error('MediaDB is not ready. State: '+this.state);var media=this;var read=media.db.transaction('files','readonly').objectStore('files').get(filename);read.onerror=function(){console.error('MediaDB.updateMetadata called with unknown filename');};read.onsuccess=function(){var fileinfo=read.result;Object.keys(metadata).forEach(function(key){fileinfo.metadata[key]=metadata[key];});var write=media.db.transaction('files','readwrite').objectStore('files').put(fileinfo);write.onerror=function(){console.error('MediaDB.updateMetadata: database write failed',write.error&&write.error.name);};if(callback){write.onsuccess=function(){callback();};}};},count:function(key,range,callback){if(this.state!==MediaDB.READY)
throw Error('MediaDB is not ready. State: '+this.state);if(arguments.length===1){callback=key;range=undefined;key=undefined;}
else if(arguments.length===2){callback=range;range=key;key=undefined;}
var store=this.db.transaction('files').objectStore('files');if(key&&key!=='name')
store=store.index(key);var countRequest=store.count(range||null);countRequest.onerror=function(){console.error('MediaDB.count() failed with',countRequest.error);};countRequest.onsuccess=function(e){callback(e.target.result);};},enumerate:function enumerate(key,range,direction,callback){if(this.state!==MediaDB.READY)
throw Error('MediaDB is not ready. State: '+this.state);var handle={state:'enumerating'};if(arguments.length===1){callback=key;key=undefined;}
else if(arguments.length===2){callback=range;range=undefined;}
else if(arguments.length===3){callback=direction;direction=undefined;}
var store=this.db.transaction('files').objectStore('files');if(key&&key!=='name')
store=store.index(key);var cursorRequest=store.openCursor(range||null,direction||'next');cursorRequest.onerror=function(){console.error('MediaDB.enumerate() failed with',cursorRequest.error);handle.state='error';};cursorRequest.onsuccess=function(){if(handle.state==='cancelling'){handle.state='cancelled';return;}
var cursor=cursorRequest.result;if(cursor){try{if(!cursor.value.fail)
callback(cursor.value);}
catch(e){console.warn('MediaDB.enumerate(): callback threw',e);}
cursor.continue();}
else{handle.state='complete';callback(null);}};return handle;},enumerateAll:function enumerateAll(key,range,direction,callback){var batch=[];if(arguments.length===1){callback=key;key=undefined;}
else if(arguments.length===2){callback=range;range=undefined;}
else if(arguments.length===3){callback=direction;direction=undefined;}
return this.enumerate(key,range,direction,function(fileinfo){if(fileinfo!==null)
batch.push(fileinfo);else
callback(batch);});},cancelEnumeration:function cancelEnumeration(handle){if(handle.state==='enumerating')
handle.state='cancelling';},getAll:function getAll(callback){if(this.state!==MediaDB.READY)
throw Error('MediaDB is not ready. State: '+this.state);var store=this.db.transaction('files').objectStore('files');var request=store.mozGetAll();request.onerror=function(){console.error('MediaDB.getAll() failed with',request.error);};request.onsuccess=function(){var all=request.result;var good=all.filter(function(fileinfo){return!fileinfo.fail;});callback(good);};},scan:function(){scan(this);},freeSpace:function freeSpace(callback){if(this.state!==MediaDB.READY)
throw Error('MediaDB is not ready. State: '+this.state);var freereq=this.storage.freeSpace();freereq.onsuccess=function(){callback(freereq.result);};}};MediaDB.VERSION=2;MediaDB.OPENING='opening';MediaDB.READY='ready';MediaDB.NOCARD='nocard';MediaDB.UNMOUNTED='unmounted';MediaDB.CLOSED='closed';function ignore(media,file){if(ignoreName(file.name))
return true;if(media.mimeTypes&&media.mimeTypes.indexOf(file.type)===-1)
return true;return false;}
function ignoreName(filename){return(filename[0]==='.'||filename.indexOf('/.')!==-1);}
function scan(media){media.scanning=true;dispatchEvent(media,'scanstart');quickScan(media.details.newestFileModTime);function quickScan(timestamp){var cursor;if(timestamp>0){media.details.firstscan=false;cursor=media.storage.enumerate('',{since:new Date(timestamp+1)});}
else{media.details.firstscan=true;media.details.records=[];cursor=media.storage.enumerate('');}
cursor.onsuccess=function(){if(!media.scanning)
return;var file=cursor.result;if(file){if(!ignore(media,file))
insertRecord(media,file);cursor.continue();}
else{whenDoneProcessing(media,function(){sendNotifications(media);if(media.details.firstscan){endscan(media);}
else{fullScan();}});}};cursor.onerror=function(){console.warning('Error while scanning',cursor.error);endscan(media);};}
function fullScan(){if(media.state!==MediaDB.READY){endscan(media);return;}
var dsfiles=[];var cursor=media.storage.enumerate('');cursor.onsuccess=function(){if(!media.scanning)
return;var file=cursor.result;if(file){if(!ignore(media,file)){dsfiles.push(file);}
cursor.continue();}
else{getDBFiles();}};cursor.onerror=function(){console.warning('Error while scanning',cursor.error);endscan(media);};function getDBFiles(){var store=media.db.transaction('files').objectStore('files');var getAllRequest=store.mozGetAll();getAllRequest.onsuccess=function(){if(!media.scanning)
return;var dbfiles=getAllRequest.result;compareLists(dbfiles,dsfiles);};}
function compareLists(dbfiles,dsfiles){dsfiles.sort(function(a,b){if(a.name<b.name)
return-1;else
return 1;});var dsindex=0,dbindex=0;while(true){var dsfile;if(dsindex<dsfiles.length)
dsfile=dsfiles[dsindex];else
dsfile=null;var dbfile;if(dbindex<dbfiles.length)
dbfile=dbfiles[dbindex];else
dbfile=null;if(dsfile===null&&dbfile===null)
break;if(dbfile===null){insertRecord(media,dsfile);dsindex++;continue;}
if(dsfile===null){deleteRecord(media,dbfile.name);dbindex++;continue;}
if(dsfile.name===dbfile.name){var lastModified=dsfile.lastModifiedDate;if((lastModified&&lastModified.getTime()!==dbfile.date)||dsfile.size!==dbfile.size){deleteRecord(media,dbfile.name);insertRecord(media,dsfile);}
dsindex++;dbindex++;continue;}
if(dsfile.name<dbfile.name){insertRecord(media,dsfile);dsindex++;continue;}
if(dsfile.name>dbfile.name){deleteRecord(media,dbfile.name);dbindex++;continue;}
console.error('Assertion failed');}
insertRecord(media,null);}}}
function endscan(media){if(media.scanning){media.scanning=false;dispatchEvent(media,'scanend');}}
function insertRecord(media,fileOrName){var details=media.details;details.pendingInsertions.push(fileOrName);if(details.processingQueue)
return;processQueue(media);}
function deleteRecord(media,filename){var details=media.details;details.pendingDeletions.push(filename);if(details.processingQueue)
return;processQueue(media);}
function whenDoneProcessing(media,f){var details=media.details;if(details.processingQueue)
details.whenDoneProcessing.push(f);else
f();}
function processQueue(media){var details=media.details;details.processingQueue=true;next();function next(){if(details.pendingDeletions.length>0){deleteFiles();}
else if(details.pendingInsertions.length>0){insertFile(details.pendingInsertions.shift());}
else{details.processingQueue=false;if(details.whenDoneProcessing.length>0){var functions=details.whenDoneProcessing;details.whenDoneProcessing=[];functions.forEach(function(f){f();});}}}
function deleteFiles(){var transaction=media.db.transaction('files','readwrite');var store=transaction.objectStore('files');deleteNextFile();function deleteNextFile(){if(details.pendingDeletions.length===0){next();return;}
var filename=details.pendingDeletions.shift();var request=store.delete(filename);request.onerror=function(){console.warn('MediaDB: Unknown file in deleteRecord:',filename,getreq.error);deleteNextFile();};request.onsuccess=function(){queueDeleteNotification(media,filename);deleteNextFile();};}}
function insertFile(f){if(f===null){sendNotifications(media);endscan(media);next();return;}
if(typeof f==='string'){var getreq=media.storage.get(f);getreq.onerror=function(){console.warn('MediaDB: Unknown file in insertRecord:',f,getreq.error);next();};getreq.onsuccess=function(){if(media.mimeTypes&&ignore(media,getreq.result))
next();else
parseMetadata(getreq.result,f);};}
else{parseMetadata(f,f.name);}}
function parseMetadata(file,filename){if(!file.lastModifiedDate){console.warn('MediaDB: parseMetadata: no lastModifiedDate for',filename,'using Date.now() until #793955 is fixed');}
var fileinfo={name:filename,type:file.type,size:file.size,date:file.lastModifiedDate?file.lastModifiedDate.getTime():Date.now()};if(fileinfo.date>details.newestFileModTime)
details.newestFileModTime=fileinfo.date;media.metadataParser(file,gotMetadata,metadataError);function metadataError(e){console.warn('MediaDB: error parsing metadata for',filename,':',e);fileinfo.fail=true;storeRecord(fileinfo);}
function gotMetadata(metadata){fileinfo.metadata=metadata;storeRecord(fileinfo);}}
function storeRecord(fileinfo){if(media.details.firstscan){media.details.records.push(fileinfo);if(!fileinfo.fail){queueCreateNotification(media,fileinfo);}
next();}
else{var transaction=media.db.transaction('files','readwrite');var store=transaction.objectStore('files');var request=store.add(fileinfo);request.onsuccess=function(){if(!fileinfo.fail)
queueCreateNotification(media,fileinfo);next();};request.onerror=function(event){if(request.error.name==='ConstraintError'){event.stopPropagation();event.preventDefault();var putrequest=store.put(fileinfo);putrequest.onsuccess=function(){queueDeleteNotification(media,fileinfo.name);if(!fileinfo.fail)
queueCreateNotification(media,fileinfo);next();};putrequest.onerror=function(){console.error('MediaDB: unexpected ConstraintError','in insertRecord for file:',fileinfo.name);next();};}
else{console.error('MediaDB: unexpected error in insertRecord:',request.error,'for file:',fileinfo.name);next();}};}}}
function queueCreateNotification(media,fileinfo){var creates=media.details.pendingCreateNotifications;creates.push(fileinfo);if(media.batchSize&&creates.length>=media.batchSize)
sendNotifications(media);else
resetNotificationTimer(media);}
function queueDeleteNotification(media,filename){var deletes=media.details.pendingDeleteNotifications;deletes.push(filename);if(media.batchSize&&deletes.length>=media.batchSize)
sendNotifications(media);else
resetNotificationTimer(media);}
function resetNotificationTimer(media){var details=media.details;if(details.pendingNotificationTimer)
clearTimeout(details.pendingNotificationTimer);details.pendingNotificationTimer=setTimeout(function(){sendNotifications(media);},media.batchHoldTime);}
function sendNotifications(media){var details=media.details;if(details.pendingNotificationTimer){clearTimeout(details.pendingNotificationTimer);details.pendingNotificationTimer=null;}
if(details.pendingDeleteNotifications.length>0){var deletions=details.pendingDeleteNotifications;details.pendingDeleteNotifications=[];dispatchEvent(media,'deleted',deletions);}
if(details.pendingCreateNotifications.length>0){if(details.firstscan&&details.records.length>0){var transaction=media.db.transaction('files','readwrite');var store=transaction.objectStore('files');for(var i=0;i<details.records.length;i++)
store.add(details.records[i]);details.records.length=0;}
var creations=details.pendingCreateNotifications;details.pendingCreateNotifications=[];dispatchEvent(media,'created',creations);}}
function dispatchEvent(media,type,detail){var handler=media['on'+type];var listeners=media.details.eventListeners[type];if(!handler&&(!listeners||listeners.length==0))
return;var event={type:type,target:media,currentTarget:media,timestamp:Date.now(),detail:detail};if(typeof handler==='function'){try{handler.call(media,event);}
catch(e){console.warn('MediaDB: ','on'+type,'event handler threw',e);}}
if(!listeners)
return;for(var i=0;i<listeners.length;i++){try{var listener=listeners[i];if(typeof listener==='function'){listener.call(media,event);}
else{listener.handleEvent(event);}}
catch(e){console.warn('MediaDB: ',type,'event listener threw',e);}}}
function changeState(media,state){if(media.state!==state){media.state=state;if(state===MediaDB.READY)
dispatchEvent(media,'ready');else
dispatchEvent(media,'unavailable',state);}}
return MediaDB;}());;'use strict';var BlobView=(function(){function fail(msg){throw Error(msg);}
function BlobView(blob,sliceOffset,sliceLength,slice,viewOffset,viewLength,littleEndian)
{this.blob=blob;this.sliceOffset=sliceOffset;this.sliceLength=sliceLength;this.slice=slice;this.viewOffset=viewOffset;this.viewLength=viewLength;this.littleEndian=littleEndian;this.view=new DataView(slice,viewOffset,viewLength);this.buffer=slice;this.byteLength=viewLength;this.byteOffset=viewOffset;this.index=0;}
BlobView.get=function(blob,offset,length,callback,littleEndian){if(offset<0)
fail('negative offset');if(length<0)
fail('negative length');if(offset>blob.size)
fail('offset larger than blob size');if(offset+length>blob.size)
length=blob.size-offset;var slice=blob.slice(offset,offset+length);var reader=new FileReader();reader.readAsArrayBuffer(slice);reader.onloadend=function(){var result=null;if(reader.result){result=new BlobView(blob,offset,length,reader.result,0,length,littleEndian||false);}
callback(result,reader.error);};};BlobView.prototype={constructor:BlobView,getMore:function(offset,length,callback){if(offset>=this.sliceOffset&&offset+length<=this.sliceOffset+this.sliceLength){callback(new BlobView(this.blob,this.sliceOffset,this.sliceLength,this.slice,offset-this.sliceOffset,length,this.littleEndian));}
else{BlobView.get(this.blob,offset,length,callback,this.littleEndian);}},littleEndian:function(){this.littleEndian=true;},bigEndian:function(){this.littleEndian=false;},getUint8:function(offset){return this.view.getUint8(offset);},getInt8:function(offset){return this.view.getInt8(offset);},getUint16:function(offset,le){return this.view.getUint16(offset,le!==undefined?le:this.littleEndian);},getInt16:function(offset,le){return this.view.getInt16(offset,le!==undefined?le:this.littleEndian);},getUint32:function(offset,le){return this.view.getUint32(offset,le!==undefined?le:this.littleEndian);},getInt32:function(offset,le){return this.view.getInt32(offset,le!==undefined?le:this.littleEndian);},getFloat32:function(offset,le){return this.view.getFloat32(offset,le!==undefined?le:this.littleEndian);},getFloat64:function(offset,le){return this.view.getFloat64(offset,le!==undefined?le:this.littleEndian);},readByte:function(){return this.view.getInt8(this.index++);},readUnsignedByte:function(){return this.view.getUint8(this.index++);},readShort:function(le){var val=this.view.getInt16(this.index,le!==undefined?le:this.littleEndian);this.index+=2;return val;},readUnsignedShort:function(le){var val=this.view.getUint16(this.index,le!==undefined?le:this.littleEndian);this.index+=2;return val;},readInt:function(le){var val=this.view.getInt32(this.index,le!==undefined?le:this.littleEndian);this.index+=4;return val;},readUnsignedInt:function(le){var val=this.view.getUint32(this.index,le!==undefined?le:this.littleEndian);this.index+=4;return val;},readFloat:function(le){var val=this.view.getFloat32(this.index,le!==undefined?le:this.littleEndian);this.index+=4;return val;},readDouble:function(le){var val=this.view.getFloat64(this.index,le!==undefined?le:this.littleEndian);this.index+=8;return val;},tell:function(){return this.index;},seek:function(index){if(index<0)
fail('negative index');if(index>=this.byteLength)
fail('index greater than buffer size');this.index=index;},advance:function(n){var index=this.index+n;if(index<0)
fail('advance past beginning of buffer');if(index>=this.byteLength)
fail('advance past end of buffer');this.index=index;},getUnsignedByteArray:function(offset,n){return new Uint8Array(this.buffer,offset+this.viewOffset,n);},readUnsignedByteArray:function(n){var val=new Uint8Array(this.buffer,this.index+this.viewOffset,n);this.index+=n;return val;},getBit:function(offset,bit){var byte=this.view.getUint8(offset);return(byte&(1<<bit))!==0;},getUint24:function(offset,le){var b1,b2,b3;if(le!==undefined?le:this.littleEndian){b1=this.view.getUint8(offset);b2=this.view.getUint8(offset+1);b3=this.view.getUint8(offset+2);}
else{b3=this.view.getUint8(offset);b2=this.view.getUint8(offset+1);b1=this.view.getUint8(offset+2);}
return(b3<<16)+(b2<<8)+b1;},readUint24:function(le){var value=this.getUint24(this.index,le);this.index+=3;return value;},getASCIIText:function(offset,len){var bytes=new Uint8Array(this.buffer,offset+this.viewOffset,len);return String.fromCharCode.apply(String,bytes);},readASCIIText:function(len){var bytes=new Uint8Array(this.buffer,this.index+this.viewOffset,len);this.index+=len;return String.fromCharCode.apply(String,bytes);},getUTF8Text:function(offset,len){function fail(){throw new Error('Illegal UTF-8');}
var pos=offset;var end=offset+len;var charcode;var s='';var b1,b2,b3,b4;while(pos<end){var b1=this.view.getUint8(pos);if(b1<128){s+=String.fromCharCode(b1);pos+=1;}
else if(b1<194){fail();}
else if(b1<224){if(pos+1>=end)
fail();b2=this.view.getUint8(pos+1);if(b2<128||b2>191)
fail();charcode=((b1&0x1f)<<6)+(b2&0x3f);s+=String.fromCharCode(charcode);pos+=2;}
else if(b1<240){if(pos+3>=end)
fail();b2=this.view.getUint8(pos+1);if(b2<128||b2>191)
fail();b3=this.view.getUint8(pos+2);if(b3<128||b3>191)
fail();charcode=((b1&0x0f)<<12)+((b2&0x3f)<<6)+(b3&0x3f);s+=String.fromCharCode(charcode);pos+=3;}
else if(b1<245){if(pos+3>=end)
fail();b2=this.view.getUint8(pos+1);if(b2<128||b2>191)
fail();b3=this.view.getUint8(pos+2);if(b3<128||b3>191)
fail();b4=this.view.getUint8(pos+3);if(b4<128||b4>191)
fail();charcode=((b1&0x07)<<18)+
((b2&0x3f)<<12)+
((b3&0x3f)<<6)+
(b4&0x3f);charcode-=0x10000;s+=String.fromCharCode(0xd800+((charcode&0x0FFC00)>>>10));s+=String.fromCharCode(0xdc00+(charcode&0x0003FF));pos+=4;}
else{fail();}}
return s;},readUTF8Text:function(len){try{return this.getUTF8Text(this.index,len);}
finally{this.index+=len;}},getID3Uint28BE:function(offset){var b1=this.view.getUint8(offset)&0x7f;var b2=this.view.getUint8(offset+1)&0x7f;var b3=this.view.getUint8(offset+2)&0x7f;var b4=this.view.getUint8(offset+3)&0x7f;return(b1<<21)|(b2<<14)|(b3<<7)|b4;},readID3Uint28BE:function(){var value=this.getID3Uint28BE(this.index);this.index+=4;return value;},readNullTerminatedLatin1Text:function(size){var s='';for(var i=0;i<size;i++){var charcode=this.view.getUint8(this.index+i);if(charcode===0){i++;break;}
s+=String.fromCharCode(charcode);}
this.index+=i;return s;},readNullTerminatedUTF8Text:function(size){for(var len=0;len<size;len++){if(this.view.getUint8(this.index+len)===0)
break;}
var s=this.readUTF8Text(len);if(len<size)
this.advance(1);return s;},readNullTerminatedUTF16Text:function(size,le){if(le==null){var BOM=this.readUnsignedShort();size-=2;if(BOM===0xFEFF)
le=false;else
le=true;}
var s='';for(var i=0;i<size;i+=2){var charcode=this.getUint16(this.index+i,le);if(charcode===0){i+=2;break;}
s+=String.fromCharCode(charcode);}
this.index+=i;return s;}};return{get:BlobView.get};}());;'use strict';function getVideoRotation(blob,rotationCallback){function MP4Parser(blob,handlers){BlobView.get(blob,0,Math.min(1024,blob.size),function(data,error){if(data.byteLength<=8||data.getASCIIText(4,4)!=='ftyp'){handlers.errorHandler('not an MP4 file');return;}
parseAtom(data);});function parseAtom(data){var offset=data.sliceOffset+data.viewOffset;var size=data.readUnsignedInt();var type=data.readASCIIText(4);var contentOffset=8;if(size===0){size=blob.size-offset;}
else if(size===1){size=data.readUnsignedInt()*4294967296+data.readUnsignedInt();contentOffset=16;}
var handler=handlers[type]||handlers.defaultHandler;if(typeof handler==='function'){data.getMore(data.sliceOffset+data.viewOffset,size,function(atom){var rv=handler(atom);if(rv!=='done'){parseAtomAt(data,offset+size);}});}
else if(handler==='children'){var skip=(type==='meta')?4:0;parseAtomAt(data,offset+contentOffset+skip);}
else if(handler==='skip'||!handler){parseAtomAt(data,offset+size);}
else if(handler==='done'){return;}}
function parseAtomAt(data,offset){if(offset>=blob.size){if(handlers.eofHandler)
handlers.eofHandler();return;}
else{data.getMore(offset,16,parseAtom);}}}
MP4Parser(blob,{errorHandler:function(msg){rotationCallback(msg);},eofHandler:function(){rotationCallback(null);},defaultHandler:'skip',moov:'children',trak:'children',tkhd:function(data){data.advance(48);var a=data.readUnsignedInt();var b=data.readUnsignedInt();data.advance(4);var c=data.readUnsignedInt();var d=data.readUnsignedInt();if(a===0&&d===0){if(b===0x00010000&&c===0xFFFF0000)
rotationCallback(90);else if(b===0xFFFF0000&&c===0x00010000)
rotationCallback(270);else
rotationCallback('unexpected rotation matrix');}
else if(b===0&&c===0){if(a===0x00010000&&d===0x00010000)
rotationCallback(0);else if(a===0xFFFF0000&&d===0xFFFF0000)
rotationCallback(180);else
rotationCallback('unexpected rotation matrix');}
else{rotationCallback('unexpected rotation matrix');}
return'done';}});};'use strict';(function(){if(MouseEventShim)
return;try{document.createEvent('TouchEvent');}catch(e){return;}
var starttouch;var target;var emitclick;window.addEventListener('mousedown',discardEvent,true);window.addEventListener('mouseup',discardEvent,true);window.addEventListener('mousemove',discardEvent,true);window.addEventListener('click',discardEvent,true);function discardEvent(e){if(e.isTrusted){e.stopImmediatePropagation();if(e.type==='click')
e.preventDefault();}}
window.addEventListener('touchstart',handleTouchStart);window.addEventListener('touchmove',handleTouchMove);window.addEventListener('touchend',handleTouchEnd);window.addEventListener('touchcancel',handleTouchEnd);function handleTouchStart(e){if(starttouch)
return;if(e.defaultPrevented)
return;try{e.changedTouches[0].target.ownerDocument;}
catch(e){return;}
starttouch=e.changedTouches[0];target=starttouch.target;emitclick=true;emitEvent('mousemove',target,starttouch);var result=emitEvent('mousedown',target,starttouch);if(!result){e.preventDefault();emitclick=false;}}
function handleTouchEnd(e){if(!starttouch)
return;if(MouseEventShim.capturing){MouseEventShim.capturing=false;MouseEventShim.captureTarget=null;}
for(var i=0;i<e.changedTouches.length;i++){var touch=e.changedTouches[i];if(touch.identifier!==starttouch.identifier)
continue;emitEvent('mouseup',target,touch);if(emitclick)
emitEvent('click',starttouch.target,touch);starttouch=null;return;}}
function handleTouchMove(e){if(!starttouch)
return;for(var i=0;i<e.changedTouches.length;i++){var touch=e.changedTouches[i];if(touch.identifier!==starttouch.identifier)
continue;if(e.defaultPrevented)
return;var dx=Math.abs(touch.screenX-starttouch.screenX);var dy=Math.abs(touch.screenY-starttouch.screenY);if(dx>MouseEventShim.dragThresholdX||dy>MouseEventShim.dragThresholdY){emitclick=false;}
var tracking=MouseEventShim.trackMouseMoves&&!MouseEventShim.capturing;if(tracking){var oldtarget=target;var newtarget=document.elementFromPoint(touch.clientX,touch.clientY);if(newtarget===null){newtarget=oldtarget;}
if(newtarget!==oldtarget){leave(oldtarget,newtarget,touch);target=newtarget;}}
else if(MouseEventShim.captureTarget){target=MouseEventShim.captureTarget;}
emitEvent('mousemove',target,touch);if(tracking&&newtarget!==oldtarget){enter(newtarget,oldtarget,touch);}}}
function contains(a,b){return(a.compareDocumentPosition(b)&16)!==0;}
function leave(oldtarget,newtarget,touch){emitEvent('mouseout',oldtarget,touch,newtarget);for(var e=oldtarget;!contains(e,newtarget);e=e.parentNode){emitEvent('mouseleave',e,touch,newtarget);}}
function enter(newtarget,oldtarget,touch){emitEvent('mouseover',newtarget,touch,oldtarget);for(var e=newtarget;!contains(e,oldtarget);e=e.parentNode){emitEvent('mouseenter',e,touch,oldtarget);}}
function emitEvent(type,target,touch,relatedTarget){var synthetic=document.createEvent('MouseEvents');var bubbles=(type!=='mouseenter'&&type!=='mouseleave');var count=(type==='mousedown'||type==='mouseup'||type==='click')?1:0;synthetic.initMouseEvent(type,bubbles,true,window,count,touch.screenX,touch.screenY,touch.clientX,touch.clientY,false,false,false,false,0,relatedTarget||null);try{return target.dispatchEvent(synthetic);}
catch(e){console.warn('Exception calling dispatchEvent',type,e);return true;}}}());var MouseEventShim={getEventTimestamp:function(e){if(e.isTrusted)
return e.timeStamp;else
return e.timeStamp/1000;},trackMouseMoves:true,setCapture:function(target){this.capturing=true;if(target)
this.captureTarget=target;},capturing:false,dragThresholdX:25,dragThresholdY:25};;var metadataQueue=[];var processingQueue=false;var stopParsingMetadataCallback=null;function addToMetadataQueue(fileinfo){metadataQueue.push(fileinfo);startParsingMetadata();}
function startParsingMetadata(){if(processingQueue||metadataQueue.length===0)
return;if(document.mozHidden||playerShowing){return;}
processingQueue=true;showThrobber();processFirstQueuedItem();}
function stopParsingMetadata(callback){if(!processingQueue){if(callback)
callback();return;}
stopParsingMetadataCallback=callback||true;}
function processFirstQueuedItem(){if(stopParsingMetadataCallback){var callback=stopParsingMetadataCallback;stopParsingMetadataCallback=null;processingQueue=false;hideThrobber();if(callback!==true)
callback();return;}
if(metadataQueue.length===0){processingQueue=false;hideThrobber();return;}
var fileinfo=metadataQueue.shift();videodb.getFile(fileinfo.name,function(file){getMetadata(file,function(metadata){fileinfo.metadata=metadata;videodb.updateMetadata(fileinfo.name,metadata);if(metadata.isVideo)
addVideo(fileinfo);setTimeout(processFirstQueuedItem);});});}
function getMetadata(videofile,callback){var offscreenVideo=document.createElement('video');var metadata={};if(!offscreenVideo.canPlayType(videofile.type)){metadata.isVideo=false;callback(metadata);return;}
var url=URL.createObjectURL(videofile);offscreenVideo.preload='metadata';offscreenVideo.src=url;offscreenVideo.onerror=function(e){console.error("Can't play video",videofile.name,e);metadata.isVideo=false;unload();callback(metadata);};offscreenVideo.onloadedmetadata=function(){if(!offscreenVideo.videoWidth){metadata.isVideo=false;unload();callback(metadata);return;}
metadata.isVideo=true;metadata.title=fileNameToVideoName(videofile.name);metadata.duration=offscreenVideo.duration;metadata.width=offscreenVideo.videoWidth;metadata.height=offscreenVideo.videoHeight;if(/.3gp$/.test(videofile.name)){getVideoRotation(videofile,function(rotation){if(typeof rotation==='number')
metadata.rotation=rotation;else if(typeof rotation==='string')
console.warn('Video rotation:',rotation);createThumbnail();});}else{metadata.rotation=0;createThumbnail();}};function createThumbnail(){offscreenVideo.currentTime=Math.min(5,offscreenVideo.duration/10);var failed=false;var timeout=setTimeout(fail,10000);offscreenVideo.onerror=fail;function fail(){console.warn('Seek failed while creating thumbnail for',videofile.name,'. Ignoring corrupt file.');failed=true;clearTimeout(timeout);offscreenVideo.onerror=null;metadata.isVideo=false;unload();callback(metadata);}
offscreenVideo.onseeked=function(){if(failed)
return;clearTimeout(timeout);captureFrame(offscreenVideo,metadata,function(poster){if(poster===null){fail();}
else{metadata.poster=poster;unload();callback(metadata);}});};}
function unload(){URL.revokeObjectURL(offscreenVideo.src);offscreenVideo.removeAttribute('src');offscreenVideo.load();}
function fileNameToVideoName(filename){filename=filename.split('/').pop().replace(/\.(webm|ogv|mp4|3gp)$/,'').replace(/[_\.]/g,' ');return filename.charAt(0).toUpperCase()+filename.slice(1);}}
function captureFrame(player,metadata,callback){try{var canvas=document.createElement('canvas');var ctx=canvas.getContext('2d');canvas.width=THUMBNAIL_WIDTH;canvas.height=THUMBNAIL_HEIGHT;var vw=player.videoWidth,vh=player.videoHeight;var tw,th;switch(metadata.rotation){case 90:ctx.translate(THUMBNAIL_WIDTH,0);ctx.rotate(Math.PI/2);tw=THUMBNAIL_HEIGHT;th=THUMBNAIL_WIDTH;break;case 180:ctx.translate(THUMBNAIL_WIDTH,THUMBNAIL_HEIGHT);ctx.rotate(Math.PI);tw=THUMBNAIL_WIDTH;th=THUMBNAIL_HEIGHT;break;case 270:ctx.translate(0,THUMBNAIL_HEIGHT);ctx.rotate(-Math.PI/2);tw=THUMBNAIL_HEIGHT;th=THUMBNAIL_WIDTH;break;default:tw=THUMBNAIL_WIDTH;th=THUMBNAIL_HEIGHT;break;}
var scale=Math.min(vw/tw,vh/th);var w=tw*scale,h=th*scale;var x=(vw-w)/2,y=(vh-h)/2;ctx.drawImage(player,x,y,w,h,0,0,tw,th);canvas.toBlob(callback,'image/jpeg');}
catch(e){console.error('Exception in captureFrame:',e,e.stack);callback(null);}};function initDB(){videodb=new MediaDB('videos');videodb.onunavailable=function(event){storageState=event.detail;if(playerShowing){hidePlayer(true);}
updateDialog();};videodb.oncardremoved=function(){if(playerShowing)
hidePlayer(true);};videodb.onready=function(){storageState=false;updateDialog();enumerateDB();};videodb.onscanend=function(){firstScanEnded=true;updateDialog();};videodb.oncreated=function(event){event.detail.forEach(videoCreated);};videodb.ondeleted=function(event){event.detail.forEach(videoDeleted);};}
var enumerated=false;function enumerateDB(){if(enumerated)
return;enumerated=true;var batch=[];var batchSize=4;videodb.enumerate('date',null,'prev',function(videoinfo){if(videoinfo===null){flush();return;}
var isVideo=videoinfo.metadata.isVideo;if(isVideo===false){return;}
if(isVideo===undefined){addToMetadataQueue(videoinfo);return;}
if(isVideo===true){batch.push(videoinfo);if(batch.length>=batchSize){flush();batchSize*=2;}}});function flush(){batch.forEach(addVideo);batch.length=0;}}
function addVideo(videodata){if(!videodata||!videodata.metadata.isVideo){return;}
var insertPosition;if(videos.length===0||videodata.date>videos[0].date){insertPosition=0;}
else if(videodata.date<videos[videos.length-1].date){insertPosition=videos.length;}
else{insertPosition=binarysearch(videos,videodata,compareVideosByDate);}
videos.splice(insertPosition,0,videodata);var thumbnail=createThumbnailItem(insertPosition);var thumbnails=dom.thumbnails.children;dom.thumbnails.insertBefore(thumbnail,thumbnails[insertPosition]);for(var i=insertPosition;i<thumbnails.length;i++){thumbnails[i].dataset.index=i;}
if(videos.length===1)
updateDialog();function compareVideosByDate(a,b){return b.date-a.date;}
function binarysearch(array,element,comparator,from,to){if(comparator===undefined)
comparator=function(a,b){return a-b;};if(from===undefined)
return binarysearch(array,element,comparator,0,array.length);if(from===to)
return from;var mid=Math.floor((from+to)/2);var result=comparator(element,array[mid]);if(result<0)
return binarysearch(array,element,comparator,from,mid);else
return binarysearch(array,element,comparator,mid+1,to);}}
function videoCreated(videoinfo){addToMetadataQueue(videoinfo);}
function videoDeleted(filename){for(var n=0;n<videos.length;n++){if(videos[n].name===filename)
break;}
if(n>=videos.length)
return;videos.splice(n,1)[0];var thumbnails=dom.thumbnails.children;dom.thumbnails.removeChild(thumbnails[n]);for(var i=n;i<thumbnails.length;i++){thumbnails[i].dataset.index=i;}
if(videos.length===0){updateDialog();hideSelectView();}};'use strict';var dom={};var ids=['thumbnail-list-view','thumbnails-bottom','thumbnails','thumbnails-video-button','thumbnails-select-button','thumbnail-select-view','thumbnails-delete-button','thumbnails-share-button','thumbnails-cancel-button','thumbnails-number-selected','fullscreen-view','crop-view','thumbnails-single-delete-button','thumbnails-single-share-button','player','overlay','overlay-title','overlay-text','videoControls','videoBar','videoActionBar','close','play','playHead','timeSlider','elapsedTime','video-title','duration-text','elapsed-text','bufferedTime','slider-wrapper','throbber','delete-video-button','picker-header','picker-close','picker-title','picker-done'];ids.forEach(function createElementRef(name){dom[toCamelCase(name)]=document.getElementById(name);});var currentView=dom.thumbnailListView;dom.player.mozAudioChannelType='content';var playing=false;var playerShowing=false;var endedTimer;var controlShowing=false;var controlFadeTimeout=null;var selectedFileNames=[];var selectedFileNamesToBlobs={};var videodb;var currentVideo;var currentVideoBlob;var videos=[];var firstScanEnded=false;var scaleRatio=window.innerWidth/320;var THUMBNAIL_WIDTH=210*scaleRatio;var THUMBNAIL_HEIGHT=120*scaleRatio;var HAVE_NOTHING=0;var storageState;var currentOverlay;var dragging=false;var FROMCAMERA=/^DCIM\/\d{3}MZLLA\/VID_\d{4}\.3gp$/;function init(){initDB();dom.thumbnailsVideoButton.addEventListener('click',launchCameraApp);dom.thumbnailsSelectButton.addEventListener('click',showSelectView);dom.thumbnailsDeleteButton.addEventListener('click',deleteSelectedItems);dom.thumbnailsShareButton.addEventListener('click',shareSelectedItems);dom.thumbnailsSingleDeleteButton.addEventListener('click',function(){if(deleteSingleFile(currentVideo.name))
hidePlayer(false);});dom.thumbnailsSingleShareButton.addEventListener('click',function(){videodb.getFile(currentVideo.name,function(blob){share([blob]);});});dom.thumbnailsCancelButton.addEventListener('click',hideSelectView);}
function showSelectView(){dom.thumbnailListView.classList.add('hidden');dom.fullscreenView.classList.add('hidden');dom.thumbnailSelectView.classList.remove('hidden');currentView=dom.thumbnailSelectView;dom.thumbnails.classList.add('select');clearSelection();}
function hideSelectView(){clearSelection();dom.fullscreenView.classList.add('hidden');dom.thumbnailSelectView.classList.add('hidden');dom.thumbnailListView.classList.remove('hidden');dom.thumbnails.classList.remove('select');currentView=dom.thumbnailListView;}
function clearSelection(){Array.forEach(thumbnails.querySelectorAll('.selected.thumbnail'),function(elt){elt.classList.remove('selected');});selectedFileNames=[];selectedFileNamesToBlobs={};dom.thumbnailsDeleteButton.classList.add('disabled');dom.thumbnailsShareButton.classList.add('disabled');dom.thumbnailsNumberSelected.textContent=navigator.mozL10n.get('number-selected2',{n:0});}
function updateSelection(thumbnail){thumbnail.classList.toggle('selected');var selected=thumbnail.classList.contains('selected');var index=parseInt(thumbnail.dataset.index);var filename=videos[index].name;if(selected){selectedFileNames.push(filename);videodb.getFile(filename,function(blob){selectedFileNamesToBlobs[filename]=blob;});}
else{delete selectedFileNamesToBlobs[filename];var i=selectedFileNames.indexOf(filename);if(i!==-1)
selectedFileNames.splice(i,1);}
var numSelected=selectedFileNames.length;dom.thumbnailsNumberSelected.textContent=navigator.mozL10n.get('number-selected2',{n:numSelected});if(numSelected===0){dom.thumbnailsDeleteButton.classList.add('disabled');dom.thumbnailsShareButton.classList.add('disabled');}
else{dom.thumbnailsDeleteButton.classList.remove('disabled');dom.thumbnailsShareButton.classList.remove('disabled');}}
function launchCameraApp(){var a=new MozActivity({name:'record',data:{type:'videos'}});}
function deleteSelectedItems(){var selected=thumbnails.querySelectorAll('.selected.thumbnail');if(selected.length===0)
return;var msg=navigator.mozL10n.get('delete-n-items?',{n:selected.length});if(confirm(msg)){for(var i=0;i<selected.length;i++){selected[i].classList.toggle('selected');deleteFile(parseInt(selected[i].dataset.index));}
clearSelection();}}
function deleteFile(n){if(n<0||n>=videos.length)
return;var filename=videos[n].name;if(FROMCAMERA.test(filename)){var postername=filename.replace('.3gp','.jpg');navigator.getDeviceStorage('pictures').delete(postername);}
videodb.deleteFile(filename);}
function deleteSingleFile(file){var msg=navigator.mozL10n.get('confirm-delete');if(confirm(msg+' '+file)){if(FROMCAMERA.test(file)){var postername=file.replace('.3gp','.jpg');navigator.getDeviceStorage('pictures').delete(postername);}
videodb.deleteFile(file);return true;}
return false;}
function shareSelectedItems(){var blobs=selectedFileNames.map(function(name){return selectedFileNamesToBlobs[name];});share(blobs);}
function share(blobs){if(blobs.length===0)
return;var names=[],types=[],fullpaths=[];blobs.forEach(function(blob){var name=blob.name;fullpaths.push(name);name=name.substring(name.lastIndexOf('/')+1);names.push(name);var type=blob.type;if(type)
type=type.substring(0,type.indexOf('/'));types.push(type);});var type;if(types.length===1||types.every(function(t){return t===types[0];}))
type=types[0]+'/*';else
type='multipart/mixed';var a=new MozActivity({name:'share',data:{type:type,number:blobs.length,blobs:blobs,filenames:names,filepaths:fullpaths}});a.onerror=function(e){if(a.error.name==='NO_PROVIDER'){var msg=navigator.mozL10n.get('share-noprovider');alert(msg);}else{console.warn('share activity error:',a.error.name);}};}
function updateDialog(){if(videos.length!==0&&(!storageState||playerShowing)){showOverlay(null);return;}
if(storageState===MediaDB.NOCARD){showOverlay('nocard');}else if(storageState===MediaDB.UNMOUNTED){showOverlay('pluggedin');}else if(firstScanEnded&&videos.length===0&&metadataQueue.length===0){showOverlay('empty');}}
function createThumbnailItem(videonum){var videodata=videos[videonum];var inner=document.createElement('div');inner.className='inner';var imageblob=videodata.metadata.bookmark||videodata.metadata.poster;var poster=document.createElement('div');poster.className='img';if(imageblob){setPosterImage(poster,imageblob);}
var details=document.createElement('div');details.className='details';details.dataset.title=videodata.metadata.title;var title=document.createElement('span');title.className='title';title.textContent=videodata.metadata.title;details.appendChild(title);if(isFinite(videodata.metadata.duration)){var d=Math.round(videodata.metadata.duration);var after=document.createElement('span');after.className='after';after.textContent=' '+formatDuration(d);details.appendChild(after);}
details.addEventListener('overflow',detailsOverflowHandler);var thumbnail=document.createElement('li');thumbnail.className='thumbnail';inner.appendChild(poster);if(!videodata.metadata.watched){var unread=document.createElement('div');unread.classList.add('unwatched');inner.appendChild(unread);}
thumbnail.dataset.name=videodata.name;thumbnail.dataset.index=videonum;thumbnail.addEventListener('click',thumbnailClickHandler);inner.appendChild(details);thumbnail.appendChild(inner);return thumbnail;}
function detailsOverflowHandler(e){var el=e.target;var title=el.firstElementChild;if(title.textContent.length>5){var max=(window.innerWidth>window.innerHeight)?175:45;var end=title.textContent.length>max?max-1:-5;title.textContent=title.textContent.slice(0,end)+'\u2026';el.style.overflow='visible';setTimeout(function(){el.style.overflow='hidden';});}}
function thumbnailClickHandler(){if(!this.classList.contains('thumbnail'))
return;if(currentView===dom.thumbnailListView||currentView===dom.fullscreenView){var index=parseInt(this.dataset.index);stopParsingMetadata(function(){showPlayer(index,true);});}
else if(currentView===dom.thumbnailSelectView){updateSelection(this);}}
function getThumbnailDom(filename){return dom.thumbnails.querySelectorAll('[data-name="'+filename+'"]')[0];}
function setPosterImage(dom,poster){if(dom.dataset.uri){URL.revokeObjectURL(dom.dataset.uri);}
dom.dataset.uri=URL.createObjectURL(poster);dom.style.backgroundImage='url('+dom.dataset.uri+')';}
function showOverlay(id){currentOverlay=id;if(id===null){dom.overlay.classList.add('hidden');return;}
dom.overlayTitle.textContent=navigator.mozL10n.get(id+'-title');dom.overlayText.textContent=navigator.mozL10n.get(id+'-text');dom.overlay.classList.remove('hidden');}
function showVideoControls(visible){dom.videoControls.classList[visible?'remove':'add']('hidden');controlShowing=visible;}
function setVideoPlaying(playing){if(playing){play();}else{pause();}}
function playerMousedown(event){if(controlFadeTimeout){clearTimeout(controlFadeTimeout);controlFadeTimeout=null;}
if(!controlShowing){showVideoControls(true);return;}
if(event.target==dom.play){setVideoPlaying(dom.player.paused);}else if(event.target==dom.close){hidePlayer(true);}else if(event.target==dom.sliderWrapper){dragSlider(event);}else if(event.target==dom.pickerDone&&pendingPick){pendingPick.postResult({type:currentVideoBlob.type,blob:currentVideoBlob});cleanupPick();}else if(pendingPick){showVideoControls(true);}else{showVideoControls(false);}}
function setPlayerSize(){var containerHeight=(window.innerHeight>dom.player.offsetHeight)?window.innerHeight:dom.player.offsetHeight;dom.cropView.style.marginTop=(containerHeight/2)*-1+'px';dom.cropView.style.height=containerHeight+'px';}
function setVideoUrl(player,video,callback){if('name'in video){videodb.getFile(video.name,function(file){var url=URL.createObjectURL(file);player.onloadedmetadata=callback;player.src=url;if(pendingPick)
currentVideoBlob=file;});}else if('url'in video){player.onloadedmetadata=callback;player.src=video.url;}}
function showPlayer(videonum,autoPlay){currentVideo=videos[videonum];dom.thumbnails.classList.add('hidden');dom.thumbnailListView.classList.add('hidden');dom.thumbnailSelectView.classList.add('hidden');dom.fullscreenView.classList.remove('hidden');currentView=dom.fullscreenView;updateDialog();dom.player.preload='metadata';function doneSeeking(){dom.player.onseeked=null;showVideoControls(true);if(!pendingPick){controlFadeTimeout=setTimeout(function(){showVideoControls(false);},250);}
if(autoPlay){play();}}
setVideoUrl(dom.player,currentVideo,function(){dom.durationText.textContent=formatDuration(dom.player.duration);timeUpdated();dom.play.classList.remove('paused');playerShowing=true;setPlayerSize();if('metadata'in currentVideo){if(currentVideo.metadata.currentTime===dom.player.duration){currentVideo.metadata.currentTime=0;}
dom.videoTitle.textContent=currentVideo.metadata.title;dom.player.currentTime=currentVideo.metadata.currentTime||0;}else{dom.videoTitle.textContent=currentVideo.title||'';dom.player.currentTime=0;}
if(dom.player.seeking){dom.player.onseeked=doneSeeking;}else{doneSeeking();}});}
function hidePlayer(updateMetadata){if(!playerShowing)
return;dom.player.pause();function completeHidingPlayer(){dom.fullscreenView.classList.add('hidden');dom.thumbnailSelectView.classList.add('hidden');dom.thumbnailListView.classList.remove('hidden');currentView===dom.thumbnailListView;dom.play.classList.remove('paused');dom.thumbnails.classList.remove('hidden');playerShowing=false;updateDialog();dom.player.removeAttribute('src');dom.player.load();startParsingMetadata();}
if(!('metadata'in currentVideo)||!updateMetadata||pendingPick){completeHidingPlayer();return;}
var video=currentVideo;var thumbnail=getThumbnailDom(video.name);if(dom.player.currentTime===0){video.metadata.bookmark=null;updateMetadata();}
else{captureFrame(dom.player,video.metadata,function(bookmark){video.metadata.bookmark=bookmark;updateMetadata();});}
function updateMetadata(){var posterImg=thumbnail.querySelector('.img');var imageblob=video.metadata.bookmark||video.metadata.poster;if(posterImg&&imageblob){setPosterImage(posterImg,imageblob);}
if(!video.metadata.watched){video.metadata.watched=true;var unwatched=thumbnail.querySelector('.unwatched');if(unwatched){unwatched.parentNode.removeChild(unwatched);}}
video.metadata.currentTime=dom.player.currentTime;videodb.updateMetadata(video.name,video.metadata);completeHidingPlayer();}}
function playerEnded(){if(dragging){return;}
if(endedTimer){clearTimeout(endedTimer);endedTimer=null;}
dom.player.currentTime=0;hidePlayer(true);}
function play(){dom.play.classList.remove('paused');dom.player.play();playing=true;}
function pause(){dom.play.classList.add('paused');dom.player.pause();playing=false;}
function timeUpdated(){if(controlShowing){if(dom.player.duration===Infinity||dom.player.duration===0){return;}
var percent=(dom.player.currentTime/dom.player.duration)*100+'%';dom.elapsedText.textContent=formatDuration(dom.player.currentTime);dom.elapsedTime.style.width=percent;if(!dragging)
dom.playHead.style.left=percent;}
if(!endedTimer){if(!dragging&&dom.player.currentTime>=dom.player.duration-1){var timeUntilEnd=(dom.player.duration-dom.player.currentTime+.5);endedTimer=setTimeout(playerEnded,timeUntilEnd*1000);}}else if(dragging&&dom.player.currentTime<dom.player.duration-1){clearTimeout(endedTimer);endedTimer=null;}}
function dragSlider(e){var isPaused=dom.player.paused;dragging=true;if(dom.player.duration===Infinity)
return;if(!isPaused){dom.player.pause();}
document.addEventListener('mousemove',mousemoveHandler,true);document.addEventListener('mouseup',mouseupHandler,true);function position(event){var rect=dom.sliderWrapper.getBoundingClientRect();var position=(event.clientX-rect.left)/rect.width;position=Math.max(position,0);position=Math.min(position,1);return position;}
function mouseupHandler(event){document.removeEventListener('mousemove',mousemoveHandler,true);document.removeEventListener('mouseup',mouseupHandler,true);dragging=false;dom.playHead.classList.remove('active');if(dom.player.currentTime===dom.player.duration){pause();}else if(!isPaused){dom.player.play();}}
function mousemoveHandler(event){var pos=position(event);var percent=pos*100+'%';dom.playHead.classList.add('active');dom.playHead.style.left=percent;dom.elapsedTime.style.width=percent;dom.player.currentTime=dom.player.duration*pos;dom.elapsedText.textContent=formatDuration(dom.player.currentTime);}
mousemoveHandler(e);}
function fileNameToVideoName(filename){filename=filename.split('/').pop().replace(/\.(webm|ogv|mp4)$/,'').replace(/[_\.]/g,' ');return filename.charAt(0).toUpperCase()+filename.slice(1);}
function toCamelCase(str){return str.replace(/\-(.)/g,function replacer(str,p1){return p1.toUpperCase();});}
function padLeft(num,length){var r=String(num);while(r.length<length){r='0'+r;}
return r;}
function formatDuration(duration){var minutes=Math.floor(duration/60);var seconds=Math.floor(duration%60);if(minutes<60){return padLeft(minutes,2)+':'+padLeft(seconds,2);}
var hours=Math.floor(minutes/60);minutes=Math.floor(minutes%60);return hours+':'+padLeft(minutes,2)+':'+padLeft(seconds,2);}
document.addEventListener('mozvisibilitychange',function visibilityChange(){if(document.mozHidden){stopParsingMetadata();if(playing)
pause();if(playerShowing)
releaseVideo();}
else{startParsingMetadata();if(playerShowing){showVideoControls(true);restoreVideo();}}});var restoreTime;function releaseVideo(){restoreTime=dom.player.currentTime;dom.player.removeAttribute('src');dom.player.load();}
function restoreVideo(){setVideoUrl(dom.player,currentVideo,function(){setPlayerSize();dom.player.currentTime=restoreTime;});}
dom.videoControls.addEventListener('mousedown',playerMousedown);function forceRepaintTitles(){var texts=document.querySelectorAll('.details');for(var i=0;i<texts.length;i++){texts[i].style.overflow='visible';texts[i].firstElementChild.textContent=texts[i].dataset.title;texts[i].style.overflow='hidden';}}
window.addEventListener('resize',function(){if(dom.player.readyState!==HAVE_NOTHING){setPlayerSize();}
forceRepaintTitles();});dom.player.addEventListener('timeupdate',timeUpdated);dom.player.addEventListener('ended',playerEnded);window.addEventListener('localized',function showBody(){document.documentElement.lang=navigator.mozL10n.language.code;document.documentElement.dir=navigator.mozL10n.language.direction;document.body.classList.remove('hidden');if(!videodb)
init();});var acm=navigator.mozAudioChannelManager;if(acm){acm.addEventListener('headphoneschange',function onheadphoneschange(){if(!acm.headphones&&playing){setVideoPlaying(false);}});}
var pendingPick;function showPickView(){dom.thumbnails.classList.add('pick');dom.pickerHeader.classList.remove('hidden');dom.pickerDone.classList.remove('hidden');dom.thumbnailsBottom.classList.add('hidden');dom.videoActionBar.parentNode.removeChild(dom.videoActionBar);dom.pickerClose.addEventListener('click',function(){pendingPick.postError('pick cancelled');});}
function cleanupPick(){pendingPick=null;currentVideoBlob=null;hidePlayer(false);}
navigator.mozSetMessageHandler('activity',function activityHandler(a){var activityName=a.source.name;if(activityName==='pick'){pendingPick=a;showPickView();}});function showThrobber(){dom.throbber.classList.remove('hidden');dom.throbber.classList.add('throb');}
function hideThrobber(){dom.throbber.classList.add('hidden');dom.throbber.classList.remove('throb');}