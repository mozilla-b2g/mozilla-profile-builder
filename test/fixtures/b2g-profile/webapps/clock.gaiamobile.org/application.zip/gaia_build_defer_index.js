;'use strict';(function(window){var gL10nData={};var gTextProp='textContent';var gLanguage='';var gMacros={};var gReadyState='loading';var gAsyncResourceLoading=true;var gDEBUG=1;function consoleLog(message){if(gDEBUG>=2){console.log('[l10n] '+message);}};function consoleWarn(message){if(gDEBUG){console.warn('[l10n] '+message);}};function getL10nResourceLinks(){return document.querySelectorAll('link[type="application/l10n"]');}
function getL10nDictionary(){var script=document.querySelector('script[type="application/l10n"]');return script?JSON.parse(script.innerHTML):null;}
function getTranslatableChildren(element){return element?element.querySelectorAll('*[data-l10n-id]'):[];}
function getL10nAttributes(element){if(!element)
return{};var l10nId=element.getAttribute('data-l10n-id');var l10nArgs=element.getAttribute('data-l10n-args');var args={};if(l10nArgs){try{args=JSON.parse(l10nArgs);}catch(e){consoleWarn('could not parse arguments for #'+l10nId);}}
return{id:l10nId,args:args};}
function fireL10nReadyEvent(){var evtObject=document.createEvent('Event');evtObject.initEvent('localized',false,false);evtObject.language=gLanguage;window.dispatchEvent(evtObject);}
function parseResource(href,lang,successCallback,failureCallback){var baseURL=href.replace(/\/[^\/]*$/,'/');function evalString(text){if(text.lastIndexOf('\\')<0)
return text;return text.replace(/\\\\/g,'\\').replace(/\\n/g,'\n').replace(/\\r/g,'\r').replace(/\\t/g,'\t').replace(/\\b/g,'\b').replace(/\\f/g,'\f').replace(/\\{/g,'{').replace(/\\}/g,'}').replace(/\\"/g,'"').replace(/\\'/g,"'");}
function parseProperties(text){var dictionary=[];var reBlank=/^\s*|\s*$/;var reComment=/^\s*#|^\s*$/;var reSection=/^\s*\[(.*)\]\s*$/;var reImport=/^\s*@import\s+url\((.*)\)\s*$/i;var reSplit=/^([^=\s]*)\s*=\s*(.+)$/;function parseRawLines(rawText,extendedSyntax){var entries=rawText.replace(reBlank,'').split(/[\r\n]+/);var currentLang='*';var genericLang=lang.replace(/-[a-z]+$/i,'');var skipLang=false;var match='';for(var i=0;i<entries.length;i++){var line=entries[i];if(reComment.test(line))
continue;if(extendedSyntax){if(reSection.test(line)){match=reSection.exec(line);currentLang=match[1];skipLang=(currentLang!=='*')&&(currentLang!==lang)&&(currentLang!==genericLang);continue;}else if(skipLang){continue;}
if(reImport.test(line)){match=reImport.exec(line);loadImport(baseURL+match[1]);}}
var tmp=line.match(reSplit);if(tmp&&tmp.length==3){dictionary[tmp[1]]=evalString(tmp[2]);}}}
function loadImport(url){loadResource(url,function(content){parseRawLines(content,false);},null,false);}
parseRawLines(text,true);return dictionary;}
function loadResource(url,onSuccess,onFailure,asynchronous){onSuccess=onSuccess||function _onSuccess(data){};onFailure=onFailure||function _onFailure(){consoleWarn(url+' not found.');};var xhr=new XMLHttpRequest();xhr.open('GET',url,asynchronous);if(xhr.overrideMimeType){xhr.overrideMimeType('text/plain; charset=utf-8');}
xhr.onreadystatechange=function(){if(xhr.readyState==4){if(xhr.status==200||xhr.status===0){onSuccess(xhr.responseText);}else{onFailure();}}};xhr.onerror=onFailure;xhr.ontimeout=onFailure;try{xhr.send(null);}catch(e){onFailure();}}
loadResource(href,function(response){var data=parseProperties(response);for(var key in data){var id,prop,index=key.lastIndexOf('.');if(index>0){id=key.substring(0,index);prop=key.substr(index+1);}else{id=key;prop=gTextProp;}
if(!gL10nData[id]){gL10nData[id]={};}
gL10nData[id][prop]=data[key];}
if(successCallback){successCallback();}},failureCallback,gAsyncResourceLoading);};function loadLocale(lang,callback){callback=callback||function _callback(){};clear();gLanguage=lang;var langLinks=getL10nResourceLinks();var langCount=langLinks.length;if(langCount==0){var dict=getL10nDictionary();if(dict&&dict.locales&&dict.default_locale){consoleLog('using the embedded JSON directory, early way out');gL10nData=dict.locales[lang]||dict.locales[dict.default_locale];callback();}else{consoleLog('no resource to load, early way out');}
fireL10nReadyEvent(lang);gReadyState='complete';return;}
var onResourceLoaded=null;var gResourceCount=0;onResourceLoaded=function(){gResourceCount++;if(gResourceCount>=langCount){callback();fireL10nReadyEvent(lang);gReadyState='complete';}};function l10nResourceLink(link){var href=link.href;var type=link.type;this.load=function(lang,callback){var applied=lang;parseResource(href,lang,callback,function(){consoleWarn(href+' not found.');applied='';});return applied;};}
for(var i=0;i<langCount;i++){var resource=new l10nResourceLink(langLinks[i]);var rv=resource.load(lang,onResourceLoaded);if(rv!=lang){consoleWarn('"'+lang+'" resource not found');gLanguage='';}}}
function clear(){gL10nData={};gLanguage='';}
function getPluralRules(lang){var locales2rules={'af':3,'ak':4,'am':4,'ar':1,'asa':3,'az':0,'be':11,'bem':3,'bez':3,'bg':3,'bh':4,'bm':0,'bn':3,'bo':0,'br':20,'brx':3,'bs':11,'ca':3,'cgg':3,'chr':3,'cs':12,'cy':17,'da':3,'de':3,'dv':3,'dz':0,'ee':3,'el':3,'en':3,'eo':3,'es':3,'et':3,'eu':3,'fa':0,'ff':5,'fi':3,'fil':4,'fo':3,'fr':5,'fur':3,'fy':3,'ga':8,'gd':24,'gl':3,'gsw':3,'gu':3,'guw':4,'gv':23,'ha':3,'haw':3,'he':2,'hi':4,'hr':11,'hu':0,'id':0,'ig':0,'ii':0,'is':3,'it':3,'iu':7,'ja':0,'jmc':3,'jv':0,'ka':0,'kab':5,'kaj':3,'kcg':3,'kde':0,'kea':0,'kk':3,'kl':3,'km':0,'kn':0,'ko':0,'ksb':3,'ksh':21,'ku':3,'kw':7,'lag':18,'lb':3,'lg':3,'ln':4,'lo':0,'lt':10,'lv':6,'mas':3,'mg':4,'mk':16,'ml':3,'mn':3,'mo':9,'mr':3,'ms':0,'mt':15,'my':0,'nah':3,'naq':7,'nb':3,'nd':3,'ne':3,'nl':3,'nn':3,'no':3,'nr':3,'nso':4,'ny':3,'nyn':3,'om':3,'or':3,'pa':3,'pap':3,'pl':13,'ps':3,'pt':3,'rm':3,'ro':9,'rof':3,'ru':11,'rwk':3,'sah':0,'saq':3,'se':7,'seh':3,'ses':0,'sg':0,'sh':11,'shi':19,'sk':12,'sl':14,'sma':7,'smi':7,'smj':7,'smn':7,'sms':7,'sn':3,'so':3,'sq':3,'sr':11,'ss':3,'ssy':3,'st':3,'sv':3,'sw':3,'syr':3,'ta':3,'te':3,'teo':3,'th':0,'ti':4,'tig':3,'tk':3,'tl':4,'tn':3,'to':0,'tr':0,'ts':3,'tzm':22,'uk':11,'ur':3,'ve':3,'vi':0,'vun':3,'wa':4,'wae':3,'wo':0,'xh':3,'xog':3,'yo':0,'zh':0,'zu':3};function isIn(n,list){return list.indexOf(n)!==-1;}
function isBetween(n,start,end){return start<=n&&n<=end;}
var pluralRules={'0':function(n){return'other';},'1':function(n){if((isBetween((n%100),3,10)))
return'few';if(n===0)
return'zero';if((isBetween((n%100),11,99)))
return'many';if(n==2)
return'two';if(n==1)
return'one';return'other';},'2':function(n){if(n!==0&&(n%10)===0)
return'many';if(n==2)
return'two';if(n==1)
return'one';return'other';},'3':function(n){if(n==1)
return'one';return'other';},'4':function(n){if((isBetween(n,0,1)))
return'one';return'other';},'5':function(n){if((isBetween(n,0,2))&&n!=2)
return'one';return'other';},'6':function(n){if(n===0)
return'zero';if((n%10)==1&&(n%100)!=11)
return'one';return'other';},'7':function(n){if(n==2)
return'two';if(n==1)
return'one';return'other';},'8':function(n){if((isBetween(n,3,6)))
return'few';if((isBetween(n,7,10)))
return'many';if(n==2)
return'two';if(n==1)
return'one';return'other';},'9':function(n){if(n===0||n!=1&&(isBetween((n%100),1,19)))
return'few';if(n==1)
return'one';return'other';},'10':function(n){if((isBetween((n%10),2,9))&&!(isBetween((n%100),11,19)))
return'few';if((n%10)==1&&!(isBetween((n%100),11,19)))
return'one';return'other';},'11':function(n){if((isBetween((n%10),2,4))&&!(isBetween((n%100),12,14)))
return'few';if((n%10)===0||(isBetween((n%10),5,9))||(isBetween((n%100),11,14)))
return'many';if((n%10)==1&&(n%100)!=11)
return'one';return'other';},'12':function(n){if((isBetween(n,2,4)))
return'few';if(n==1)
return'one';return'other';},'13':function(n){if((isBetween((n%10),2,4))&&!(isBetween((n%100),12,14)))
return'few';if(n!=1&&(isBetween((n%10),0,1))||(isBetween((n%10),5,9))||(isBetween((n%100),12,14)))
return'many';if(n==1)
return'one';return'other';},'14':function(n){if((isBetween((n%100),3,4)))
return'few';if((n%100)==2)
return'two';if((n%100)==1)
return'one';return'other';},'15':function(n){if(n===0||(isBetween((n%100),2,10)))
return'few';if((isBetween((n%100),11,19)))
return'many';if(n==1)
return'one';return'other';},'16':function(n){if((n%10)==1&&n!=11)
return'one';return'other';},'17':function(n){if(n==3)
return'few';if(n===0)
return'zero';if(n==6)
return'many';if(n==2)
return'two';if(n==1)
return'one';return'other';},'18':function(n){if(n===0)
return'zero';if((isBetween(n,0,2))&&n!==0&&n!=2)
return'one';return'other';},'19':function(n){if((isBetween(n,2,10)))
return'few';if((isBetween(n,0,1)))
return'one';return'other';},'20':function(n){if((isBetween((n%10),3,4)||((n%10)==9))&&!(isBetween((n%100),10,19)||isBetween((n%100),70,79)||isBetween((n%100),90,99)))
return'few';if((n%1000000)===0&&n!==0)
return'many';if((n%10)==2&&!isIn((n%100),[12,72,92]))
return'two';if((n%10)==1&&!isIn((n%100),[11,71,91]))
return'one';return'other';},'21':function(n){if(n===0)
return'zero';if(n==1)
return'one';return'other';},'22':function(n){if((isBetween(n,0,1))||(isBetween(n,11,99)))
return'one';return'other';},'23':function(n){if((isBetween((n%10),1,2))||(n%20)===0)
return'one';return'other';},'24':function(n){if((isBetween(n,3,10)||isBetween(n,13,19)))
return'few';if(isIn(n,[2,12]))
return'two';if(isIn(n,[1,11]))
return'one';return'other';}};var index=locales2rules[lang.replace(/-.*$/,'')];if(!(index in pluralRules)){consoleWarn('plural form unknown for ['+lang+']');return function(){return'other';};}
return pluralRules[index];}
gMacros.plural=function(str,param,key,prop){var n=parseFloat(param);if(isNaN(n))
return str;if(prop!=gTextProp)
return str;if(!gMacros._pluralRules){gMacros._pluralRules=getPluralRules(gLanguage);}
var index='['+gMacros._pluralRules(n)+']';if(n===0&&(key+'[zero]')in gL10nData){str=gL10nData[key+'[zero]'][prop];}else if(n==1&&(key+'[one]')in gL10nData){str=gL10nData[key+'[one]'][prop];}else if(n==2&&(key+'[two]')in gL10nData){str=gL10nData[key+'[two]'][prop];}else if((key+index)in gL10nData){str=gL10nData[key+index][prop];}else if((key+'[other]')in gL10nData){str=gL10nData[key+'[other]'][prop];}
return str;};function getL10nData(key,args){var data=gL10nData[key];if(!data){consoleWarn('#'+key+' is undefined.');}
var rv={};for(var prop in data){var str=data[prop];str=substIndexes(str,args,key,prop);str=substArguments(str,args,key);rv[prop]=str;}
return rv;}
function substIndexes(str,args,key,prop){var reIndex=/\{\[\s*([a-zA-Z]+)\(([a-zA-Z]+)\)\s*\]\}/;var reMatch=reIndex.exec(str);if(!reMatch||!reMatch.length)
return str;var macroName=reMatch[1];var paramName=reMatch[2];var param;if(args&&paramName in args){param=args[paramName];}else if(paramName in gL10nData){param=gL10nData[paramName];}
if(macroName in gMacros){var macro=gMacros[macroName];str=macro(str,param,key,prop);}
return str;}
function substArguments(str,args,key){var reArgs=/\{\{\s*(.+?)\s*\}\}/;var match=reArgs.exec(str);while(match){if(!match||match.length<2)
return str;var arg=match[1];var sub='';if(args&&arg in args){sub=args[arg];}else if(arg in gL10nData){sub=gL10nData[arg][gTextProp];}else{consoleLog('argument {{'+arg+'}} for #'+key+' is undefined.');return str;}
str=str.substring(0,match.index)+sub+
str.substr(match.index+match[0].length);match=reArgs.exec(str);}
return str;}
function translateElement(element){var l10n=getL10nAttributes(element);if(!l10n.id){return;}
var data=getL10nData(l10n.id,l10n.args);if(!data){consoleWarn('#'+l10n.id+' is undefined.');return;}
if(data[gTextProp]){if(element.children.length===0){element[gTextProp]=data[gTextProp];}else{var children=element.childNodes;var found=false;for(var i=0,l=children.length;i<l;i++){if(children[i].nodeType===3&&/\S/.test(children[i].nodeValue)){if(found){children[i].nodeValue='';}else{children[i].nodeValue=data[gTextProp];found=true;}}}
if(!found){var textNode=document.createTextNode(data[gTextProp]);element.insertBefore(textNode,element.firstChild);}}
delete data[gTextProp];}
for(var k in data){element[k]=data[k];}}
function translateFragment(element){element=element||document.documentElement;var children=getTranslatableChildren(element);var elementCount=children.length;for(var i=0;i<elementCount;i++){translateElement(children[i]);}
translateElement(element);}
function l10nStartup(){gReadyState='interactive';consoleLog('loading ['+navigator.language+'] resources, '+
(gAsyncResourceLoading?'asynchronously.':'synchronously.'));if(document.documentElement.lang===navigator.language){loadLocale(navigator.language);}else{loadLocale(navigator.language,translateFragment);}}
if(typeof(document)!=='undefined'){if(document.readyState==='complete'||document.readyState==='interactive'){window.setTimeout(l10nStartup);}else{document.addEventListener('DOMContentLoaded',l10nStartup);}}
if('mozSettings'in navigator&&navigator.mozSettings){navigator.mozSettings.addObserver('language.current',function(event){loadLocale(event.settingValue,translateFragment);});}
navigator.mozL10n={get:function l10n_get(key,args,fallback){var data=getL10nData(key,args)||fallback;if(data){return'textContent'in data?data.textContent:'';}
return'{{'+key+'}}';},get language(){return{get code(){return gLanguage;},set code(lang){loadLocale(lang,translateFragment);},get direction(){var rtlList=['ar','he','fa','ps','ur'];return(rtlList.indexOf(gLanguage)>=0)?'rtl':'ltr';}};},translate:translateFragment,get dictionary(){return JSON.parse(JSON.stringify(gL10nData));},get readyState(){return gReadyState;},ready:function l10n_ready(callback){if(!callback)
return;if(gReadyState=='complete'){window.setTimeout(callback);}else{window.addEventListener('localized',callback);}}};consoleLog('library loaded.');})(this);;'use strict';navigator.mozL10n.DateTimeFormat=function(locales,options){var _=navigator.mozL10n.get;function localeFormat(d,format){var tokens=format.match(/(%E.|%O.|%.)/g);for(var i=0;tokens&&i<tokens.length;i++){var value='';switch(tokens[i]){case'%a':value=_('weekday-'+d.getDay()+'-short');break;case'%A':value=_('weekday-'+d.getDay()+'-long');break;case'%b':case'%h':value=_('month-'+d.getMonth()+'-short');break;case'%B':value=_('month-'+d.getMonth()+'-long');break;case'%Eb':value=_('month-'+d.getMonth()+'-genitive');break;case'%I':value=d.getHours()%12||12;break;case'%e':value=d.getDate();break;case'%p':value=d.getHours()<12?'AM':'PM';break;case'%c':case'%x':case'%X':var tmp=_('dateTimeFormat_'+tokens[i]);if(tmp&&!(/(%c|%x|%X)/).test(tmp)){value=localeFormat(d,tmp);}
break;}
format=format.replace(tokens[i],value||d.toLocaleFormat(tokens[i]));}
return format;}
function relativeParts(seconds){seconds=Math.abs(seconds);var descriptors={};var units=['years',86400*365,'months',86400*30,'weeks',86400*7,'days',86400,'hours',3600,'minutes',60];if(seconds<60){return{minutes:Math.round(seconds/60)};}
for(var i=0,uLen=units.length;i<uLen;i+=2){var value=units[i+1];if(seconds>=value){descriptors[units[i]]=Math.floor(seconds/value);seconds-=descriptors[units[i]]*value;}}
return descriptors;}
function prettyDate(time,useCompactFormat,maxDiff){maxDiff=maxDiff||86400*10;switch(time.constructor){case String:time=parseInt(time);break;case Date:time=time.getTime();break;}
var secDiff=(Date.now()-time)/1000;if(isNaN(secDiff)){return _('incorrectDate');}
if(secDiff>maxDiff){return localeFormat(new Date(time),'%x');}
var f=useCompactFormat?'-short':'-long';var parts=relativeParts(secDiff);var affix=secDiff>=0?'-ago':'-until';for(var i in parts){return _(i+affix+f,{value:parts[i]});}}
return{localeDateString:function localeDateString(d){return localeFormat(d,'%x');},localeTimeString:function localeTimeString(d){return localeFormat(d,'%X');},localeString:function localeString(d){return localeFormat(d,'%c');},localeFormat:localeFormat,fromNow:prettyDate,relativeParts:relativeParts};};;'use strict';var GestureDetector=(function(){function GD(e,options){this.element=e;this.options=options||{};this.state=initialState;this.timers={};this.listeningForMouseEvents=true;}
GD.prototype.startDetecting=function(){var self=this;eventtypes.forEach(function(t){self.element.addEventListener(t,self);});};GD.prototype.stopDetecting=function(){var self=this;eventtypes.forEach(function(t){self.element.removeEventListener(t,self);});};GD.prototype.handleEvent=function(e){var handler=this.state[e.type];if(!handler)return;if(e.changedTouches){if(this.listeningForMouseEvents){this.listeningForMouseEvents=false;this.element.removeEventListener('mousedown',this);}
if(e.type==='touchend'&&e.changedTouches.length>1){console.warn('gesture_detector.js: spurious extra changed touch on '+'touchend. See '+'https://bugzilla.mozilla.org/show_bug.cgi?id=785554');}
for(var i=0;i<e.changedTouches.length;i++){handler(this,e,e.changedTouches[i]);handler=this.state[e.type];}}
else{handler(this,e);}};GD.prototype.startTimer=function(type,time){this.clearTimer(type);var self=this;this.timers[type]=setTimeout(function(){self.timers[type]=null;var handler=self.state[type];if(handler)
handler(self,type);},time);};GD.prototype.clearTimer=function(type){if(this.timers[type]){clearTimeout(this.timers[type]);this.timers[type]=null;}};GD.prototype.switchTo=function(state,event,touch){this.state=state;if(state.init)
state.init(this,event,touch);};GD.prototype.emitEvent=function(type,detail){if(!this.target){console.error('Attempt to emit event with no target');return;}
var event=this.element.ownerDocument.createEvent('CustomEvent');event.initCustomEvent(type,true,true,detail);this.target.dispatchEvent(event);};GD.HOLD_INTERVAL=1000;GD.PAN_THRESHOLD=20;GD.MOUSE_PAN_THRESHOLD=15;GD.DOUBLE_TAP_DISTANCE=50;GD.DOUBLE_TAP_TIME=500;GD.VELOCITY_SMOOTHING=.5;GD.SCALE_THRESHOLD=20;GD.ROTATE_THRESHOLD=22.5;GD.THRESHOLD_SMOOTHING=0.9;var abs=Math.abs,floor=Math.floor,sqrt=Math.sqrt,atan2=Math.atan2;var PI=Math.PI;var eventtypes=['touchstart','touchmove','touchend','mousedown'];function eventTime(e){var ts=e.timeStamp;if(ts>2*Date.now())
return Math.floor(ts/1000);else
return ts;}
function coordinates(e,t){return Object.freeze({screenX:t.screenX,screenY:t.screenY,clientX:t.clientX,clientY:t.clientY,timeStamp:eventTime(e)});}
function midpoints(e,t1,t2){return Object.freeze({screenX:floor((t1.screenX+t2.screenX)/2),screenY:floor((t1.screenY+t2.screenY)/2),clientX:floor((t1.clientX+t2.clientX)/2),clientY:floor((t1.clientY+t2.clientY)/2),timeStamp:eventTime(e)});}
function mouseCoordinates(e){return Object.freeze({screenX:e.screenX,screenY:e.screenY,clientX:e.clientX,clientY:e.clientY,timeStamp:eventTime(e)});}
function between(c1,c2){var r=GD.THRESHOLD_SMOOTHING;return Object.freeze({screenX:floor(c1.screenX+r*(c2.screenX-c1.screenX)),screenY:floor(c1.screenY+r*(c2.screenY-c1.screenY)),clientX:floor(c1.clientX+r*(c2.clientX-c1.clientX)),clientY:floor(c1.clientY+r*(c2.clientY-c1.clientY)),timeStamp:floor(c1.timeStamp+r*(c2.timeStamp-c1.timeStamp))});}
function touchDistance(t1,t2){var dx=t2.screenX-t1.screenX;var dy=t2.screenY-t1.screenY;return sqrt(dx*dx+dy*dy);}
function touchDirection(t1,t2){return atan2(t2.screenY-t1.screenY,t2.screenX-t1.screenX)*180/PI;}
function touchRotation(d1,d2){var angle=d2-d1;if(angle>180)
angle-=360;else if(angle<=-180)
angle+=360;return angle;}
function isDoubleTap(lastTap,thisTap){var dx=abs(thisTap.screenX-lastTap.screenX);var dy=abs(thisTap.screenY-lastTap.screenY);var dt=thisTap.timeStamp-lastTap.timeStamp;return(dx<GD.DOUBLE_TAP_DISTANCE&&dy<GD.DOUBLE_TAP_DISTANCE&&dt<GD.DOUBLE_TAP_TIME);}
var initialState={name:'initialState',init:function(d){d.target=null;d.start=d.last=null;d.touch1=d.touch2=null;d.vx=d.vy=null;d.startDistance=d.lastDistance=null;d.startDirection=d.lastDirection=null;d.lastMidpoint=null;d.scaled=d.rotated=null;},touchstart:function(d,e,t){d.switchTo(touchStartedState,e,t);},mousedown:function(d,e){d.switchTo(mouseDownState,e);}};var touchStartedState={name:'touchStartedState',init:function(d,e,t){d.target=e.target;d.touch1=t.identifier;d.start=d.last=coordinates(e,t);if(d.options.holdEvents)
d.startTimer('holdtimeout',GD.HOLD_INTERVAL);},touchstart:function(d,e,t){d.clearTimer('holdtimeout');d.switchTo(transformState,e,t);},touchmove:function(d,e,t){if(t.identifier!==d.touch1)
return;if(abs(t.screenX-d.start.screenX)>GD.PAN_THRESHOLD||abs(t.screenY-d.start.screenY)>GD.PAN_THRESHOLD){d.clearTimer('holdtimeout');d.switchTo(panStartedState,e,t);}},touchend:function(d,e,t){if(t.identifier!==d.touch1)
return;if(d.lastTap&&isDoubleTap(d.lastTap,d.start)){d.emitEvent('tap',d.start);d.emitEvent('dbltap',d.start);d.lastTap=null;}
else{d.emitEvent('tap',d.start);d.lastTap=coordinates(e,t);}
d.clearTimer('holdtimeout');d.switchTo(initialState);},holdtimeout:function(d){d.switchTo(holdState);}};var panStartedState={name:'panStartedState',init:function(d,e,t){d.start=d.last=between(d.start,coordinates(e,t));if(e.type==='touchmove')
panStartedState.touchmove(d,e,t);},touchmove:function(d,e,t){if(t.identifier!==d.touch1)
return;var current=coordinates(e,t);d.emitEvent('pan',{absolute:{dx:current.screenX-d.start.screenX,dy:current.screenY-d.start.screenY},relative:{dx:current.screenX-d.last.screenX,dy:current.screenY-d.last.screenY},position:current});var dt=current.timeStamp-d.last.timeStamp;var vx=(current.screenX-d.last.screenX)/dt;var vy=(current.screenY-d.last.screenY)/dt;if(d.vx==null){d.vx=vx;d.vy=vy;}
else{d.vx=d.vx*GD.VELOCITY_SMOOTHING+
vx*(1-GD.VELOCITY_SMOOTHING);d.vy=d.vy*GD.VELOCITY_SMOOTHING+
vy*(1-GD.VELOCITY_SMOOTHING);}
d.last=current;},touchend:function(d,e,t){if(t.identifier!==d.touch1)
return;var current=coordinates(e,t);var dx=current.screenX-d.start.screenX;var dy=current.screenY-d.start.screenY;var angle=atan2(dy,dx)*180/PI;if(angle<0)
angle+=360;var direction;if(angle>=315||angle<45)
direction='right';else if(angle>=45&&angle<135)
direction='down';else if(angle>=135&&angle<225)
direction='left';else if(angle>=225&&angle<315)
direction='up';d.emitEvent('swipe',{start:d.start,end:current,dx:dx,dy:dy,dt:e.timeStamp-d.start.timeStamp,vx:d.vx,vy:d.vy,direction:direction,angle:angle});d.switchTo(initialState);}};var holdState={name:'holdState',init:function(d){d.emitEvent('holdstart',d.start);},touchmove:function(d,e,t){var current=coordinates(e,t);d.emitEvent('holdmove',{absolute:{dx:current.screenX-d.start.screenX,dy:current.screenY-d.start.screenY},relative:{dx:current.screenX-d.last.screenX,dy:current.screenY-d.last.screenY},position:current});d.last=current;},touchend:function(d,e,t){var current=coordinates(e,t);d.emitEvent('holdend',{start:d.start,end:current,dx:current.screenX-d.start.screenX,dy:current.screenY-d.start.screenY});d.switchTo(initialState);}};var transformState={name:'transformState',init:function(d,e,t){d.touch2=t.identifier;var t1=e.touches.identifiedTouch(d.touch1);var t2=e.touches.identifiedTouch(d.touch2);d.startDistance=d.lastDistance=touchDistance(t1,t2);d.startDirection=d.lastDirection=touchDirection(t1,t2);d.scaled=d.rotated=false;},touchmove:function(d,e,t){if(t.identifier!==d.touch1&&t.identifier!==d.touch2)
return;var t1=e.touches.identifiedTouch(d.touch1);var t2=e.touches.identifiedTouch(d.touch2);var midpoint=midpoints(e,t1,t2);var distance=touchDistance(t1,t2);var direction=touchDirection(t1,t2);var rotation=touchRotation(d.startDirection,direction);if(!d.scaled){if(abs(distance-d.startDistance)>GD.SCALE_THRESHOLD){d.scaled=true;d.startDistance=d.lastDistance=floor(d.startDistance+
GD.THRESHOLD_SMOOTHING*(distance-d.startDistance));}
else
distance=d.startDistance;}
if(!d.rotated){if(abs(rotation)>GD.ROTATE_THRESHOLD)
d.rotated=true;else
direction=d.startDirection;}
if(d.scaled||d.rotated){d.emitEvent('transform',{absolute:{scale:distance/d.startDistance,rotate:touchRotation(d.startDirection,direction)},relative:{scale:distance/d.lastDistance,rotate:touchRotation(d.lastDirection,direction)},midpoint:midpoint});d.lastDistance=distance;d.lastDirection=direction;d.lastMidpoint=midpoint;}},touchend:function(d,e,t){if(t.identifier===d.touch2)
d.touch2=null;else if(t.identifier===d.touch1){d.touch1=d.touch2;d.touch2=null;}
else
return;if(d.scaled||d.rotated){d.emitEvent('transformend',{absolute:{scale:d.lastDistance/d.startDistance,rotate:touchRotation(d.startDirection,d.lastDirection)},relative:{scale:1,rotate:0},midpoint:d.lastMidpoint});}
d.switchTo(afterTransformState);}};var afterTransformState={name:'afterTransformState',touchstart:function(d,e,t){d.switchTo(transformState,e,t);},touchend:function(d,e,t){if(t.identifier===d.touch1)
d.switchTo(initialState);}};var mouseDownState={name:'mouseDownState',init:function(d,e){d.target=e.target;var doc=d.element.ownerDocument;doc.addEventListener('mousemove',d,true);doc.addEventListener('mouseup',d,true);d.start=d.last=mouseCoordinates(e);if(d.options.holdEvents)
d.startTimer('holdtimeout',GD.HOLD_INTERVAL);},mousemove:function(d,e){if(abs(e.screenX-d.start.screenX)>GD.MOUSE_PAN_THRESHOLD||abs(e.screenY-d.start.screenY)>GD.MOUSE_PAN_THRESHOLD){d.clearTimer('holdtimeout');d.switchTo(mousePannedState,e);}},mouseup:function(d,e){var doc=d.element.ownerDocument;doc.removeEventListener('mousemove',d,true);doc.removeEventListener('mouseup',d,true);if(d.lastTap&&isDoubleTap(d.lastTap,d.start)){d.emitEvent('tap',d.start);d.emitEvent('dbltap',d.start);d.lastTap=null;}
else{d.emitEvent('tap',d.start);d.lastTap=mouseCoordinates(e);}
d.clearTimer('holdtimeout');d.switchTo(initialState);},holdtimeout:function(d){d.switchTo(mouseHoldState);}};var mouseHoldState={name:'mouseHoldState',init:function(d){d.emitEvent('holdstart',d.start);},mousemove:function(d,e){var current=mouseCoordinates(e);d.emitEvent('holdmove',{absolute:{dx:current.screenX-d.start.screenX,dy:current.screenY-d.start.screenY},relative:{dx:current.screenX-d.last.screenX,dy:current.screenY-d.last.screenY},position:current});d.last=current;},mouseup:function(d,e){var current=mouseCoordinates(e);d.emitEvent('holdend',{start:d.start,end:current,dx:current.screenX-d.start.screenX,dy:current.screenY-d.start.screenY});d.switchTo(initialState);}};var mousePannedState={name:'mousePannedState',init:function(d,e){d.start=d.last=between(d.start,mouseCoordinates(e));if(e.type==='mousemove')
mousePannedState.mousemove(d,e);},mousemove:function(d,e){var current=mouseCoordinates(e);d.emitEvent('pan',{absolute:{dx:current.screenX-d.start.screenX,dy:current.screenY-d.start.screenY},relative:{dx:current.screenX-d.last.screenX,dy:current.screenY-d.last.screenY},position:current});var dt=current.timeStamp-d.last.timeStamp;var vx=(current.screenX-d.last.screenX)/dt;var vy=(current.screenY-d.last.screenY)/dt;if(d.vx==null){d.vx=vx;d.vy=vy;}
else{d.vx=d.vx*GD.VELOCITY_SMOOTHING+
vx*(1-GD.VELOCITY_SMOOTHING);d.vy=d.vy*GD.VELOCITY_SMOOTHING+
vy*(1-GD.VELOCITY_SMOOTHING);}
d.last=current;},mouseup:function(d,e){var doc=d.element.ownerDocument;doc.removeEventListener('mousemove',d,true);doc.removeEventListener('mouseup',d,true);var current=mouseCoordinates(e);var dx=current.screenX-d.start.screenX;var dy=current.screenY-d.start.screenY;var angle=atan2(dy,dx)*180/PI;if(angle<0)
angle+=360;var direction;if(angle>=315||angle<45)
direction='right';else if(angle>=45&&angle<135)
direction='down';else if(angle>=135&&angle<225)
direction='left';else if(angle>=225&&angle<315)
direction='up';d.emitEvent('swipe',{start:d.start,end:current,dx:dx,dy:dy,dt:current.timeStamp-d.start.timeStamp,vx:d.vx,vy:d.vy,direction:direction,angle:angle});d.switchTo(initialState);}};return GD;}());;'use strict';(function(){if(MouseEventShim)
return;try{document.createEvent('TouchEvent');}catch(e){return;}
var starttouch;var target;var emitclick;window.addEventListener('mousedown',discardEvent,true);window.addEventListener('mouseup',discardEvent,true);window.addEventListener('mousemove',discardEvent,true);window.addEventListener('click',discardEvent,true);function discardEvent(e){if(e.isTrusted){e.stopImmediatePropagation();if(e.type==='click')
e.preventDefault();}}
window.addEventListener('touchstart',handleTouchStart);window.addEventListener('touchmove',handleTouchMove);window.addEventListener('touchend',handleTouchEnd);window.addEventListener('touchcancel',handleTouchEnd);function handleTouchStart(e){if(starttouch)
return;if(e.defaultPrevented)
return;try{e.changedTouches[0].target.ownerDocument;}
catch(e){return;}
starttouch=e.changedTouches[0];target=starttouch.target;emitclick=true;emitEvent('mousemove',target,starttouch);var result=emitEvent('mousedown',target,starttouch);if(!result){e.preventDefault();emitclick=false;}}
function handleTouchEnd(e){if(!starttouch)
return;if(MouseEventShim.capturing){MouseEventShim.capturing=false;MouseEventShim.captureTarget=null;}
for(var i=0;i<e.changedTouches.length;i++){var touch=e.changedTouches[i];if(touch.identifier!==starttouch.identifier)
continue;emitEvent('mouseup',target,touch);if(emitclick)
emitEvent('click',starttouch.target,touch);starttouch=null;return;}}
function handleTouchMove(e){if(!starttouch)
return;for(var i=0;i<e.changedTouches.length;i++){var touch=e.changedTouches[i];if(touch.identifier!==starttouch.identifier)
continue;if(e.defaultPrevented)
return;var dx=Math.abs(touch.screenX-starttouch.screenX);var dy=Math.abs(touch.screenY-starttouch.screenY);if(dx>MouseEventShim.dragThresholdX||dy>MouseEventShim.dragThresholdY){emitclick=false;}
var tracking=MouseEventShim.trackMouseMoves&&!MouseEventShim.capturing;if(tracking){var oldtarget=target;var newtarget=document.elementFromPoint(touch.clientX,touch.clientY);if(newtarget===null){newtarget=oldtarget;}
if(newtarget!==oldtarget){leave(oldtarget,newtarget,touch);target=newtarget;}}
else if(MouseEventShim.captureTarget){target=MouseEventShim.captureTarget;}
emitEvent('mousemove',target,touch);if(tracking&&newtarget!==oldtarget){enter(newtarget,oldtarget,touch);}}}
function contains(a,b){return(a.compareDocumentPosition(b)&16)!==0;}
function leave(oldtarget,newtarget,touch){emitEvent('mouseout',oldtarget,touch,newtarget);for(var e=oldtarget;!contains(e,newtarget);e=e.parentNode){emitEvent('mouseleave',e,touch,newtarget);}}
function enter(newtarget,oldtarget,touch){emitEvent('mouseover',newtarget,touch,oldtarget);for(var e=newtarget;!contains(e,oldtarget);e=e.parentNode){emitEvent('mouseenter',e,touch,oldtarget);}}
function emitEvent(type,target,touch,relatedTarget){var synthetic=document.createEvent('MouseEvents');var bubbles=(type!=='mouseenter'&&type!=='mouseleave');var count=(type==='mousedown'||type==='mouseup'||type==='click')?1:0;synthetic.initMouseEvent(type,bubbles,true,window,count,touch.screenX,touch.screenY,touch.clientX,touch.clientY,false,false,false,false,0,relatedTarget||null);try{return target.dispatchEvent(synthetic);}
catch(e){console.warn('Exception calling dispatchEvent',type,e);return true;}}}());var MouseEventShim={getEventTimestamp:function(e){if(e.isTrusted)
return e.timeStamp;else
return e.timeStamp/1000;},trackMouseMoves:true,setCapture:function(target){this.capturing=true;if(target)
this.captureTarget=target;},capturing:false,dragThresholdX:25,dragThresholdY:25};;'use strict';this.asyncStorage=(function(){var DBNAME='asyncStorage';var DBVERSION=1;var STORENAME='keyvaluepairs';var db=null;function withStore(type,f){if(db){f(db.transaction(STORENAME,type).objectStore(STORENAME));}else{var openreq=indexedDB.open(DBNAME,DBVERSION);openreq.onerror=function withStoreOnError(){console.error("asyncStorage: can't open database:",openreq.error.name);};openreq.onupgradeneeded=function withStoreOnUpgradeNeeded(){openreq.result.createObjectStore(STORENAME);};openreq.onsuccess=function withStoreOnSuccess(){db=openreq.result;f(db.transaction(STORENAME,type).objectStore(STORENAME));};}}
function getItem(key,callback){withStore('readonly',function getItemBody(store){var req=store.get(key);req.onsuccess=function getItemOnSuccess(){var value=req.result;if(value===undefined)
value=null;callback(value);};req.onerror=function getItemOnError(){console.error('Error in asyncStorage.getItem(): ',req.error.name);};});}
function setItem(key,value,callback){withStore('readwrite',function setItemBody(store){var req=store.put(value,key);if(callback){req.onsuccess=function setItemOnSuccess(){callback();};}
req.onerror=function setItemOnError(){console.error('Error in asyncStorage.setItem(): ',req.error.name);};});}
function removeItem(key,callback){withStore('readwrite',function removeItemBody(store){var req=store.delete(key);if(callback){req.onsuccess=function removeItemOnSuccess(){callback();};}
req.onerror=function removeItemOnError(){console.error('Error in asyncStorage.removeItem(): ',req.error.name);};});}
function clear(callback){withStore('readwrite',function clearBody(store){var req=store.clear();if(callback){req.onsuccess=function clearOnSuccess(){callback();};}
req.onerror=function clearOnError(){console.error('Error in asyncStorage.clear(): ',req.error.name);};});}
function length(callback){withStore('readonly',function lengthBody(store){var req=store.count();req.onsuccess=function lengthOnSuccess(){callback(req.result);};req.onerror=function lengthOnError(){console.error('Error in asyncStorage.length(): ',req.error.name);};});}
function key(n,callback){if(n<0){callback(null);return;}
withStore('readonly',function keyBody(store){var advanced=false;var req=store.openCursor();req.onsuccess=function keyOnSuccess(){var cursor=req.result;if(!cursor){callback(null);return;}
if(n===0){callback(cursor.key);}else{if(!advanced){advanced=true;cursor.advance(n);}else{callback(cursor.key);}}};req.onerror=function keyOnError(){console.error('Error in asyncStorage.key(): ',req.error.name);};});}
return{getItem:getItem,setItem:setItem,removeItem:removeItem,clear:clear,length:length,key:key};}());;'use strict';function escapeHTML(str,escapeQuotes){var span=document.createElement('span');span.textContent=str;if(escapeQuotes)
return span.innerHTML.replace(/"/g,'&quot;').replace(/'/g,'&#x27;');return span.innerHTML;}
function summarizeDaysOfWeek(bitStr){var _=navigator.mozL10n.get;if(bitStr=='')
return _('never');var summary='';switch(bitStr){case'1111111':summary=_('everyday');break;case'1111100':summary=_('weekdays');break;case'0000011':summary=_('weekends');break;case'0000000':summary=_('never');break;default:var weekdays=[];for(var i=0;i<bitStr.length;i++){if(bitStr.substr(i,1)=='1'){weekdays.push(_('weekday-'+((i+1)%7)+'-short'));}}
summary=weekdays.join(', ');}
return summary;}
function is12hFormat(){var localeTimeFormat=navigator.mozL10n.get('dateTimeFormat_%X');var is12h=(localeTimeFormat.indexOf('%p')>=0);return is12h;}
function getLocaleTime(d){var f=new navigator.mozL10n.DateTimeFormat();var is12h=is12hFormat();return{t:f.localeFormat(d,(is12h?'%I:%M':'%H:%M')).replace(/^0/,''),p:is12h?f.localeFormat(d,'%p'):''};}
function isAlarmPassToday(hour,minute){var now=new Date();if(hour>now.getHours()||(hour==now.getHours()&&minute>now.getMinutes())){return false;}
return true;}
function getNextAlarmFireTime(alarm){var repeat=alarm.repeat;var hour=alarm.hour;var minute=alarm.minute;var now=new Date();var nextAlarmFireTime=new Date();var diffDays=0;if(repeat=='0000000'){if(isAlarmPassToday(hour,minute))
diffDays=1;}else{var weekDayFormatRepeat=repeat.slice(-1).concat(repeat.slice(0,repeat.length-1));var weekDayOfToday=now.getDay();var index=0;for(var i=0;i<weekDayFormatRepeat.length;i++){index=(i+weekDayOfToday)%7;if(weekDayFormatRepeat.charAt(index)=='1'){if(diffDays==0){if(!isAlarmPassToday(hour,minute))
break;diffDays++;continue;}
break;}
diffDays++;}}
nextAlarmFireTime.setDate(nextAlarmFireTime.getDate()+diffDays);nextAlarmFireTime.setHours(hour);nextAlarmFireTime.setMinutes(minute);nextAlarmFireTime.setSeconds(0,0);return nextAlarmFireTime;}
function changeSelectByValue(selectElement,value){var options=selectElement.options;for(var i=0;i<options.length;i++){if(options[i].value==value){if(selectElement.selectedIndex!=i){selectElement.selectedIndex=i;}
break;}}}
function getSelectedValue(selectElement){return selectElement.options[selectElement.selectedIndex].value;}
function formatTime(hour,minute){var period='';if(is12hFormat()){period=hour<12?'AM':'PM';hour=hour%12;hour=(hour==0)?12:hour;}
if(hour==0){hour='00';}
if(minute<10){minute='0'+minute;}
return hour+':'+minute+period;}
function parseTime(time){var parsed=time.split(':');var hour=+parsed[0];var minute=parsed[1];var periodIndex=minute.indexOf('M')-1;if(periodIndex>=0){hour=(hour==12)?0:hour;hour+=(minute.slice(periodIndex)=='PM')?12:0;minute=minute.slice(0,periodIndex);}
return{hour:hour,minute:+minute};};'use strict';function extend(destination,source){for(var k in source){if(source.hasOwnProperty(k)){destination[k]=source[k];}}
return destination;}
var BaseIndexDB=function(objectStoreOptions){this.query=function ad_query(dbName,storeName,func,callback,data){var indexedDB=window.indexedDB||window.webkitIndexedDB||window.mozIndexedDB||window.msIndexedDB;var request=indexedDB.open(dbName,5);request.onsuccess=function(event){func(request.result,storeName,callback,data);};request.onerror=function(event){console.error('Can\'t open database',dbName,event);};request.onupgradeneeded=function(event){console.log('Upgrading db');var db=event.target.result;if(db.objectStoreNames.contains(storeName))
db.deleteObjectStore(storeName);db.createObjectStore(storeName,objectStoreOptions);console.log('Upgrading db done');};};this.put=function ad_put(database,storeName,callback,item){var txn=database.transaction(storeName,'readwrite');var store=txn.objectStore(storeName);var putreq=store.put(item);putreq.onsuccess=function(event){item.id=event.target.result;if(typeof callback==='function')
callback(item);};putreq.onerror=function(e){console.error('Add operation failure: ',database.name,storeName,e.message,putreq.errorCode);};};this.load=function ad_load(database,storeName,callback){if(typeof callback!=='function')
callback=function(){};var alarms=[];var txn=database.transaction(storeName);var store=txn.objectStore(storeName);var cursor=store.openCursor(null,'prev');cursor.onsuccess=function(event){var item=event.target.result;if(item){alarms.push(item.value);item.continue();}else{callback(alarms);}};cursor.onerror=function(event){callback([]);};};this.get=function ad_get(database,storeName,callback,key){if(typeof callback!=='function')
callback=function(){};var txn=database.transaction(storeName);var store=txn.objectStore(storeName);var request=store.get(key);request.onsuccess=function(event){callback(request.result);};request.onerror=function(event){console.error('Get operation failure: ',database.name,storeName,event.message,request.errorCode);};};this.delete=function ad_delete(database,storeName,callback,key){if(typeof callback!=='function')
callback=function(){};var txn=database.transaction(storeName,'readwrite');var store=txn.objectStore(storeName);var request=store.delete(key);request.onsuccess=callback;request.onerror=function(e){console.error('Delete operation failure: ',database.name,storeName,e.message,request.errorCode);};};};var AlarmsDB={DBNAME:'alarms',STORENAME:'alarms',getAlarmList:function ad_getAlarmList(callback){this.query(this.DBNAME,this.STORENAME,this.load,callback);},putAlarm:function ad_putAlarm(alarm,callback){this.query(this.DBNAME,this.STORENAME,this.put,callback,alarm);},getAlarm:function ad_getAlarm(key,callback){this.query(this.DBNAME,this.STORENAME,this.get,callback,key);},deleteAlarm:function ad_deleteAlarm(key,callback){this.query(this.DBNAME,this.STORENAME,this.delete,callback,key);}};extend(AlarmsDB,new BaseIndexDB({keyPath:'id',autoIncrement:true}));;'use strict';window.addEventListener('localized',function localized(){document.documentElement.lang=navigator.mozL10n.language.code;document.documentElement.dir=navigator.mozL10n.language.direction;ClockView.init();AlarmList.init();BannerView.init();ActiveAlarmController.init();});;'use strict';var _=navigator.mozL10n.get;var SETTINGS_CLOCKMODE='settings_clockoptions_mode';var ClockView={_clockMode:null,_analogGestureDetector:null,_digitalGestureDetector:null,get digitalClock(){delete this.digitalClock;return this.digitalClock=document.getElementById('digital-clock');},get analogClock(){delete this.analogClock;return this.analogClock=document.getElementById('analog-clock');},get time(){delete this.time;return this.time=document.getElementById('clock-time');},get hourState(){delete this.hourState;return this.hourState=document.getElementById('clock-hour24-state');},get dayDate(){delete this.dayDate;return this.dayDate=document.getElementById('clock-day-date');},get alarmNewBtn(){delete this.alarmNewBtn;return this.alarmNewBtn=document.getElementById('alarm-new');},get digitalClockBackground(){delete this.digitalClockBackground;return this.digitalClockBackground=document.getElementById('digital-clock-background');},init:function cv_init(){this.container=document.getElementById('analog-clock-container');document.addEventListener('mozvisibilitychange',this);this.updateDaydate();this.initClockface();},initClockface:function cv_initClockface(){var self=this;this._analogGestureDetector=new GestureDetector(this.analogClock);this.analogClock.addEventListener('tap',this);this._digitalGestureDetector=new GestureDetector(this.digitalClock);this.digitalClock.addEventListener('tap',this);asyncStorage.getItem(SETTINGS_CLOCKMODE,function(mode){switch(mode){case'digital':self.showDigitalClock();break;default:self.showAnalogClock();break;}});},updateDaydate:function cv_updateDaydate(){var d=new Date();var f=new navigator.mozL10n.DateTimeFormat();var format=navigator.mozL10n.get('dateFormat');var formated=f.localeFormat(d,format);this.dayDate.innerHTML=formated.replace(/([0-9]+)/,'<b>$1</b>');var self=this;var remainMillisecond=(24-d.getHours())*3600*1000-
d.getMinutes()*60*1000-
d.getMilliseconds();this._updateDaydateTimeout=window.setTimeout(function cv_updateDaydateTimeout(){self.updateDaydate();},remainMillisecond);},updateDigitalClock:function cv_updateDigitalClock(){var d=new Date();var time=getLocaleTime(d);this.time.textContent=time.t;this.hourState.textContent=time.p||'  ';var self=this;this._updateDigitalClockTimeout=window.setTimeout(function cv_updateDigitalClockTimeout(){self.updateDigitalClock();},(59-d.getSeconds())*1000);},updateAnalogClock:function cv_updateAnalogClock(){var now=new Date();var sec=now.getSeconds();var min=now.getMinutes();var hour=(now.getHours()%12)+min/60;var lastHour=(now.getHours()-1%12)+min/60;this.setTransform('secondhand',sec*6,(sec-1)*6);this.setTransform('minutehand',min*6-180,(min-1)*6-180);this.setTransform('hourhand',hour*30-180,(lastHour)*30-180);var self=this;this._updateAnalogClockTimeout=window.setTimeout(function cv_updateAnalogClockTimeout(){self.updateAnalogClock();},(1000-now.getMilliseconds()));},setTransform:function cv_setTransform(id,angle,from){!this.rotation&&(this.rotation={});var hand=document.getElementById(id);if(!this.rotation[id]){this.rotation[id]=document.createElementNS('http://www.w3.org/2000/svg','animateTransform');}
if(!hand){return;}
var rotate=this.rotation[id];if(rotate.getAttribute('to')==angle+',135,135')
return;rotate.setAttribute('attributeName','transform');rotate.setAttribute('attributeType','xml');rotate.setAttribute('type','rotate');rotate.setAttribute('from',from+',135,135');rotate.setAttribute('to',angle+',135,135');rotate.setAttribute('dur','0.001s');rotate.setAttribute('fill','freeze');hand.appendChild(rotate);},handleEvent:function cv_handleEvent(evt){switch(evt.type){case'mozvisibilitychange':if(document.mozHidden){if(this._updateDaydateTimeout){window.clearTimeout(this._updateDaydateTimeout);}
if(this._updateDigitalClockTimeout){window.clearTimeout(this._updateDigitalClockTimeout);}
if(this._updateAnalogClockTimeout){window.clearTimeout(this._updateAnalogClockTimeout);}
return;}else if(!document.mozHidden){this.updateDaydate();if(this._clockMode==='digital'){this.updateDigitalClock();}else if(this._clockMode==='analog'){this.updateAnalogClock();}}
break;case'tap':var input=evt.target;if(!input)
return;switch(input.id){case'digital-clock-display':this.showAnalogClock();break;case'analog-clock-svg':this.showDigitalClock();break;}
break;}},showAnalogClock:function cv_showAnalogClock(){if(this._clockMode!=='analog')
asyncStorage.setItem(SETTINGS_CLOCKMODE,'analog');if(this._updateDigitalClockTimeout){window.clearTimeout(this._updateDigitalClockTimeout);}
this.digitalClock.classList.remove('visible');this.digitalClockBackground.classList.remove('visible');this.resizeAnalogClock();this.updateAnalogClock();this._clockMode='analog';this.analogClock.classList.add('visible');this._analogGestureDetector.startDetecting();this._digitalGestureDetector.stopDetecting();},showDigitalClock:function cv_showDigitalClock(){if(this._clockMode!=='digital')
asyncStorage.setItem(SETTINGS_CLOCKMODE,'digital');if(this._updateDigitalClockTimeout){window.clearTimeout(this._updateAnalogClockTimeout);}
this.analogClock.classList.remove('visible');this.updateDigitalClock();this._clockMode='digital';this.digitalClock.classList.add('visible');this.digitalClockBackground.classList.add('visible');this._digitalGestureDetector.startDetecting();this._analogGestureDetector.stopDetecting();},calAnalogClockType:function cv_calAnalogClockType(count){if(count<=1){count=1;}else if(count>=4){count=4;}
return count;},resizeAnalogClock:function cv_resizeAnalogClock(){var type=this.calAnalogClockType(AlarmList.getAlarmCount());this.container.className='marks'+type;document.getElementById('alarms').className='count'+type;},showHideAlarmSetIndicator:function cv_showHideAlarmSetIndicator(enabled){if(enabled){this.hourState.classList.add('alarm-set-indicator');}else{this.hourState.classList.remove('alarm-set-indicator');}},hide:function cv_hide(){var self=this;setTimeout(function(){self.digitalClock.className='';self.analogClock.className='';},500);},show:function cv_show(){window.location.hash='alarm-view';var self=this;self.digitalClock.className='';self.analogClock.className='';if(self._clockMode==='analog'){self.analogClock.className='visible';}else{self.digitalClock.className='visible';}}};var BannerView={_remainHours:0,_remainMinutes:0,get bannerCountdown(){delete this.bannerCountdown;return this.bannerCountdown=document.getElementById('banner-countdown');},init:function BV_init(){this.bannerCountdown.addEventListener('click',this);},handleEvent:function al_handleEvent(evt){this.hideBannerStatus();},calRemainTime:function BV_calRemainTime(targetTime){var now=new Date();var remainTime=targetTime.getTime()-now.getTime();this._remainHours=Math.floor(remainTime/(60*60*1000));this._remainMinutes=Math.floor((remainTime/(60*1000))-
(this._remainHours*60));},setStatus:function BV_setStatus(nextAlarmFireTime){this.calRemainTime(nextAlarmFireTime);var innerHTML='';if(this._remainHours===0){innerHTML=_('countdown-lessThanAnHour',{minutes:_('nMinutes',{n:this._remainMinutes})});}else if(this._remainHours<24){innerHTML=_('countdown-moreThanAnHour',{hours:_('nHours',{n:this._remainHours}),minutes:_('nRemainMinutes',{n:this._remainMinutes})});}else{var remainDays=Math.floor(this._remainHours/24);var remainHours=this._remainHours-(remainDays*24);innerHTML=_('countdown-moreThanADay',{days:_('nRemainDays',{n:remainDays}),hours:_('nRemainHours',{n:remainHours})});}
this.bannerCountdown.innerHTML='<p>'+innerHTML+'</p>';this.showBannerStatus();var self=this;window.setTimeout(function cv_hideBannerTimeout(){self.setBannerStatus(false);},4000);},setBannerStatus:function BV_setBannerStatus(visible){if(visible){this.bannerCountdown.classList.add('visible');}else{this.bannerCountdown.classList.remove('visible');}},showBannerStatus:function BV_showBannerStatus(){this.setBannerStatus(true);},hideBannerStatus:function BV_hideBannerStatus(){this.setBannerStatus(false);}};var AlarmList={alarmList:[],refreshingAlarms:[],_previousAlarmCount:0,get alarms(){delete this.alarms;return this.alarms=document.getElementById('alarms');},get title(){delete this.title;return this.title=document.getElementById('alarms-title');},get newAlarmButton(){delete this.newAlarmButton;return this.newAlarmButton=document.getElementById('alarm-new');},handleEvent:function al_handleEvent(evt){var link=evt.target;if(!link)
return;if(link===this.newAlarmButton){ClockView.hide();AlarmEditView.load();}else if(link.classList.contains('input-enable')){this.toggleAlarmEnableState(link.checked,this.getAlarmFromList(parseInt(link.dataset.id,10)));}else if(link.classList.contains('alarm-item')){ClockView.hide();AlarmEditView.load(this.getAlarmFromList(parseInt(link.dataset.id,10)));}},init:function al_init(){this.newAlarmButton.addEventListener('click',this);this.alarms.addEventListener('click',this);this.refresh();AlarmManager.regUpdateAlarmEnableState(this.refreshItem.bind(this));},refresh:function al_refresh(){var self=this;AlarmManager.getAlarmList(function al_gotAlarmList(list){self.fillList(list);});},buildAlarmContent:function al_buildAlarmContent(alarm){var summaryRepeat=(alarm.repeat==='0000000')?'':summarizeDaysOfWeek(alarm.repeat);var isChecked=alarm.enabled?' checked="true"':'';var d=new Date();d.setHours(alarm.hour);d.setMinutes(alarm.minute);var time=getLocaleTime(d);var label=(alarm.label==='')?_('alarm'):escapeHTML(alarm.label);return'<label class="alarmList alarmEnable">'+'  <input class="input-enable"'+'" data-id="'+alarm.id+'" type="checkbox"'+isChecked+'>'+'  <span></span>'+'</label>'+'<a href="#alarm" class="alarm-item" data-id="'+alarm.id+'">'+'  <span class="time">'+
time.t+'<span class="period">'+time.p+'</span>'+'  </span>'+'  <span class="label">'+label+'</span>'+'  <span class="repeat">'+summaryRepeat+'</span>'+'</a>';},refreshItem:function al_refreshItem(alarm){this.setAlarmFromList(alarm.id,alarm);var id='a[data-id="'+alarm.id+'"]';var alarmItem=this.alarms.querySelector(id);alarmItem.parentNode.innerHTML=this.buildAlarmContent(alarm);var index=this.refreshingAlarms.indexOf(alarm.id);this.refreshingAlarms.splice(index,1);},fillList:function al_fillList(alarmDataList){this.alarmList=alarmDataList;var content='';this.alarms.innerHTML='';alarmDataList.forEach(function al_fillEachList(alarm){var li=document.createElement('li');li.className='alarm-cell';li.innerHTML=this.buildAlarmContent(alarm);this.alarms.appendChild(li);}.bind(this));if(this._previousAlarmCount!==this.getAlarmCount()){this._previousAlarmCount=this.getAlarmCount();ClockView.resizeAnalogClock();}},getAlarmFromList:function al_getAlarmFromList(id){for(var i=0;i<this.alarmList.length;i++){if(this.alarmList[i].id===id)
return this.alarmList[i];}
return null;},setAlarmFromList:function al_setAlarmFromList(id,alarm){for(var i=0;i<this.alarmList.length;i++){if(this.alarmList[i].id===id){this.alarmList[i]=alarm;return;}}},getAlarmCount:function al_getAlarmCount(){return this.alarmList.length;},toggleAlarmEnableState:function al_toggleAlarmEnableState(enabled,alarm){if(this.refreshingAlarms.indexOf(alarm.id)!==-1){return;}
if(alarm.enabled===enabled)
return;alarm.enabled=enabled;this.refreshingAlarms.push(alarm.id);var self=this;AlarmManager.putAlarm(alarm,function al_putAlarm(alarm){if(!alarm.enabled&&!alarm.normalAlarmId&&!alarm.snoozeAlarmId){self.refreshItem(alarm);}else{AlarmManager.toggleAlarm(alarm,alarm.enabled);}});},deleteCurrent:function al_deleteCurrent(id){var alarm=this.getAlarmFromList(id);var self=this;AlarmManager.delete(alarm,function al_deleted(){self.refresh();});}};var ActiveAlarmController={_onFireAlarm:{},_onFireChildWindow:null,init:function am_init(){var self=this;navigator.mozSetMessageHandler('alarm',function gotMessage(message){self.onAlarmFiredHandler(message);});AlarmManager.updateAlarmStatusBar();},onAlarmFiredHandler:function aac_onAlarmFiredHandler(message){var cpuWakeLock=navigator.requestWakeLock('cpu');var unlockCpuWakeLock=function unlockCpuWakeLock(){if(cpuWakeLock){cpuWakeLock.unlock();cpuWakeLock=null;}};setTimeout(unlockCpuWakeLock,30000);var id=message.data.id;var type=message.data.type;var clearAlarmRequestId=function clearAlarmRequestId(alarm,callback){if(type==='normal'){alarm.normalAlarmId='';}else{alarm.snoozeAlarmId='';}
AlarmManager.putAlarm(alarm,function aac_putAlarm(alarmFromDB){if(type==='normal'&&alarmFromDB.repeat!=='0000000'&&callback){alarmFromDB.enabled=false;callback(alarmFromDB);}else{if(!alarmFromDB.normalAlarmId)
AlarmList.toggleAlarmEnableState(false,alarmFromDB);}});};var setRepeatAlarm=function setRepeatAlarm(alarm){AlarmList.toggleAlarmEnableState(true,alarm);};var self=this;AlarmManager.getAlarmById(id,function aac_gotAlarm(alarm){if(!alarm){unlockCpuWakeLock();return;}
clearAlarmRequestId(alarm,setRepeatAlarm);if(self._onFireChildWindow!==null&&typeof self._onFireChildWindow!=='undefined'&&!self._onFireChildWindow.closed){if(self._onFireChildWindow.RingView){self._onFireChildWindow.RingView.stopAlarmNotification();}}
self._onFireAlarm=alarm;var protocol=window.location.protocol;var host=window.location.host;self._onFireChildWindow=window.open(protocol+'//'+host+'/onring.html','ring_screen','attention');self._onFireChildWindow.onload=function childWindowLoaded(){unlockCpuWakeLock();};});AlarmManager.updateAlarmStatusBar();},snoozeHandler:function aac_snoozeHandler(){var id=this._onFireAlarm.id;AlarmManager.getAlarmById(id,function aac_gotAlarm(alarm){alarm.enabled=true;AlarmManager.putAlarm(alarm,function aac_putAlarm(alarm){AlarmManager.set(alarm,true);});});},getOnFireAlarm:function aac_getOnFireAlarm(){return this._onFireAlarm;}};var AlarmEditView={alarm:{},timePicker:{hour:null,minute:null,hour24State:null,is12hFormat:false},previewRingtonePlayer:null,get element(){delete this.element;return this.element=document.getElementById('alarm');},get scrollList(){delete this.scrollList;return this.scrollList=document.getElementById('edit-alarm');},get labelInput(){delete this.labelInput;return this.labelInput=document.querySelector('input[name="alarm.label"]');},get timeSelect(){delete this.timeSelect;return this.timeSelect=document.getElementById('time-select');},get timeMenu(){delete this.timeMenu;return this.timeMenu=document.getElementById('time-menu');},get alarmTitle(){delete this.alarmTitle;return this.alarmTitle=document.getElementById('alarm-title');},get repeatMenu(){delete this.repeatMenu;return this.repeatMenu=document.getElementById('repeat-menu');},get repeatSelect(){delete this.repeatSelect;return this.repeatSelect=document.getElementById('repeat-select');},get soundMenu(){delete this.soundMenu;return this.soundMenu=document.getElementById('sound-menu');},get soundSelect(){delete this.soundSelect;return this.soundSelect=document.getElementById('sound-select');},get vibrateMenu(){delete this.vibrateMenu;return this.vibrateMenu=document.getElementById('vibrate-menu');},get vibrateSelect(){delete this.vibrateSelect;return this.vibrateSelect=document.getElementById('vibrate-select');},get snoozeMenu(){delete this.snoozeMenu;return this.snoozeMenu=document.getElementById('snooze-menu');},get snoozeSelect(){delete this.snoozeSelect;return this.snoozeSelect=document.getElementById('snooze-select');},get deleteButton(){delete this.deleteButton;return this.deleteButton=document.getElementById('alarm-delete');},get backButton(){delete this.backElement;return this.backElement=document.getElementById('alarm-close');},get doneButton(){delete this.doneButton;return this.doneButton=document.getElementById('alarm-done');},init:function aev_init(){this.backButton.addEventListener('click',this);this.doneButton.addEventListener('click',this);this.timeMenu.addEventListener('click',this);this.timeSelect.addEventListener('blur',this);this.repeatMenu.addEventListener('click',this);this.repeatSelect.addEventListener('blur',this);this.soundMenu.addEventListener('click',this);this.soundSelect.addEventListener('change',this);this.soundSelect.addEventListener('blur',this);this.vibrateMenu.addEventListener('click',this);this.vibrateSelect.addEventListener('blur',this);this.snoozeMenu.addEventListener('click',this);this.snoozeSelect.addEventListener('blur',this);this.deleteButton.addEventListener('click',this);},handleEvent:function aev_handleEvent(evt){evt.preventDefault();var input=evt.target;if(!input)
return;switch(input){case this.backButton:ClockView.show();break;case this.doneButton:ClockView.show();if(!this.save()){evt.preventDefault();return;}
break;case this.timeMenu:this.focusMenu(this.timeSelect);break;case this.timeSelect:this.refreshTimeMenu(this.getTimeSelect());break;case this.repeatMenu:this.focusMenu(this.repeatSelect);break;case this.repeatSelect:this.refreshRepeatMenu(this.getRepeatSelect());break;case this.soundMenu:this.focusMenu(this.soundSelect);break;case this.soundSelect:switch(evt.type){case'change':this.refreshSoundMenu(this.getSoundSelect());this.previewSound();break;case'blur':this.stopPreviewSound();break;}
break;case this.vibrateMenu:this.focusMenu(this.vibrateSelect);break;case this.vibrateSelect:this.refreshVibrateMenu(this.getVibrateSelect());break;case this.snoozeMenu:this.focusMenu(this.snoozeSelect);break;case this.snoozeSelect:this.refreshSnoozeMenu(this.getSnoozeSelect());break;case this.deleteButton:ClockView.show();this.delete();break;}},focusMenu:function aev_focusMenu(menu){setTimeout(function(){menu.focus();},10);},getDefaultAlarm:function aev_getDefaultAlarm(){var now=new Date();return{id:'',normalAlarmId:'',snoozeAlarmId:'',label:'',hour:now.getHours(),minute:now.getMinutes(),enabled:true,repeat:'0000000',sound:'ac_classic_clock_alarm.opus',vibrate:1,snooze:5,color:'Darkorange'};},load:function aev_load(alarm){if(this.element.classList.contains('hidden')){this.element.classList.remove('hidden');this.init();}
this.scrollList.scrollTop=0;window.location.hash='alarm';if(!alarm){this.element.classList.add('new');this.alarmTitle.textContent=_('newAlarm');alarm=this.getDefaultAlarm();}else{this.element.classList.remove('new');this.alarmTitle.textContent=_('editAlarm');}
this.alarm=alarm;this.element.dataset.id=alarm.id;this.labelInput.value=alarm.label;this.initTimeSelect();this.refreshTimeMenu();this.initRepeatSelect();this.refreshRepeatMenu();this.initSoundSelect();this.refreshSoundMenu();this.initVibrateSelect();this.refreshVibrateMenu();this.initSnoozeSelect();this.refreshSnoozeMenu();},initTimeSelect:function aev_initTimeSelect(){this.timeSelect.value=this.alarm.hour+':'+this.alarm.minute;},getTimeSelect:function aev_getTimeSelect(){return parseTime(this.timeSelect.value);},refreshTimeMenu:function aev_refreshTimeMenu(time){if(!time){time=this.alarm;}
this.timeMenu.textContent=formatTime(time.hour,time.minute);},initRepeatSelect:function aev_initRepeatSelect(){var daysOfWeek=this.alarm.repeat;var options=this.repeatSelect.options;for(var i=0;i<options.length;i++){options[i].selected=(daysOfWeek.substr(i,1)==='1')?true:false;}},getRepeatSelect:function aev_getRepeatSelect(){var daysOfWeek='';var options=this.repeatSelect.options;for(var i=0;i<options.length;i++){daysOfWeek+=(options[i].selected)?'1':'0';}
return daysOfWeek;},refreshRepeatMenu:function aev_refreshRepeatMenu(repeatOpts){var daysOfWeek=(repeatOpts)?repeatOpts:this.alarm.repeat;this.repeatMenu.textContent=summarizeDaysOfWeek(daysOfWeek);},initSoundSelect:function aev_initSoundSelect(){changeSelectByValue(this.soundSelect,this.alarm.sound);},getSoundSelect:function aev_getSoundSelect(){return getSelectedValue(this.soundSelect);},refreshSoundMenu:function aev_refreshSoundMenu(sound){sound=(sound!==undefined)?sound:this.alarm.sound;this.soundMenu.textContent=(sound===0||sound==='0')?_('noSound'):_(sound.replace('.','_'));},previewSound:function aev_previewSound(){var ringtonePlayer=this.previewRingtonePlayer;if(!ringtonePlayer){this.previewRingtonePlayer=new Audio();ringtonePlayer=this.previewRingtonePlayer;}else{ringtonePlayer.pause();}
var ringtoneName=this.getSoundSelect();var previewRingtone='shared/resources/media/alarms/'+ringtoneName;ringtonePlayer.mozAudioChannelType='alarm';ringtonePlayer.src=previewRingtone;ringtonePlayer.play();},stopPreviewSound:function aev_stopPreviewSound(){if(this.previewRingtonePlayer)
this.previewRingtonePlayer.pause();},initVibrateSelect:function aev_initVibrateSelect(){changeSelectByValue(this.vibrateSelect,this.alarm.vibrate);},getVibrateSelect:function aev_getVibrateSelect(){return getSelectedValue(this.vibrateSelect);},refreshVibrateMenu:function aev_refreshVibrateMenu(vibrate){vibrate=(vibrate!==undefined)?vibrate:this.alarm.vibrate;this.vibrateMenu.textContent=(vibrate===0||vibrate==='0')?_('vibrateOff'):_('vibrateOn');},initSnoozeSelect:function aev_initSnoozeSelect(){changeSelectByValue(this.snoozeSelect,this.alarm.snooze);},getSnoozeSelect:function aev_getSnoozeSelect(){return getSelectedValue(this.snoozeSelect);},refreshSnoozeMenu:function aev_refreshSnoozeMenu(snooze){snooze=(snooze)?this.getSnoozeSelect():this.alarm.snooze;this.snoozeMenu.textContent=_('nMinutes',{n:snooze});},save:function aev_save(callback){if(this.element.dataset.id!==''){this.alarm.id=parseInt(this.element.dataset.id,10);}else{delete this.alarm.id;}
var error=false;this.alarm.label=this.labelInput.value;this.alarm.enabled=true;var time=this.getTimeSelect();this.alarm.hour=time.hour;this.alarm.minute=time.minute;this.alarm.repeat=this.getRepeatSelect();this.alarm.sound=this.getSoundSelect();this.alarm.vibrate=this.getVibrateSelect();this.alarm.snooze=parseInt(this.getSnoozeSelect(),10);if(!error){AlarmManager.putAlarm(this.alarm,function al_putAlarmList(alarm){AlarmManager.toggleAlarm(alarm,alarm.enabled);AlarmList.refresh();callback&&callback(alarm);});}
return!error;},delete:function aev_delete(callback){if(!this.element.dataset.id)
return;var alarm=this.alarm;AlarmManager.delete(alarm,function aev_delete(){AlarmList.refresh();callback&&callback(alarm);});}};;var AlarmManager={toggleAlarm:function am_toggleAlarm(alarm,enabled,callback){if(enabled){this.set(alarm,false,callback);}else{this.unset(alarm,callback);}},set:function am_set(alarm,bSnooze,callback){if(!bSnooze){this.unset(alarm);}
var nextAlarmFireTime=null;if(bSnooze){nextAlarmFireTime=new Date();nextAlarmFireTime.setMinutes(nextAlarmFireTime.getMinutes()+
alarm.snooze);}else{nextAlarmFireTime=getNextAlarmFireTime(alarm);}
if(!navigator.mozAlarms)
return;var type=bSnooze?'snooze':'normal';var data={id:alarm.id,type:type};var request=navigator.mozAlarms.add(nextAlarmFireTime,'ignoreTimezone',data);var self=this;request.onsuccess=function(e){if(bSnooze){alarm.snoozeAlarmId=e.target.result;}else{alarm.normalAlarmId=e.target.result;}
AlarmsDB.putAlarm(alarm,function am_putAlarm(alarm){if(self._updateAlarmEableStateHandler)
self._updateAlarmEableStateHandler(alarm);if(callback)
callback(alarm);});self.updateAlarmStatusBar();BannerView.setStatus(nextAlarmFireTime);};request.onerror=function(e){console.log('onerror!!!!');var logInfo=bSnooze?' snooze':'';console.log('set'+logInfo+' alarm fail');};},unset:function am_unset(alarm,callback){var isNeedToUpdateAlarmDB=false;if(alarm.normalAlarmId){navigator.mozAlarms.remove(alarm.normalAlarmId);alarm.normalAlarmId='';isNeedToUpdateAlarmDB=true;}
if(alarm.snoozeAlarmId){navigator.mozAlarms.remove(alarm.snoozeAlarmId);alarm.snoozeAlarmId='';isNeedToUpdateAlarmDB=true;}
if(isNeedToUpdateAlarmDB){var self=this;AlarmsDB.putAlarm(alarm,function am_putAlarm(alarm){if(self._updateAlarmEableStateHandler)
self._updateAlarmEableStateHandler(alarm);if(callback)
callback(alarm);});this.updateAlarmStatusBar();}},delete:function am_delete(alarm,callback){if(alarm.normalAlarmId||alarm.snoozeAlarmId)
this.toggleAlarm(alarm,false);var self=this;AlarmsDB.deleteAlarm(alarm.id,function am_deletedAlarm(){if(callback)
callback();});},getAlarmList:function am_getAlarmList(callback){AlarmsDB.getAlarmList(function am_gotAlarmList(list){if(callback)
callback(list);});},getAlarmById:function am_getAlarmById(id,callback){AlarmsDB.getAlarm(id,function am_gotAlarm(alarm){if(callback)
callback(alarm);});},putAlarm:function am_putAlarm(alarm,callback){AlarmsDB.putAlarm(alarm,function am_putAlarm(alarm){if(callback)
callback(alarm);});},updateAlarmStatusBar:function am_updateAlarmStatusBar(){if(!('mozSettings'in navigator))
return;if(!navigator.mozAlarms)
return;var request=navigator.mozAlarms.getAll();request.onsuccess=function(e){var hasAlarmEnabled=!!e.target.result.length;navigator.mozSettings.createLock().set({'alarm.enabled':hasAlarmEnabled});ClockView.showHideAlarmSetIndicator(hasAlarmEnabled);};request.onerror=function(e){console.log('get all alarm fail');};},regUpdateAlarmEnableState:function am_regUpdateAlarmEnableState(handler){this._updateAlarmEableStateHandler=handler;}};