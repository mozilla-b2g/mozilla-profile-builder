'use strict';

var utils = {
  overlay: {
    show: function() {}
  }
};
