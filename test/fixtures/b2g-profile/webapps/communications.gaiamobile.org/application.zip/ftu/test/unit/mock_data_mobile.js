'use strict';

var MockDataMobile = {
  init: function() {},
  setStatus: function(s) { this.status = s;},
  getStatus: function() {
    return status;
  }
};
