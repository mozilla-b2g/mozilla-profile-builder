'use strict';

var WifiManager = {
  scan: function() {}
};

var WifiUI = {
  renderNetworks: function() {}
};
