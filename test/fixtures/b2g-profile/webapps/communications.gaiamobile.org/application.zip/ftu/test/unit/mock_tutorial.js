'use strict';

var Tutorial = {
  init: function() {}
};
