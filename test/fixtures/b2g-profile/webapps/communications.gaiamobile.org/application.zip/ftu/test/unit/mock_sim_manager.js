'use strict';

var MockSimManager = {

  handleCardState: function() {}

};
