'use strict';

var MockContactsListObj = {
    init: function() {},
    load: function() {},
    refresh: function() {},
    getContactById: function() {},
    getAllContacts: function() {},
    handleClick: function() {},
    remove: function() {},
    loaded: true,
    clearClickHandlers: function() {},
    setOrderByLastName: function() {}
};
