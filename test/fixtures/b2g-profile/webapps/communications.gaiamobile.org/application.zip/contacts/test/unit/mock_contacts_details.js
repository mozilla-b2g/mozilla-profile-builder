'use strict';

var MockContactDetails = {
  'init': function init() {}
};
