'use strict';

var MockContactsForm = {
  'init': function init() {}
};
