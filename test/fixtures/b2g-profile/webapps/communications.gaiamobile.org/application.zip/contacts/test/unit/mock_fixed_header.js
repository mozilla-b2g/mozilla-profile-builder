'use strict';

var MockFixedHeader = {
  init: function(param1, param2, param3) {
    return;
  },
  refresh: function() {
    return;
  }
};
