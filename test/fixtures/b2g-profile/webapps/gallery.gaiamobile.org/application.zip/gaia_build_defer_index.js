;'use strict';(function(window){var gL10nData={};var gTextProp='textContent';var gLanguage='';var gMacros={};var gReadyState='loading';var gAsyncResourceLoading=true;var gDEBUG=1;function consoleLog(message){if(gDEBUG>=2){console.log('[l10n] '+message);}};function consoleWarn(message){if(gDEBUG){console.warn('[l10n] '+message);}};function getL10nResourceLinks(){return document.querySelectorAll('link[type="application/l10n"]');}
function getL10nDictionary(){var script=document.querySelector('script[type="application/l10n"]');return script?JSON.parse(script.innerHTML):null;}
function getTranslatableChildren(element){return element?element.querySelectorAll('*[data-l10n-id]'):[];}
function getL10nAttributes(element){if(!element)
return{};var l10nId=element.getAttribute('data-l10n-id');var l10nArgs=element.getAttribute('data-l10n-args');var args={};if(l10nArgs){try{args=JSON.parse(l10nArgs);}catch(e){consoleWarn('could not parse arguments for #'+l10nId);}}
return{id:l10nId,args:args};}
function fireL10nReadyEvent(){var evtObject=document.createEvent('Event');evtObject.initEvent('localized',false,false);evtObject.language=gLanguage;window.dispatchEvent(evtObject);}
function parseResource(href,lang,successCallback,failureCallback){var baseURL=href.replace(/\/[^\/]*$/,'/');function evalString(text){if(text.lastIndexOf('\\')<0)
return text;return text.replace(/\\\\/g,'\\').replace(/\\n/g,'\n').replace(/\\r/g,'\r').replace(/\\t/g,'\t').replace(/\\b/g,'\b').replace(/\\f/g,'\f').replace(/\\{/g,'{').replace(/\\}/g,'}').replace(/\\"/g,'"').replace(/\\'/g,"'");}
function parseProperties(text){var dictionary=[];var reBlank=/^\s*|\s*$/;var reComment=/^\s*#|^\s*$/;var reSection=/^\s*\[(.*)\]\s*$/;var reImport=/^\s*@import\s+url\((.*)\)\s*$/i;var reSplit=/^([^=\s]*)\s*=\s*(.+)$/;function parseRawLines(rawText,extendedSyntax){var entries=rawText.replace(reBlank,'').split(/[\r\n]+/);var currentLang='*';var genericLang=lang.replace(/-[a-z]+$/i,'');var skipLang=false;var match='';for(var i=0;i<entries.length;i++){var line=entries[i];if(reComment.test(line))
continue;if(extendedSyntax){if(reSection.test(line)){match=reSection.exec(line);currentLang=match[1];skipLang=(currentLang!=='*')&&(currentLang!==lang)&&(currentLang!==genericLang);continue;}else if(skipLang){continue;}
if(reImport.test(line)){match=reImport.exec(line);loadImport(baseURL+match[1]);}}
var tmp=line.match(reSplit);if(tmp&&tmp.length==3){dictionary[tmp[1]]=evalString(tmp[2]);}}}
function loadImport(url){loadResource(url,function(content){parseRawLines(content,false);},null,false);}
parseRawLines(text,true);return dictionary;}
function loadResource(url,onSuccess,onFailure,asynchronous){onSuccess=onSuccess||function _onSuccess(data){};onFailure=onFailure||function _onFailure(){consoleWarn(url+' not found.');};var xhr=new XMLHttpRequest();xhr.open('GET',url,asynchronous);if(xhr.overrideMimeType){xhr.overrideMimeType('text/plain; charset=utf-8');}
xhr.onreadystatechange=function(){if(xhr.readyState==4){if(xhr.status==200||xhr.status===0){onSuccess(xhr.responseText);}else{onFailure();}}};xhr.onerror=onFailure;xhr.ontimeout=onFailure;try{xhr.send(null);}catch(e){onFailure();}}
loadResource(href,function(response){var data=parseProperties(response);for(var key in data){var id,prop,index=key.lastIndexOf('.');if(index>0){id=key.substring(0,index);prop=key.substr(index+1);}else{id=key;prop=gTextProp;}
if(!gL10nData[id]){gL10nData[id]={};}
gL10nData[id][prop]=data[key];}
if(successCallback){successCallback();}},failureCallback,gAsyncResourceLoading);};function loadLocale(lang,callback){callback=callback||function _callback(){};clear();gLanguage=lang;var langLinks=getL10nResourceLinks();var langCount=langLinks.length;if(langCount==0){var dict=getL10nDictionary();if(dict&&dict.locales&&dict.default_locale){consoleLog('using the embedded JSON directory, early way out');gL10nData=dict.locales[lang]||dict.locales[dict.default_locale];callback();}else{consoleLog('no resource to load, early way out');}
fireL10nReadyEvent(lang);gReadyState='complete';return;}
var onResourceLoaded=null;var gResourceCount=0;onResourceLoaded=function(){gResourceCount++;if(gResourceCount>=langCount){callback();fireL10nReadyEvent(lang);gReadyState='complete';}};function l10nResourceLink(link){var href=link.href;var type=link.type;this.load=function(lang,callback){var applied=lang;parseResource(href,lang,callback,function(){consoleWarn(href+' not found.');applied='';});return applied;};}
for(var i=0;i<langCount;i++){var resource=new l10nResourceLink(langLinks[i]);var rv=resource.load(lang,onResourceLoaded);if(rv!=lang){consoleWarn('"'+lang+'" resource not found');gLanguage='';}}}
function clear(){gL10nData={};gLanguage='';}
function getPluralRules(lang){var locales2rules={'af':3,'ak':4,'am':4,'ar':1,'asa':3,'az':0,'be':11,'bem':3,'bez':3,'bg':3,'bh':4,'bm':0,'bn':3,'bo':0,'br':20,'brx':3,'bs':11,'ca':3,'cgg':3,'chr':3,'cs':12,'cy':17,'da':3,'de':3,'dv':3,'dz':0,'ee':3,'el':3,'en':3,'eo':3,'es':3,'et':3,'eu':3,'fa':0,'ff':5,'fi':3,'fil':4,'fo':3,'fr':5,'fur':3,'fy':3,'ga':8,'gd':24,'gl':3,'gsw':3,'gu':3,'guw':4,'gv':23,'ha':3,'haw':3,'he':2,'hi':4,'hr':11,'hu':0,'id':0,'ig':0,'ii':0,'is':3,'it':3,'iu':7,'ja':0,'jmc':3,'jv':0,'ka':0,'kab':5,'kaj':3,'kcg':3,'kde':0,'kea':0,'kk':3,'kl':3,'km':0,'kn':0,'ko':0,'ksb':3,'ksh':21,'ku':3,'kw':7,'lag':18,'lb':3,'lg':3,'ln':4,'lo':0,'lt':10,'lv':6,'mas':3,'mg':4,'mk':16,'ml':3,'mn':3,'mo':9,'mr':3,'ms':0,'mt':15,'my':0,'nah':3,'naq':7,'nb':3,'nd':3,'ne':3,'nl':3,'nn':3,'no':3,'nr':3,'nso':4,'ny':3,'nyn':3,'om':3,'or':3,'pa':3,'pap':3,'pl':13,'ps':3,'pt':3,'rm':3,'ro':9,'rof':3,'ru':11,'rwk':3,'sah':0,'saq':3,'se':7,'seh':3,'ses':0,'sg':0,'sh':11,'shi':19,'sk':12,'sl':14,'sma':7,'smi':7,'smj':7,'smn':7,'sms':7,'sn':3,'so':3,'sq':3,'sr':11,'ss':3,'ssy':3,'st':3,'sv':3,'sw':3,'syr':3,'ta':3,'te':3,'teo':3,'th':0,'ti':4,'tig':3,'tk':3,'tl':4,'tn':3,'to':0,'tr':0,'ts':3,'tzm':22,'uk':11,'ur':3,'ve':3,'vi':0,'vun':3,'wa':4,'wae':3,'wo':0,'xh':3,'xog':3,'yo':0,'zh':0,'zu':3};function isIn(n,list){return list.indexOf(n)!==-1;}
function isBetween(n,start,end){return start<=n&&n<=end;}
var pluralRules={'0':function(n){return'other';},'1':function(n){if((isBetween((n%100),3,10)))
return'few';if(n===0)
return'zero';if((isBetween((n%100),11,99)))
return'many';if(n==2)
return'two';if(n==1)
return'one';return'other';},'2':function(n){if(n!==0&&(n%10)===0)
return'many';if(n==2)
return'two';if(n==1)
return'one';return'other';},'3':function(n){if(n==1)
return'one';return'other';},'4':function(n){if((isBetween(n,0,1)))
return'one';return'other';},'5':function(n){if((isBetween(n,0,2))&&n!=2)
return'one';return'other';},'6':function(n){if(n===0)
return'zero';if((n%10)==1&&(n%100)!=11)
return'one';return'other';},'7':function(n){if(n==2)
return'two';if(n==1)
return'one';return'other';},'8':function(n){if((isBetween(n,3,6)))
return'few';if((isBetween(n,7,10)))
return'many';if(n==2)
return'two';if(n==1)
return'one';return'other';},'9':function(n){if(n===0||n!=1&&(isBetween((n%100),1,19)))
return'few';if(n==1)
return'one';return'other';},'10':function(n){if((isBetween((n%10),2,9))&&!(isBetween((n%100),11,19)))
return'few';if((n%10)==1&&!(isBetween((n%100),11,19)))
return'one';return'other';},'11':function(n){if((isBetween((n%10),2,4))&&!(isBetween((n%100),12,14)))
return'few';if((n%10)===0||(isBetween((n%10),5,9))||(isBetween((n%100),11,14)))
return'many';if((n%10)==1&&(n%100)!=11)
return'one';return'other';},'12':function(n){if((isBetween(n,2,4)))
return'few';if(n==1)
return'one';return'other';},'13':function(n){if((isBetween((n%10),2,4))&&!(isBetween((n%100),12,14)))
return'few';if(n!=1&&(isBetween((n%10),0,1))||(isBetween((n%10),5,9))||(isBetween((n%100),12,14)))
return'many';if(n==1)
return'one';return'other';},'14':function(n){if((isBetween((n%100),3,4)))
return'few';if((n%100)==2)
return'two';if((n%100)==1)
return'one';return'other';},'15':function(n){if(n===0||(isBetween((n%100),2,10)))
return'few';if((isBetween((n%100),11,19)))
return'many';if(n==1)
return'one';return'other';},'16':function(n){if((n%10)==1&&n!=11)
return'one';return'other';},'17':function(n){if(n==3)
return'few';if(n===0)
return'zero';if(n==6)
return'many';if(n==2)
return'two';if(n==1)
return'one';return'other';},'18':function(n){if(n===0)
return'zero';if((isBetween(n,0,2))&&n!==0&&n!=2)
return'one';return'other';},'19':function(n){if((isBetween(n,2,10)))
return'few';if((isBetween(n,0,1)))
return'one';return'other';},'20':function(n){if((isBetween((n%10),3,4)||((n%10)==9))&&!(isBetween((n%100),10,19)||isBetween((n%100),70,79)||isBetween((n%100),90,99)))
return'few';if((n%1000000)===0&&n!==0)
return'many';if((n%10)==2&&!isIn((n%100),[12,72,92]))
return'two';if((n%10)==1&&!isIn((n%100),[11,71,91]))
return'one';return'other';},'21':function(n){if(n===0)
return'zero';if(n==1)
return'one';return'other';},'22':function(n){if((isBetween(n,0,1))||(isBetween(n,11,99)))
return'one';return'other';},'23':function(n){if((isBetween((n%10),1,2))||(n%20)===0)
return'one';return'other';},'24':function(n){if((isBetween(n,3,10)||isBetween(n,13,19)))
return'few';if(isIn(n,[2,12]))
return'two';if(isIn(n,[1,11]))
return'one';return'other';}};var index=locales2rules[lang.replace(/-.*$/,'')];if(!(index in pluralRules)){consoleWarn('plural form unknown for ['+lang+']');return function(){return'other';};}
return pluralRules[index];}
gMacros.plural=function(str,param,key,prop){var n=parseFloat(param);if(isNaN(n))
return str;if(prop!=gTextProp)
return str;if(!gMacros._pluralRules){gMacros._pluralRules=getPluralRules(gLanguage);}
var index='['+gMacros._pluralRules(n)+']';if(n===0&&(key+'[zero]')in gL10nData){str=gL10nData[key+'[zero]'][prop];}else if(n==1&&(key+'[one]')in gL10nData){str=gL10nData[key+'[one]'][prop];}else if(n==2&&(key+'[two]')in gL10nData){str=gL10nData[key+'[two]'][prop];}else if((key+index)in gL10nData){str=gL10nData[key+index][prop];}else if((key+'[other]')in gL10nData){str=gL10nData[key+'[other]'][prop];}
return str;};function getL10nData(key,args){var data=gL10nData[key];if(!data){consoleWarn('#'+key+' is undefined.');}
var rv={};for(var prop in data){var str=data[prop];str=substIndexes(str,args,key,prop);str=substArguments(str,args,key);rv[prop]=str;}
return rv;}
function substIndexes(str,args,key,prop){var reIndex=/\{\[\s*([a-zA-Z]+)\(([a-zA-Z]+)\)\s*\]\}/;var reMatch=reIndex.exec(str);if(!reMatch||!reMatch.length)
return str;var macroName=reMatch[1];var paramName=reMatch[2];var param;if(args&&paramName in args){param=args[paramName];}else if(paramName in gL10nData){param=gL10nData[paramName];}
if(macroName in gMacros){var macro=gMacros[macroName];str=macro(str,param,key,prop);}
return str;}
function substArguments(str,args,key){var reArgs=/\{\{\s*(.+?)\s*\}\}/;var match=reArgs.exec(str);while(match){if(!match||match.length<2)
return str;var arg=match[1];var sub='';if(args&&arg in args){sub=args[arg];}else if(arg in gL10nData){sub=gL10nData[arg][gTextProp];}else{consoleLog('argument {{'+arg+'}} for #'+key+' is undefined.');return str;}
str=str.substring(0,match.index)+sub+
str.substr(match.index+match[0].length);match=reArgs.exec(str);}
return str;}
function translateElement(element){var l10n=getL10nAttributes(element);if(!l10n.id){return;}
var data=getL10nData(l10n.id,l10n.args);if(!data){consoleWarn('#'+l10n.id+' is undefined.');return;}
if(data[gTextProp]){if(element.children.length===0){element[gTextProp]=data[gTextProp];}else{var children=element.childNodes;var found=false;for(var i=0,l=children.length;i<l;i++){if(children[i].nodeType===3&&/\S/.test(children[i].nodeValue)){if(found){children[i].nodeValue='';}else{children[i].nodeValue=data[gTextProp];found=true;}}}
if(!found){var textNode=document.createTextNode(data[gTextProp]);element.insertBefore(textNode,element.firstChild);}}
delete data[gTextProp];}
for(var k in data){element[k]=data[k];}}
function translateFragment(element){element=element||document.documentElement;var children=getTranslatableChildren(element);var elementCount=children.length;for(var i=0;i<elementCount;i++){translateElement(children[i]);}
translateElement(element);}
function l10nStartup(){gReadyState='interactive';consoleLog('loading ['+navigator.language+'] resources, '+
(gAsyncResourceLoading?'asynchronously.':'synchronously.'));if(document.documentElement.lang===navigator.language){loadLocale(navigator.language);}else{loadLocale(navigator.language,translateFragment);}}
if(typeof(document)!=='undefined'){if(document.readyState==='complete'||document.readyState==='interactive'){window.setTimeout(l10nStartup);}else{document.addEventListener('DOMContentLoaded',l10nStartup);}}
if('mozSettings'in navigator&&navigator.mozSettings){navigator.mozSettings.addObserver('language.current',function(event){loadLocale(event.settingValue,translateFragment);});}
navigator.mozL10n={get:function l10n_get(key,args,fallback){var data=getL10nData(key,args)||fallback;if(data){return'textContent'in data?data.textContent:'';}
return'{{'+key+'}}';},get language(){return{get code(){return gLanguage;},set code(lang){loadLocale(lang,translateFragment);},get direction(){var rtlList=['ar','he','fa','ps','ur'];return(rtlList.indexOf(gLanguage)>=0)?'rtl':'ltr';}};},translate:translateFragment,get dictionary(){return JSON.parse(JSON.stringify(gL10nData));},get readyState(){return gReadyState;},ready:function l10n_ready(callback){if(!callback)
return;if(gReadyState=='complete'){window.setTimeout(callback);}else{window.addEventListener('localized',callback);}}};consoleLog('library loaded.');})(this);;'use strict';(function(){if(MouseEventShim)
return;try{document.createEvent('TouchEvent');}catch(e){return;}
var starttouch;var target;var emitclick;window.addEventListener('mousedown',discardEvent,true);window.addEventListener('mouseup',discardEvent,true);window.addEventListener('mousemove',discardEvent,true);window.addEventListener('click',discardEvent,true);function discardEvent(e){if(e.isTrusted){e.stopImmediatePropagation();if(e.type==='click')
e.preventDefault();}}
window.addEventListener('touchstart',handleTouchStart);window.addEventListener('touchmove',handleTouchMove);window.addEventListener('touchend',handleTouchEnd);window.addEventListener('touchcancel',handleTouchEnd);function handleTouchStart(e){if(starttouch)
return;if(e.defaultPrevented)
return;try{e.changedTouches[0].target.ownerDocument;}
catch(e){return;}
starttouch=e.changedTouches[0];target=starttouch.target;emitclick=true;emitEvent('mousemove',target,starttouch);var result=emitEvent('mousedown',target,starttouch);if(!result){e.preventDefault();emitclick=false;}}
function handleTouchEnd(e){if(!starttouch)
return;if(MouseEventShim.capturing){MouseEventShim.capturing=false;MouseEventShim.captureTarget=null;}
for(var i=0;i<e.changedTouches.length;i++){var touch=e.changedTouches[i];if(touch.identifier!==starttouch.identifier)
continue;emitEvent('mouseup',target,touch);if(emitclick)
emitEvent('click',starttouch.target,touch);starttouch=null;return;}}
function handleTouchMove(e){if(!starttouch)
return;for(var i=0;i<e.changedTouches.length;i++){var touch=e.changedTouches[i];if(touch.identifier!==starttouch.identifier)
continue;if(e.defaultPrevented)
return;var dx=Math.abs(touch.screenX-starttouch.screenX);var dy=Math.abs(touch.screenY-starttouch.screenY);if(dx>MouseEventShim.dragThresholdX||dy>MouseEventShim.dragThresholdY){emitclick=false;}
var tracking=MouseEventShim.trackMouseMoves&&!MouseEventShim.capturing;if(tracking){var oldtarget=target;var newtarget=document.elementFromPoint(touch.clientX,touch.clientY);if(newtarget===null){newtarget=oldtarget;}
if(newtarget!==oldtarget){leave(oldtarget,newtarget,touch);target=newtarget;}}
else if(MouseEventShim.captureTarget){target=MouseEventShim.captureTarget;}
emitEvent('mousemove',target,touch);if(tracking&&newtarget!==oldtarget){enter(newtarget,oldtarget,touch);}}}
function contains(a,b){return(a.compareDocumentPosition(b)&16)!==0;}
function leave(oldtarget,newtarget,touch){emitEvent('mouseout',oldtarget,touch,newtarget);for(var e=oldtarget;!contains(e,newtarget);e=e.parentNode){emitEvent('mouseleave',e,touch,newtarget);}}
function enter(newtarget,oldtarget,touch){emitEvent('mouseover',newtarget,touch,oldtarget);for(var e=newtarget;!contains(e,oldtarget);e=e.parentNode){emitEvent('mouseenter',e,touch,oldtarget);}}
function emitEvent(type,target,touch,relatedTarget){var synthetic=document.createEvent('MouseEvents');var bubbles=(type!=='mouseenter'&&type!=='mouseleave');var count=(type==='mousedown'||type==='mouseup'||type==='click')?1:0;synthetic.initMouseEvent(type,bubbles,true,window,count,touch.screenX,touch.screenY,touch.clientX,touch.clientY,false,false,false,false,0,relatedTarget||null);try{return target.dispatchEvent(synthetic);}
catch(e){console.warn('Exception calling dispatchEvent',type,e);return true;}}}());var MouseEventShim={getEventTimestamp:function(e){if(e.isTrusted)
return e.timeStamp;else
return e.timeStamp/1000;},trackMouseMoves:true,setCapture:function(target){this.capturing=true;if(target)
this.captureTarget=target;},capturing:false,dragThresholdX:25,dragThresholdY:25};;'use strict';var MediaDB=(function(){function MediaDB(mediaType,metadataParser,options){this.mediaType=mediaType;this.metadataParser=metadataParser;if(!options)
options={};this.indexes=options.indexes||[];this.version=options.version||1;this.mimeTypes=options.mimeTypes;this.autoscan=(options.autoscan!==undefined)?options.autoscan:true;this.state=MediaDB.OPENING;this.scanning=false;this.batchHoldTime=options.batchHoldTime||100;this.batchSize=options.batchSize||0;this.dbname='MediaDB/'+this.mediaType+'/';var media=this;this.details={eventListeners:{},pendingInsertions:[],pendingDeletions:[],whenDoneProcessing:[],pendingCreateNotifications:[],pendingDeleteNotifications:[],pendingNotificationTimer:null,newestFileModTime:0};if(!this.metadataParser){this.metadataParser=function(file,callback){setTimeout(function(){callback({});},0);};}
var openRequest=indexedDB.open(this.dbname,this.version*MediaDB.VERSION);openRequest.onerror=function(e){console.error('MediaDB():',openRequest.error.name);};openRequest.onblocked=function(e){console.error('indexedDB.open() is blocked in MediaDB()');};openRequest.onupgradeneeded=function(e){var db=openRequest.result;var existingStoreNames=db.objectStoreNames;for(var i=0;i<existingStoreNames.length;i++){db.deleteObjectStore(existingStoreNames[i]);}
var filestore=db.createObjectStore('files',{keyPath:'name'});filestore.createIndex('date','date');media.indexes.forEach(function(indexName){if(indexName==='name'||indexName==='date')
return;filestore.createIndex(indexName,indexName);});};openRequest.onsuccess=function(e){media.db=openRequest.result;media.db.onerror=function(event){console.error('MediaDB: ',event.target.error&&event.target.error.name);};var cursorRequest=media.db.transaction('files','readonly').objectStore('files').index('date').openCursor(null,'prev');cursorRequest.onerror=function(){console.error('MediaDB initialization error',cursorRequest.error);};cursorRequest.onsuccess=function(){var cursor=cursorRequest.result;if(cursor){media.details.newestFileModTime=cursor.value.date;}
else{media.details.newestFileModTime=0;}
initDeviceStorage();};};function initDeviceStorage(){var details=media.details;media.storage=navigator.getDeviceStorage(mediaType);details.storages=navigator.getDeviceStorages(mediaType);details.availability={};getStorageAvailability();function getStorageAvailability(){var next=0;getNextAvailability();function getNextAvailability(){if(next>=details.storages.length){setupHandlers();return;}
var s=details.storages[next++];var name=s.storageName;var req=s.available();req.onsuccess=function(e){details.availability[name]=req.result;getNextAvailability();};req.onerror=function(e){details.availability[name]='unavailable';getNextAvailability();};}}
function setupHandlers(){for(var i=0;i<details.storages.length;i++)
details.storages[i].addEventListener('change',changeHandler);details.dsEventListener=changeHandler;sendInitialEvent();}
function sendInitialEvent(){var state=getState(details.availability);changeState(media,state);if(media.autoscan)
scan(media);}
function getState(availability){var n=0;var a=0;var u=0;var s=0;for(var name in availability){n++;switch(availability[name]){case'available':a++;break;case'unavailable':u++;break;case'shared':s++;break;}}
if(s>0)
return MediaDB.UNMOUNTED;if(u===n)
return MediaDB.NOCARD;return MediaDB.READY;}
function changeHandler(e){switch(e.reason){case'modified':case'deleted':fileChangeHandler(e);return;case'available':case'unavailable':case'shared':volumeChangeHandler(e);return;default:return;}}
function volumeChangeHandler(e){var storageName=e.target.storageName;if(details.availability[storageName]===e.reason)
return;var oldState=media.state;details.availability[storageName]=e.reason;var newState=getState(details.availability);if(newState!==oldState){changeState(media,newState);if(newState===MediaDB.READY){if(media.autoscan)
scan(media);}
else{endscan(media);}}
else if(newState===MediaDB.READY){if(e.reason==='available'){dispatchEvent(media,'ready');if(media.autoscan)
scan(media);}
else if(e.reason==='unavailable'){dispatchEvent(media,'cardremoved');deleteAllFiles(storageName);}}}
function fileChangeHandler(e){var filename=e.path;if(ignoreName(filename))
return;if(e.reason==='modified')
insertRecord(media,filename);else
deleteRecord(media,filename);}
function deleteAllFiles(storageName){var storagePrefix=storageName?'/'+storageName+'/':'';var store=media.db.transaction('files').objectStore('files');var cursorRequest=store.openCursor();cursorRequest.onsuccess=function(){var cursor=cursorRequest.result;if(cursor){if(cursor.value.name.startsWith(storagePrefix)){deleteRecord(media,cursor.value.name);}
cursor.continue();}};}}}
MediaDB.prototype={close:function close(){this.db.close();for(var i=0;i<this.details.storages.length;i++){var s=this.details.storages[i];s.removeEventListener('change',this.details.dsEventListener);}
changeState(this,MediaDB.CLOSED);},addEventListener:function addEventListener(type,listener){if(!this.details.eventListeners.hasOwnProperty(type))
this.details.eventListeners[type]=[];var listeners=this.details.eventListeners[type];if(listeners.indexOf(listener)!==-1)
return;listeners.push(listener);},removeEventListener:function removeEventListener(type,listener){if(!this.details.eventListeners.hasOwnProperty(type))
return;var listeners=this.details.eventListeners[type];var position=listeners.indexOf(listener);if(position===-1)
return;listeners.splice(position,1);},getFile:function getFile(filename,callback,errback){if(this.state!==MediaDB.READY)
throw Error('MediaDB is not ready. State: '+this.state);var getRequest=this.storage.get(filename);getRequest.onsuccess=function(){callback(getRequest.result);};getRequest.onerror=function(){var errmsg=getRequest.error&&getRequest.error.name;if(errback)
errback(errmsg);else
console.error('MediaDB.getFile:',errmsg);};},deleteFile:function deleteFile(filename){if(this.state!==MediaDB.READY)
throw Error('MediaDB is not ready. State: '+this.state);this.storage.delete(filename).onerror=function(e){console.error('MediaDB.deleteFile(): Failed to delete',filename,'from DeviceStorage:',e.target.error);};},addFile:function addFile(filename,file){if(this.state!==MediaDB.READY)
throw Error('MediaDB is not ready. State: '+this.state);var media=this;var deletereq=media.storage.delete(filename);deletereq.onsuccess=deletereq.onerror=save;function save(){var request=media.storage.addNamed(file,filename);request.onerror=function(){console.error('MediaDB: Failed to store',filename,'in DeviceStorage:',request.error);};}},updateMetadata:function(filename,metadata,callback){if(this.state===MediaDB.OPENING)
throw Error('MediaDB is not ready. State: '+this.state);var media=this;var read=media.db.transaction('files','readonly').objectStore('files').get(filename);read.onerror=function(){console.error('MediaDB.updateMetadata called with unknown filename');};read.onsuccess=function(){var fileinfo=read.result;Object.keys(metadata).forEach(function(key){fileinfo.metadata[key]=metadata[key];});var write=media.db.transaction('files','readwrite').objectStore('files').put(fileinfo);write.onerror=function(){console.error('MediaDB.updateMetadata: database write failed',write.error&&write.error.name);};if(callback){write.onsuccess=function(){callback();};}};},count:function(key,range,callback){if(this.state!==MediaDB.READY)
throw Error('MediaDB is not ready. State: '+this.state);if(arguments.length===1){callback=key;range=undefined;key=undefined;}
else if(arguments.length===2){callback=range;range=key;key=undefined;}
var store=this.db.transaction('files').objectStore('files');if(key&&key!=='name')
store=store.index(key);var countRequest=store.count(range||null);countRequest.onerror=function(){console.error('MediaDB.count() failed with',countRequest.error);};countRequest.onsuccess=function(e){callback(e.target.result);};},enumerate:function enumerate(key,range,direction,callback){if(this.state!==MediaDB.READY)
throw Error('MediaDB is not ready. State: '+this.state);var handle={state:'enumerating'};if(arguments.length===1){callback=key;key=undefined;}
else if(arguments.length===2){callback=range;range=undefined;}
else if(arguments.length===3){callback=direction;direction=undefined;}
var store=this.db.transaction('files').objectStore('files');if(key&&key!=='name')
store=store.index(key);var cursorRequest=store.openCursor(range||null,direction||'next');cursorRequest.onerror=function(){console.error('MediaDB.enumerate() failed with',cursorRequest.error);handle.state='error';};cursorRequest.onsuccess=function(){if(handle.state==='cancelling'){handle.state='cancelled';return;}
var cursor=cursorRequest.result;if(cursor){try{if(!cursor.value.fail)
callback(cursor.value);}
catch(e){console.warn('MediaDB.enumerate(): callback threw',e);}
cursor.continue();}
else{handle.state='complete';callback(null);}};return handle;},enumerateAll:function enumerateAll(key,range,direction,callback){var batch=[];if(arguments.length===1){callback=key;key=undefined;}
else if(arguments.length===2){callback=range;range=undefined;}
else if(arguments.length===3){callback=direction;direction=undefined;}
return this.enumerate(key,range,direction,function(fileinfo){if(fileinfo!==null)
batch.push(fileinfo);else
callback(batch);});},cancelEnumeration:function cancelEnumeration(handle){if(handle.state==='enumerating')
handle.state='cancelling';},getAll:function getAll(callback){if(this.state!==MediaDB.READY)
throw Error('MediaDB is not ready. State: '+this.state);var store=this.db.transaction('files').objectStore('files');var request=store.mozGetAll();request.onerror=function(){console.error('MediaDB.getAll() failed with',request.error);};request.onsuccess=function(){var all=request.result;var good=all.filter(function(fileinfo){return!fileinfo.fail;});callback(good);};},scan:function(){scan(this);},freeSpace:function freeSpace(callback){if(this.state!==MediaDB.READY)
throw Error('MediaDB is not ready. State: '+this.state);var freereq=this.storage.freeSpace();freereq.onsuccess=function(){callback(freereq.result);};}};MediaDB.VERSION=2;MediaDB.OPENING='opening';MediaDB.READY='ready';MediaDB.NOCARD='nocard';MediaDB.UNMOUNTED='unmounted';MediaDB.CLOSED='closed';function ignore(media,file){if(ignoreName(file.name))
return true;if(media.mimeTypes&&media.mimeTypes.indexOf(file.type)===-1)
return true;return false;}
function ignoreName(filename){return(filename[0]==='.'||filename.indexOf('/.')!==-1);}
function scan(media){media.scanning=true;dispatchEvent(media,'scanstart');quickScan(media.details.newestFileModTime);function quickScan(timestamp){var cursor;if(timestamp>0){media.details.firstscan=false;cursor=media.storage.enumerate('',{since:new Date(timestamp+1)});}
else{media.details.firstscan=true;media.details.records=[];cursor=media.storage.enumerate('');}
cursor.onsuccess=function(){if(!media.scanning)
return;var file=cursor.result;if(file){if(!ignore(media,file))
insertRecord(media,file);cursor.continue();}
else{whenDoneProcessing(media,function(){sendNotifications(media);if(media.details.firstscan){endscan(media);}
else{fullScan();}});}};cursor.onerror=function(){console.warning('Error while scanning',cursor.error);endscan(media);};}
function fullScan(){if(media.state!==MediaDB.READY){endscan(media);return;}
var dsfiles=[];var cursor=media.storage.enumerate('');cursor.onsuccess=function(){if(!media.scanning)
return;var file=cursor.result;if(file){if(!ignore(media,file)){dsfiles.push(file);}
cursor.continue();}
else{getDBFiles();}};cursor.onerror=function(){console.warning('Error while scanning',cursor.error);endscan(media);};function getDBFiles(){var store=media.db.transaction('files').objectStore('files');var getAllRequest=store.mozGetAll();getAllRequest.onsuccess=function(){if(!media.scanning)
return;var dbfiles=getAllRequest.result;compareLists(dbfiles,dsfiles);};}
function compareLists(dbfiles,dsfiles){dsfiles.sort(function(a,b){if(a.name<b.name)
return-1;else
return 1;});var dsindex=0,dbindex=0;while(true){var dsfile;if(dsindex<dsfiles.length)
dsfile=dsfiles[dsindex];else
dsfile=null;var dbfile;if(dbindex<dbfiles.length)
dbfile=dbfiles[dbindex];else
dbfile=null;if(dsfile===null&&dbfile===null)
break;if(dbfile===null){insertRecord(media,dsfile);dsindex++;continue;}
if(dsfile===null){deleteRecord(media,dbfile.name);dbindex++;continue;}
if(dsfile.name===dbfile.name){var lastModified=dsfile.lastModifiedDate;if((lastModified&&lastModified.getTime()!==dbfile.date)||dsfile.size!==dbfile.size){deleteRecord(media,dbfile.name);insertRecord(media,dsfile);}
dsindex++;dbindex++;continue;}
if(dsfile.name<dbfile.name){insertRecord(media,dsfile);dsindex++;continue;}
if(dsfile.name>dbfile.name){deleteRecord(media,dbfile.name);dbindex++;continue;}
console.error('Assertion failed');}
insertRecord(media,null);}}}
function endscan(media){if(media.scanning){media.scanning=false;dispatchEvent(media,'scanend');}}
function insertRecord(media,fileOrName){var details=media.details;details.pendingInsertions.push(fileOrName);if(details.processingQueue)
return;processQueue(media);}
function deleteRecord(media,filename){var details=media.details;details.pendingDeletions.push(filename);if(details.processingQueue)
return;processQueue(media);}
function whenDoneProcessing(media,f){var details=media.details;if(details.processingQueue)
details.whenDoneProcessing.push(f);else
f();}
function processQueue(media){var details=media.details;details.processingQueue=true;next();function next(){if(details.pendingDeletions.length>0){deleteFiles();}
else if(details.pendingInsertions.length>0){insertFile(details.pendingInsertions.shift());}
else{details.processingQueue=false;if(details.whenDoneProcessing.length>0){var functions=details.whenDoneProcessing;details.whenDoneProcessing=[];functions.forEach(function(f){f();});}}}
function deleteFiles(){var transaction=media.db.transaction('files','readwrite');var store=transaction.objectStore('files');deleteNextFile();function deleteNextFile(){if(details.pendingDeletions.length===0){next();return;}
var filename=details.pendingDeletions.shift();var request=store.delete(filename);request.onerror=function(){console.warn('MediaDB: Unknown file in deleteRecord:',filename,getreq.error);deleteNextFile();};request.onsuccess=function(){queueDeleteNotification(media,filename);deleteNextFile();};}}
function insertFile(f){if(f===null){sendNotifications(media);endscan(media);next();return;}
if(typeof f==='string'){var getreq=media.storage.get(f);getreq.onerror=function(){console.warn('MediaDB: Unknown file in insertRecord:',f,getreq.error);next();};getreq.onsuccess=function(){if(media.mimeTypes&&ignore(media,getreq.result))
next();else
parseMetadata(getreq.result,f);};}
else{parseMetadata(f,f.name);}}
function parseMetadata(file,filename){if(!file.lastModifiedDate){console.warn('MediaDB: parseMetadata: no lastModifiedDate for',filename,'using Date.now() until #793955 is fixed');}
var fileinfo={name:filename,type:file.type,size:file.size,date:file.lastModifiedDate?file.lastModifiedDate.getTime():Date.now()};if(fileinfo.date>details.newestFileModTime)
details.newestFileModTime=fileinfo.date;media.metadataParser(file,gotMetadata,metadataError);function metadataError(e){console.warn('MediaDB: error parsing metadata for',filename,':',e);fileinfo.fail=true;storeRecord(fileinfo);}
function gotMetadata(metadata){fileinfo.metadata=metadata;storeRecord(fileinfo);}}
function storeRecord(fileinfo){if(media.details.firstscan){media.details.records.push(fileinfo);if(!fileinfo.fail){queueCreateNotification(media,fileinfo);}
next();}
else{var transaction=media.db.transaction('files','readwrite');var store=transaction.objectStore('files');var request=store.add(fileinfo);request.onsuccess=function(){if(!fileinfo.fail)
queueCreateNotification(media,fileinfo);next();};request.onerror=function(event){if(request.error.name==='ConstraintError'){event.stopPropagation();event.preventDefault();var putrequest=store.put(fileinfo);putrequest.onsuccess=function(){queueDeleteNotification(media,fileinfo.name);if(!fileinfo.fail)
queueCreateNotification(media,fileinfo);next();};putrequest.onerror=function(){console.error('MediaDB: unexpected ConstraintError','in insertRecord for file:',fileinfo.name);next();};}
else{console.error('MediaDB: unexpected error in insertRecord:',request.error,'for file:',fileinfo.name);next();}};}}}
function queueCreateNotification(media,fileinfo){var creates=media.details.pendingCreateNotifications;creates.push(fileinfo);if(media.batchSize&&creates.length>=media.batchSize)
sendNotifications(media);else
resetNotificationTimer(media);}
function queueDeleteNotification(media,filename){var deletes=media.details.pendingDeleteNotifications;deletes.push(filename);if(media.batchSize&&deletes.length>=media.batchSize)
sendNotifications(media);else
resetNotificationTimer(media);}
function resetNotificationTimer(media){var details=media.details;if(details.pendingNotificationTimer)
clearTimeout(details.pendingNotificationTimer);details.pendingNotificationTimer=setTimeout(function(){sendNotifications(media);},media.batchHoldTime);}
function sendNotifications(media){var details=media.details;if(details.pendingNotificationTimer){clearTimeout(details.pendingNotificationTimer);details.pendingNotificationTimer=null;}
if(details.pendingDeleteNotifications.length>0){var deletions=details.pendingDeleteNotifications;details.pendingDeleteNotifications=[];dispatchEvent(media,'deleted',deletions);}
if(details.pendingCreateNotifications.length>0){if(details.firstscan&&details.records.length>0){var transaction=media.db.transaction('files','readwrite');var store=transaction.objectStore('files');for(var i=0;i<details.records.length;i++)
store.add(details.records[i]);details.records.length=0;}
var creations=details.pendingCreateNotifications;details.pendingCreateNotifications=[];dispatchEvent(media,'created',creations);}}
function dispatchEvent(media,type,detail){var handler=media['on'+type];var listeners=media.details.eventListeners[type];if(!handler&&(!listeners||listeners.length==0))
return;var event={type:type,target:media,currentTarget:media,timestamp:Date.now(),detail:detail};if(typeof handler==='function'){try{handler.call(media,event);}
catch(e){console.warn('MediaDB: ','on'+type,'event handler threw',e);}}
if(!listeners)
return;for(var i=0;i<listeners.length;i++){try{var listener=listeners[i];if(typeof listener==='function'){listener.call(media,event);}
else{listener.handleEvent(event);}}
catch(e){console.warn('MediaDB: ',type,'event listener threw',e);}}}
function changeState(media,state){if(media.state!==state){media.state=state;if(state===MediaDB.READY)
dispatchEvent(media,'ready');else
dispatchEvent(media,'unavailable',state);}}
return MediaDB;}());;'use strict';var LazyLoader=(function(){function LazyLoader(){this._loaded={};this._isLoading={};}
LazyLoader.prototype={_js:function(file,callback){var script=document.createElement('script');script.src=file;script.addEventListener('load',callback);document.head.appendChild(script);this._isLoading[file]=script;},_css:function(file,callback){var style=document.createElement('link');style.type='text/css';style.rel='stylesheet';style.href=file;document.head.appendChild(style);callback();},_html:function(domNode,callback){for(var i=0;i<domNode.childNodes.length;i++){if(domNode.childNodes[i].nodeType==document.COMMENT_NODE){domNode.innerHTML=domNode.childNodes[i].nodeValue;break;}}
callback();},load:function(files,callback){if(!Array.isArray(files))
files=[files];var loadsRemaining=files.length,self=this;function perFileCallback(file){if(self._isLoading[file])
delete self._isLoading[file];self._loaded[file]=true;if(--loadsRemaining===0){if(callback)
callback();}}
for(var i=0;i<files.length;i++){var file=files[i];if(this._loaded[file]){perFileCallback(file);}else if(this._isLoading[file]){this._isLoading[file].addEventListener('load',perFileCallback.bind(null,file));}else{var method,idx;if(typeof file==='string'){method=file.match(/\.(.*?)$/)[1];idx=file;}else{method='html';idx=file.id;}
this['_'+method](file,perFileCallback.bind(null,idx));}}}};return new LazyLoader();}());;'use strict';function monitorChildVisibility(container,scrollmargin,scrolldelta,onscreenCallback,offscreenCallback)
{var firstOnscreen=null,lastOnscreen=null;var firstNotifiedOnscreen=null,lastNotifiedOnscreen=null;var pendingCallbacks=null;var lastScrollTop=-1;container.addEventListener('scroll',scrollHandler);window.addEventListener('resize',resizeHandler);var observer=new MutationObserver(mutationHandler);observer.observe(container,{childList:true});adjustBounds();callCallbacks();return{stop:function stop(){container.removeEventListener('scroll',scrollHandler);window.removeEventListener('resize',resizeHandler);observer.disconnect();}};function resizeHandler(){if(container.clientHeight===0){return;}
adjustBounds();callCallbacks();}
function mutationHandler(mutations){if(container.clientHeight===0){return;}
if(pendingCallbacks)
callCallbacks();for(var i=0;i<mutations.length;i++){var mutation=mutations[i];if(mutation.addedNodes){for(var j=0;j<mutation.addedNodes.length;j++){var child=mutation.addedNodes[j];if(child.nodeType===Node.ELEMENT_NODE)
childAdded(child);}}
if(mutation.removedNodes){for(var j=0;j<mutation.removedNodes.length;j++){var child=mutation.removedNodes[j];if(child.nodeType===Node.ELEMENT_NODE)
childRemoved(child,mutation.previousSibling,mutation.nextSibling);}}}}
function childAdded(child){if(lastOnscreen&&after(child,lastOnscreen)&&child.offsetTop>container.clientHeight+scrollmargin)
return;if(!firstOnscreen||after(child,firstOnscreen)){try{onscreenCallback(child);}
catch(e){console.warn('monitorChildVisiblity: Exception in onscreenCallback:',e,e.stack);}}
adjustBounds();callCallbacks();}
function childRemoved(child,previous,next){if(container.firstElementChild===null){firstOnscreen=lastOnscreen=null;firstNotifiedOnscreen=lastNotifiedOnscreen=null;}
else{if(previous!==null&&after(previous,lastOnscreen))
return;if(child===firstOnscreen){firstOnscreen=firstNotifiedOnscreen=next||previous;}
if(child===lastOnscreen){lastOnscreen=lastNotifiedOnscreen=previous||next;}
adjustBounds();}
callCallbacks();}
function scrollHandler(){if(container.clientHeight===0){return;}
var scrollTop=container.scrollTop;if(Math.abs(scrollTop-lastScrollTop)<scrolldelta){return;}
lastScrollTop=scrollTop;adjustBounds();if(scrolldelta>1){callCallbacks();}else{deferCallbacks();}}
function before(a,b){return!!(a.compareDocumentPosition(b)&Node.DOCUMENT_POSITION_FOLLOWING);}
function after(a,b){return!!(a.compareDocumentPosition(b)&Node.DOCUMENT_POSITION_PRECEDING);}
function adjustBounds(){if(container.firstElementChild===null){firstOnscreen=lastOnscreen=null;return;}
var scrollTop=container.scrollTop;var screenTop=scrollTop-scrollmargin;var screenBottom=scrollTop+container.clientHeight+scrollmargin;var BEFORE=-1,ON=0,AFTER=1;function position(child){var childTop=child.offsetTop;var childBottom=childTop+child.offsetHeight;if(childBottom<screenTop)
return BEFORE;if(childTop>screenBottom)
return AFTER;return ON;}
if(!firstOnscreen)
firstOnscreen=container.firstElementChild;var toppos=position(firstOnscreen);if(toppos===ON){var prev=firstOnscreen.previousElementSibling;while(prev&&position(prev)===ON){firstOnscreen=prev;prev=prev.previousElementSibling;}}
else if(toppos===BEFORE){var e=firstOnscreen.nextElementSibling;while(e&&position(e)!==ON){e=e.nextElementSibling;}
firstOnscreen=e;}
else{lastOnscreen=firstOnscreen.previousElementSibling;while(lastOnscreen&&position(lastOnscreen)!==ON)
lastOnscreen=lastOnscreen.previousElementSibling;firstOnscreen=lastOnscreen;prev=firstOnscreen.previousElementSibling;while(prev&&position(prev)===ON){firstOnscreen=prev;prev=prev.previousElementSibling;}
return;}
if(lastOnscreen===null)
lastOnscreen=firstOnscreen;var bottompos=position(lastOnscreen);if(bottompos===ON){var next=lastOnscreen.nextElementSibling;while(next&&position(next)===ON){lastOnscreen=next;next=next.nextElementSibling;}}
else if(bottompos===AFTER){lastOnscreen=lastOnscreen.previousElementSibling;while(position(lastOnscreen)!==ON)
lastOnscreen=lastOnscreen.previousElementSibling;}
else{firstOnscreen=lastOnscreen.nextElementSibling;while(firstOnscreen&&position(firstOnscreen)!==ON){firstOnscreen=firstOnscreen.nextElementSibling;}
lastOnscreen=firstOnscreen;var next=lastOnscreen.nextElementSibling;while(next&&position(next)===ON){lastOnscreen=next;next=next.nextElementSibling;}}}
function deferCallbacks(){if(pendingCallbacks){clearTimeout(pendingCallbacks);}
pendingCallbacks=setTimeout(callCallbacks,0);}
function callCallbacks(){if(pendingCallbacks){clearTimeout(pendingCallbacks);pendingCallbacks=null;}
function onscreen(from,to){var e=from;while(e&&e!==to){try{onscreenCallback(e);}
catch(ex){console.warn('monitorChildVisibility: Exception in onscreenCallback:',ex,ex.stack);}
e=e.nextElementSibling;}}
function offscreen(from,to){var e=from;while(e&&e!==to){try{offscreenCallback(e);}
catch(ex){console.warn('monitorChildVisibility: '+'Exception in offscreenCallback:',ex,ex.stack);}
e=e.nextElementSibling;}}
if(firstOnscreen===firstNotifiedOnscreen&&lastOnscreen===lastNotifiedOnscreen)
return;if(firstNotifiedOnscreen===null){onscreen(firstOnscreen,lastOnscreen.nextElementSibling);}
else if(firstOnscreen===null){}
else if(before(lastOnscreen,firstNotifiedOnscreen)||after(firstOnscreen,lastNotifiedOnscreen)){onscreen(firstOnscreen,lastOnscreen.nextElementSibling);offscreen(firstNotifiedOnscreen,lastNotifiedOnscreen.nextElementSibling);}
else{if(before(firstOnscreen,firstNotifiedOnscreen)){onscreen(firstOnscreen,firstNotifiedOnscreen);}
if(after(lastOnscreen,lastNotifiedOnscreen)){onscreen(lastNotifiedOnscreen.nextElementSibling,lastOnscreen.nextElementSibling);}
if(after(firstOnscreen,firstNotifiedOnscreen)){offscreen(firstNotifiedOnscreen,firstOnscreen);}
if(before(lastOnscreen,lastNotifiedOnscreen)){offscreen(lastOnscreen.nextElementSibling,lastNotifiedOnscreen.nextElementSibling);}}
firstNotifiedOnscreen=firstOnscreen;lastNotifiedOnscreen=lastOnscreen;}};'use strict';var TRANSITION_FRACTION=0.25;var TRANSITION_SPEED=0.75;var PAGE_SIZE=15;function $(id){return document.getElementById(id);}
var thumbnails=$('thumbnails');var thumbnailListView=$('thumbnail-list-view');var thumbnailSelectView=$('thumbnail-select-view');var fullscreenView=$('fullscreen-view');var editView=$('edit-view');var pickView=$('pick-view');var cropView=$('crop-view');var views=[thumbnailListView,thumbnailSelectView,fullscreenView,editView,pickView,cropView];var currentView;var languageDirection;var files=[];var currentFileIndex=0;var editedPhotoIndex;var selectedFileNames=[];var selectedFileNamesToBlobs={};var photodb;var videostorage;var visibilityMonitor;var loader=LazyLoader;var scanningBigImages=false;window.addEventListener('localized',function showBody(){window.removeEventListener('localized',showBody);document.documentElement.lang=navigator.mozL10n.language.code;document.documentElement.dir=navigator.mozL10n.language.direction;document.body.classList.remove('hidden');if(!photodb)
init();});function init(){MouseEventShim.trackMouseMoves=false;$('thumbnails-select-button').onclick=setView.bind(null,thumbnailSelectView);$('thumbnails-cancel-button').onclick=setView.bind(null,thumbnailListView);$('pick-back-button').onclick=cancelPick;$('crop-back-button').onclick=function(){setView(pickView);cleanupCrop();};$('crop-done-button').onclick=cropAndEndPick;$('fullscreen-camera-button').onclick=launchCameraApp;$('thumbnails-camera-button').onclick=launchCameraApp;$('thumbnails-delete-button').onclick=deleteSelectedItems;$('thumbnails-share-button').onclick=shareSelectedItems;window.onresize=resizeHandler;if(!navigator.mozHasPendingMessage('activity')){initDB();setView(thumbnailListView);}
navigator.mozSetMessageHandler('activity',function activityHandler(a){var activityName=a.source.name;switch(activityName){case'browse':if(!photodb){initDB();setView(thumbnailListView);}
else{if(currentView===fullscreenView)
setView(thumbnailListView);}
break;case'pick':if(pendingPick)
cancelPick();pendingPick=a;if(!photodb)
initDB();startPick();break;}});}
function initDB(){photodb=new MediaDB('pictures',metadataParserWrapper,{version:2,autoscan:false,batchHoldTime:150,batchSize:PAGE_SIZE});videostorage=navigator.getDeviceStorage('videos');var loaded=false;function metadataParserWrapper(file,onsuccess,onerror){if(loaded){metadataParser(file,onsuccess,onerror);return;}
loader.load('js/metadata_scripts.js',function(){loaded=true;metadataParser(file,onsuccess,onerror);});}
photodb.onunavailable=function(event){if(pendingPick){cancelPick();return;}
setView(thumbnailListView);var why=event.detail;if(why===MediaDB.NOCARD)
showOverlay('nocard');else if(why===MediaDB.UNMOUNTED)
showOverlay('pluggedin');};photodb.onready=function(){if(currentOverlay==='nocard'||currentOverlay==='pluggedin')
showOverlay(null);initThumbnails();};photodb.onscanstart=function onscanstart(){$('progress').classList.remove('hidden');$('throbber').classList.add('throb');};photodb.onscanend=function onscanend(){if(currentOverlay==='scanning')
showOverlay('emptygallery');$('progress').classList.add('hidden');$('throbber').classList.remove('throb');scanningBigImages=false;};photodb.oncardremoved=function oncardremoved(){if(pendingPick){cancelPick();return;}
setView(thumbnailListView);};photodb.oncreated=function(event){event.detail.forEach(fileCreated);};photodb.ondeleted=function(event){event.detail.forEach(fileDeleted);};}
function getVideoFile(filename,callback){var req=videostorage.get(filename);req.onsuccess=function(){callback(req.result);};req.onerror=function(){console.error('Failed to get video file',filename);};}
function compareFilesByDate(a,b){if(a.date<b.date)
return 1;else if(a.date>b.date)
return-1;return 0;}
function initThumbnails(){if(visibilityMonitor){photodb.scan();return;}
var visibilityMargin=5060;var minimumScrollDelta=4000;visibilityMonitor=monitorChildVisibility(thumbnails,visibilityMargin,minimumScrollDelta,thumbnailOnscreen,thumbnailOffscreen);thumbnails.onclick=thumbnailClickHandler;var batch=[];var batchsize=PAGE_SIZE;photodb.enumerate('date',null,'prev',function(fileinfo){if(fileinfo){if(pendingPick&&fileinfo.metadata.video)
return;batch.push(fileinfo);if(batch.length>=batchsize){flush();batchsize*=2;}}
else{done();}});function flush(){batch.forEach(thumb);batch.length=0;}
function thumb(fileinfo){files.push(fileinfo);var thumbnail=createThumbnail(files.length-1);thumbnails.appendChild(thumbnail);}
function done(){flush();if(files.length===0){showOverlay('scanning');}
photodb.scan();}}
function fileDeleted(filename){for(var n=0;n<files.length;n++){if(files[n].name===filename)
break;}
if(n>=files.length)
return;var deletedImageData=files.splice(n,1)[0];var thumbnailElts=thumbnails.querySelectorAll('.thumbnail');URL.revokeObjectURL(thumbnailElts[n].dataset.backgroundImage.slice(5,-2));thumbnails.removeChild(thumbnailElts[n]);for(var i=n+1;i<thumbnailElts.length;i++){thumbnailElts[i].dataset.index=i-1;}
if(n<currentFileIndex)
currentFileIndex--;if(currentFileIndex>=files.length)
currentFileIndex=files.length-1;if(n<editedPhotoIndex)
editedPhotoIndex--;if(currentView===fullscreenView&&files.length>0){showFile(currentFileIndex);}
if(files.length===0){if(currentView!==pickView)
setView(thumbnailListView);showOverlay('emptygallery');}}
function deleteFile(n){if(n<0||n>=files.length)
return;var fileinfo=files[n];photodb.deleteFile(files[n].name);if(fileinfo.metadata.video){videostorage.delete(fileinfo.metadata.video);}
if(fileinfo.metadata.preview&&fileinfo.metadata.preview.filename){var pictures=navigator.getDeviceStorage('pictures');pictures.delete(fileinfo.metadata.preview.filename);}}
function fileCreated(fileinfo){var insertPosition;if(pendingPick&&fileinfo.metadata.video)
return;if(currentOverlay==='emptygallery'||currentOverlay==='scanning')
showOverlay(null);if(files.length===0||fileinfo.date>files[0].date){insertPosition=0;}
else{insertPosition=binarysearch(files,fileinfo,compareFilesByDate);}
files.splice(insertPosition,0,fileinfo);var thumbnail=createThumbnail(insertPosition);var thumbnailElts=thumbnails.querySelectorAll('.thumbnail');if(thumbnailElts.length===0)
thumbnails.appendChild(thumbnail);else
thumbnails.insertBefore(thumbnail,thumbnailElts[insertPosition]);for(var i=insertPosition;i<thumbnailElts.length;i++){thumbnailElts[i].dataset.index=i+1;}
if(currentFileIndex>=insertPosition)
currentFileIndex++;if(editedPhotoIndex>=insertPosition)
editedPhotoIndex++;if(currentView===fullscreenView){showFile(currentFileIndex);}}
function binarysearch(array,element,comparator,from,to){if(comparator===undefined)
comparator=function(a,b){if(a<b)
return-1;if(a>b)
return 1;return 0;};if(from===undefined)
return binarysearch(array,element,comparator,0,array.length);if(from===to)
return from;var mid=Math.floor((from+to)/2);var result=comparator(element,array[mid]);if(result<0)
return binarysearch(array,element,comparator,from,mid);else
return binarysearch(array,element,comparator,mid+1,to);}
function scrollToShowThumbnail(n){var selector='li[data-index="'+n+'"]';var thumbnail=thumbnails.querySelector(selector);if(thumbnail){var screenTop=thumbnails.scrollTop;var screenBottom=screenTop+thumbnails.clientHeight;var thumbnailTop=thumbnail.offsetTop;var thumbnailBottom=thumbnailTop+thumbnail.offsetHeight;var toolbarHeight=40;screenBottom-=toolbarHeight;if(thumbnailTop<screenTop){thumbnails.scrollTop=thumbnailTop;}
else if(thumbnailBottom>screenBottom){thumbnails.scrollTop=thumbnailBottom-thumbnails.clientHeight+toolbarHeight;}}}
function setView(view){if(currentView===view)
return;switch(currentView){case thumbnailSelectView:Array.forEach(thumbnails.querySelectorAll('.selected.thumbnail'),function(elt){elt.classList.remove('selected');});break;case fullscreenView:previousFrame.clear();currentFrame.clear();nextFrame.clear();delete previousFrame.filename;delete currentFrame.filename;delete nextFrame.filename;scrollToShowThumbnail(currentFileIndex);break;}
for(var i=0;i<views.length;i++){if(views[i]===view)
views[i].classList.remove('hidden');else
views[i].classList.add('hidden');}
switch(view){case thumbnailListView:thumbnails.className='list';break;case thumbnailSelectView:thumbnails.className='select';clearSelection();break;case pickView:thumbnails.className='pick';break;case fullscreenView:thumbnails.className='offscreen';fullscreenView.classList.remove('toolbarhidden');break;default:thumbnails.className='offscreen';break;}
currentView=view;}
function createThumbnail(imagenum){var li=document.createElement('li');li.dataset.index=imagenum;li.classList.add('thumbnail');var fileinfo=files[imagenum];var url=URL.createObjectURL(fileinfo.metadata.thumbnail);li.dataset.backgroundImage='url("'+url+'")';return li;}
function thumbnailOnscreen(thumbnail){if(thumbnail.dataset.backgroundImage)
thumbnail.style.backgroundImage=thumbnail.dataset.backgroundImage;}
function thumbnailOffscreen(thumbnail){if(thumbnail.dataset.backgroundImage)
thumbnail.style.backgroundImage=null;}
var pendingPick;var pickType;var pickWidth,pickHeight;var pickedFile;var cropURL;var cropEditor;function startPick(){pickType=pendingPick.source.data.type;if(pendingPick.source.data.width&&pendingPick.source.data.height){pickWidth=pendingPick.source.data.width;pickHeight=pendingPick.source.data.height;}
else{pickWidth=pickHeight=0;}
loader.load('js/ImageEditor.js',function(){setView(pickView);});}
function cropPickedImage(fileinfo){pickedFile=fileinfo;var nocrop=pendingPick.source.data.nocrop;if(nocrop){$('crop-header').textContent='';}
setView(cropView);photodb.getFile(pickedFile.name,function(file){cropURL=URL.createObjectURL(file);cropEditor=new ImageEditor(cropURL,$('crop-frame'),{},function(){if(nocrop){cropEditor.cropRegion.left=cropEditor.cropRegion.top=0;cropEditor.cropRegion.right=cropEditor.dest.w;cropEditor.cropRegion.bottom=cropEditor.dest.h;return;}
cropEditor.showCropOverlay();if(pickWidth)
cropEditor.setCropAspectRatio(pickWidth,pickHeight);else
cropEditor.setCropAspectRatio();});});}
function cropAndEndPick(){if(Array.isArray(pickType)){if(pickType.length===0||pickType.indexOf(pickedFile.type)!==-1||pickType.indexOf('image/*')!==-1){pickType=pickedFile.type;}
else if(pickType.indexOf('image/png')!==-1){pickType='image/png';}
else{pickType='image/jpeg';}}
else if(pickType==='image/*'){pickType=pickedFile.type;}
if(pickType===pickedFile.type&&!pickWidth&&!pickHeight&&(pendingPick.source.data.nocrop||!cropEditor.hasBeenCropped())){photodb.getFile(pickedFile.name,endPick);}
else{cropEditor.getCroppedRegionBlob(pickType,pickWidth,pickHeight,endPick);}}
function endPick(blob){pendingPick.postResult({type:pickType,blob:blob});cleanupPick();}
function cancelPick(){pendingPick.postError('pick cancelled');cleanupPick();}
function cleanupCrop(){if(cropURL){URL.revokeObjectURL(cropURL);cropURL=null;}
if(cropEditor){cropEditor.destroy();cropEditor=null;}}
function cleanupPick(){cleanupCrop();pendingPick=null;pickedFile=null;setView(thumbnailListView);}
window.addEventListener('mozvisibilitychange',function(){if(document.mozHidden&&pendingPick)
cancelPick();});function thumbnailClickHandler(evt){var target=evt.target;if(!target||!target.classList.contains('thumbnail'))
return;if(currentView===thumbnailListView||currentView===fullscreenView){loader.load('js/frame_scripts.js',function(){showFile(parseInt(target.dataset.index));});}
else if(currentView===thumbnailSelectView){updateSelection(target);}
else if(currentView===pickView){cropPickedImage(files[parseInt(target.dataset.index)]);}}
function clearSelection(){selectedFileNames=[];selectedFileNamesToBlobs={};$('thumbnails-delete-button').classList.add('disabled');$('thumbnails-share-button').classList.add('disabled');$('thumbnails-number-selected').textContent=navigator.mozL10n.get('number-selected2',{n:0});}
function updateSelection(thumbnail){thumbnail.classList.toggle('selected');var selected=thumbnail.classList.contains('selected');var index=parseInt(thumbnail.dataset.index);var filename=files[index].name;if(selected){selectedFileNames.push(filename);if(files[index].metadata.video){getVideoFile(files[index].metadata.video,function(file){selectedFileNamesToBlobs[filename]=file;});}
else{photodb.getFile(filename,function(file){selectedFileNamesToBlobs[filename]=file;});}}
else{delete selectedFileNamesToBlobs[filename];var i=selectedFileNames.indexOf(filename);if(i!==-1)
selectedFileNames.splice(i,1);}
var numSelected=selectedFileNames.length;var msg=navigator.mozL10n.get('number-selected2',{n:numSelected});$('thumbnails-number-selected').textContent=msg;if(numSelected===0){$('thumbnails-delete-button').classList.add('disabled');$('thumbnails-share-button').classList.add('disabled');}
else{$('thumbnails-delete-button').classList.remove('disabled');$('thumbnails-share-button').classList.remove('disabled');}}
function launchCameraApp(){var a=new MozActivity({name:'record',data:{type:'photos'}});}
function deleteSelectedItems(){var selected=thumbnails.querySelectorAll('.selected.thumbnail');if(selected.length===0)
return;showConfirmDialog({message:navigator.mozL10n.get('delete-n-items?',{n:selected.length}),cancelText:navigator.mozL10n.get('cancel'),confirmText:navigator.mozL10n.get('delete'),danger:true},function(){for(var i=0;i<selected.length;i++){selected[i].classList.toggle('selected');deleteFile(parseInt(selected[i].dataset.index,10));}
clearSelection();});}
function showConfirmDialog(options,onConfirm,onCancel){LazyLoader.load('shared/style/confirm.css',function(){var dialog=$('confirm-dialog');var msgEle=$('confirm-msg');var cancelButton=$('confirm-cancel');var confirmButton=$('confirm-ok');msgEle.textContent=options.message;cancelButton.textContent=options.cancelText||navigator.mozL10n.get('cancel');confirmButton.textContent=options.confirmText||navigator.mozL10n.get('ok');if(options.danger){confirmButton.classList.add('danger');}
else{confirmButton.classList.remove('danger');}
dialog.classList.remove('hidden');var onCancelClick=function(ev){close(ev);if(onCancel){onCancel();}
return false;};var onConfirmClick=function(ev){close(ev);if(onConfirm){onConfirm();}
return false;};cancelButton.addEventListener('click',onCancelClick);confirmButton.addEventListener('click',onConfirmClick);function close(ev){dialog.classList.add('hidden');cancelButton.removeEventListener('click',onCancelClick);confirmButton.removeEventListener('click',onConfirmClick);ev.preventDefault();ev.stopPropagation();return false;}});}
function shareSelectedItems(){var blobs=selectedFileNames.map(function(name){return selectedFileNamesToBlobs[name];});share(blobs);}
function share(blobs){if(blobs.length===0)
return;var names=[],types=[],fullpaths=[];blobs.forEach(function(blob){var name=blob.name;fullpaths.push(name);name=name.substring(name.lastIndexOf('/')+1);names.push(name);var type=blob.type;if(type)
type=type.substring(0,type.indexOf('/'));types.push(type);});var type;if(types.length===1||types.every(function(t){return t===types[0];}))
type=types[0]+'/*';else
type='multipart/mixed';var a=new MozActivity({name:'share',data:{type:type,number:blobs.length,blobs:blobs,filenames:names,filepaths:fullpaths}});a.onerror=function(e){if(a.error.name==='NO_PROVIDER'){var msg=navigator.mozL10n.get('share-noprovider');alert(msg);}
else{console.warn('share activity error:',a.error.name);}};}
function resizeHandler(){if(fullscreenView.offsetWidth===0&&fullscreenView.offsetHeight===0)
return;if(currentView===fullscreenView){currentFrame.resize();previousFrame.reset();nextFrame.reset();setFramesPosition();}}
var currentOverlay;function showOverlay(id){currentOverlay=id;var title,text;switch(currentOverlay){case null:$('overlay').classList.add('hidden');return;case'nocard':title=navigator.mozL10n.get('nocard2-title');text=navigator.mozL10n.get('nocard2-text');break;case'pluggedin':title=navigator.mozL10n.get('pluggedin2-title');text=navigator.mozL10n.get('pluggedin2-text');break;case'scanning':title=navigator.mozL10n.get('scanning-title');text=navigator.mozL10n.get('scanning-text');break;case'emptygallery':title=navigator.mozL10n.get('emptygallery2-title');text=navigator.mozL10n.get('emptygallery2-text');break;default:console.warn('Reference to undefined overlay',currentOverlay);return;}
$('overlay-title').textContent=title;$('overlay-text').textContent=text;$('overlay').classList.remove('hidden');}
$('overlay').addEventListener('click',function dummyHandler(){});