;'use strict';(function(window){var gL10nData={};var gTextProp='textContent';var gLanguage='';var gMacros={};var gReadyState='loading';var gAsyncResourceLoading=true;var gDEBUG=1;function consoleLog(message){if(gDEBUG>=2){console.log('[l10n] '+message);}};function consoleWarn(message){if(gDEBUG){console.warn('[l10n] '+message);}};function getL10nResourceLinks(){return document.querySelectorAll('link[type="application/l10n"]');}
function getL10nDictionary(){var script=document.querySelector('script[type="application/l10n"]');return script?JSON.parse(script.innerHTML):null;}
function getTranslatableChildren(element){return element?element.querySelectorAll('*[data-l10n-id]'):[];}
function getL10nAttributes(element){if(!element)
return{};var l10nId=element.getAttribute('data-l10n-id');var l10nArgs=element.getAttribute('data-l10n-args');var args={};if(l10nArgs){try{args=JSON.parse(l10nArgs);}catch(e){consoleWarn('could not parse arguments for #'+l10nId);}}
return{id:l10nId,args:args};}
function fireL10nReadyEvent(){var evtObject=document.createEvent('Event');evtObject.initEvent('localized',false,false);evtObject.language=gLanguage;window.dispatchEvent(evtObject);}
function parseResource(href,lang,successCallback,failureCallback){var baseURL=href.replace(/\/[^\/]*$/,'/');function evalString(text){if(text.lastIndexOf('\\')<0)
return text;return text.replace(/\\\\/g,'\\').replace(/\\n/g,'\n').replace(/\\r/g,'\r').replace(/\\t/g,'\t').replace(/\\b/g,'\b').replace(/\\f/g,'\f').replace(/\\{/g,'{').replace(/\\}/g,'}').replace(/\\"/g,'"').replace(/\\'/g,"'");}
function parseProperties(text){var dictionary=[];var reBlank=/^\s*|\s*$/;var reComment=/^\s*#|^\s*$/;var reSection=/^\s*\[(.*)\]\s*$/;var reImport=/^\s*@import\s+url\((.*)\)\s*$/i;var reSplit=/^([^=\s]*)\s*=\s*(.+)$/;function parseRawLines(rawText,extendedSyntax){var entries=rawText.replace(reBlank,'').split(/[\r\n]+/);var currentLang='*';var genericLang=lang.replace(/-[a-z]+$/i,'');var skipLang=false;var match='';for(var i=0;i<entries.length;i++){var line=entries[i];if(reComment.test(line))
continue;if(extendedSyntax){if(reSection.test(line)){match=reSection.exec(line);currentLang=match[1];skipLang=(currentLang!=='*')&&(currentLang!==lang)&&(currentLang!==genericLang);continue;}else if(skipLang){continue;}
if(reImport.test(line)){match=reImport.exec(line);loadImport(baseURL+match[1]);}}
var tmp=line.match(reSplit);if(tmp&&tmp.length==3){dictionary[tmp[1]]=evalString(tmp[2]);}}}
function loadImport(url){loadResource(url,function(content){parseRawLines(content,false);},null,false);}
parseRawLines(text,true);return dictionary;}
function loadResource(url,onSuccess,onFailure,asynchronous){onSuccess=onSuccess||function _onSuccess(data){};onFailure=onFailure||function _onFailure(){consoleWarn(url+' not found.');};var xhr=new XMLHttpRequest();xhr.open('GET',url,asynchronous);if(xhr.overrideMimeType){xhr.overrideMimeType('text/plain; charset=utf-8');}
xhr.onreadystatechange=function(){if(xhr.readyState==4){if(xhr.status==200||xhr.status===0){onSuccess(xhr.responseText);}else{onFailure();}}};xhr.onerror=onFailure;xhr.ontimeout=onFailure;try{xhr.send(null);}catch(e){onFailure();}}
loadResource(href,function(response){var data=parseProperties(response);for(var key in data){var id,prop,index=key.lastIndexOf('.');if(index>0){id=key.substring(0,index);prop=key.substr(index+1);}else{id=key;prop=gTextProp;}
if(!gL10nData[id]){gL10nData[id]={};}
gL10nData[id][prop]=data[key];}
if(successCallback){successCallback();}},failureCallback,gAsyncResourceLoading);};function loadLocale(lang,callback){callback=callback||function _callback(){};clear();gLanguage=lang;var langLinks=getL10nResourceLinks();var langCount=langLinks.length;if(langCount==0){var dict=getL10nDictionary();if(dict&&dict.locales&&dict.default_locale){consoleLog('using the embedded JSON directory, early way out');gL10nData=dict.locales[lang]||dict.locales[dict.default_locale];callback();}else{consoleLog('no resource to load, early way out');}
fireL10nReadyEvent(lang);gReadyState='complete';return;}
var onResourceLoaded=null;var gResourceCount=0;onResourceLoaded=function(){gResourceCount++;if(gResourceCount>=langCount){callback();fireL10nReadyEvent(lang);gReadyState='complete';}};function l10nResourceLink(link){var href=link.href;var type=link.type;this.load=function(lang,callback){var applied=lang;parseResource(href,lang,callback,function(){consoleWarn(href+' not found.');applied='';});return applied;};}
for(var i=0;i<langCount;i++){var resource=new l10nResourceLink(langLinks[i]);var rv=resource.load(lang,onResourceLoaded);if(rv!=lang){consoleWarn('"'+lang+'" resource not found');gLanguage='';}}}
function clear(){gL10nData={};gLanguage='';}
function getPluralRules(lang){var locales2rules={'af':3,'ak':4,'am':4,'ar':1,'asa':3,'az':0,'be':11,'bem':3,'bez':3,'bg':3,'bh':4,'bm':0,'bn':3,'bo':0,'br':20,'brx':3,'bs':11,'ca':3,'cgg':3,'chr':3,'cs':12,'cy':17,'da':3,'de':3,'dv':3,'dz':0,'ee':3,'el':3,'en':3,'eo':3,'es':3,'et':3,'eu':3,'fa':0,'ff':5,'fi':3,'fil':4,'fo':3,'fr':5,'fur':3,'fy':3,'ga':8,'gd':24,'gl':3,'gsw':3,'gu':3,'guw':4,'gv':23,'ha':3,'haw':3,'he':2,'hi':4,'hr':11,'hu':0,'id':0,'ig':0,'ii':0,'is':3,'it':3,'iu':7,'ja':0,'jmc':3,'jv':0,'ka':0,'kab':5,'kaj':3,'kcg':3,'kde':0,'kea':0,'kk':3,'kl':3,'km':0,'kn':0,'ko':0,'ksb':3,'ksh':21,'ku':3,'kw':7,'lag':18,'lb':3,'lg':3,'ln':4,'lo':0,'lt':10,'lv':6,'mas':3,'mg':4,'mk':16,'ml':3,'mn':3,'mo':9,'mr':3,'ms':0,'mt':15,'my':0,'nah':3,'naq':7,'nb':3,'nd':3,'ne':3,'nl':3,'nn':3,'no':3,'nr':3,'nso':4,'ny':3,'nyn':3,'om':3,'or':3,'pa':3,'pap':3,'pl':13,'ps':3,'pt':3,'rm':3,'ro':9,'rof':3,'ru':11,'rwk':3,'sah':0,'saq':3,'se':7,'seh':3,'ses':0,'sg':0,'sh':11,'shi':19,'sk':12,'sl':14,'sma':7,'smi':7,'smj':7,'smn':7,'sms':7,'sn':3,'so':3,'sq':3,'sr':11,'ss':3,'ssy':3,'st':3,'sv':3,'sw':3,'syr':3,'ta':3,'te':3,'teo':3,'th':0,'ti':4,'tig':3,'tk':3,'tl':4,'tn':3,'to':0,'tr':0,'ts':3,'tzm':22,'uk':11,'ur':3,'ve':3,'vi':0,'vun':3,'wa':4,'wae':3,'wo':0,'xh':3,'xog':3,'yo':0,'zh':0,'zu':3};function isIn(n,list){return list.indexOf(n)!==-1;}
function isBetween(n,start,end){return start<=n&&n<=end;}
var pluralRules={'0':function(n){return'other';},'1':function(n){if((isBetween((n%100),3,10)))
return'few';if(n===0)
return'zero';if((isBetween((n%100),11,99)))
return'many';if(n==2)
return'two';if(n==1)
return'one';return'other';},'2':function(n){if(n!==0&&(n%10)===0)
return'many';if(n==2)
return'two';if(n==1)
return'one';return'other';},'3':function(n){if(n==1)
return'one';return'other';},'4':function(n){if((isBetween(n,0,1)))
return'one';return'other';},'5':function(n){if((isBetween(n,0,2))&&n!=2)
return'one';return'other';},'6':function(n){if(n===0)
return'zero';if((n%10)==1&&(n%100)!=11)
return'one';return'other';},'7':function(n){if(n==2)
return'two';if(n==1)
return'one';return'other';},'8':function(n){if((isBetween(n,3,6)))
return'few';if((isBetween(n,7,10)))
return'many';if(n==2)
return'two';if(n==1)
return'one';return'other';},'9':function(n){if(n===0||n!=1&&(isBetween((n%100),1,19)))
return'few';if(n==1)
return'one';return'other';},'10':function(n){if((isBetween((n%10),2,9))&&!(isBetween((n%100),11,19)))
return'few';if((n%10)==1&&!(isBetween((n%100),11,19)))
return'one';return'other';},'11':function(n){if((isBetween((n%10),2,4))&&!(isBetween((n%100),12,14)))
return'few';if((n%10)===0||(isBetween((n%10),5,9))||(isBetween((n%100),11,14)))
return'many';if((n%10)==1&&(n%100)!=11)
return'one';return'other';},'12':function(n){if((isBetween(n,2,4)))
return'few';if(n==1)
return'one';return'other';},'13':function(n){if((isBetween((n%10),2,4))&&!(isBetween((n%100),12,14)))
return'few';if(n!=1&&(isBetween((n%10),0,1))||(isBetween((n%10),5,9))||(isBetween((n%100),12,14)))
return'many';if(n==1)
return'one';return'other';},'14':function(n){if((isBetween((n%100),3,4)))
return'few';if((n%100)==2)
return'two';if((n%100)==1)
return'one';return'other';},'15':function(n){if(n===0||(isBetween((n%100),2,10)))
return'few';if((isBetween((n%100),11,19)))
return'many';if(n==1)
return'one';return'other';},'16':function(n){if((n%10)==1&&n!=11)
return'one';return'other';},'17':function(n){if(n==3)
return'few';if(n===0)
return'zero';if(n==6)
return'many';if(n==2)
return'two';if(n==1)
return'one';return'other';},'18':function(n){if(n===0)
return'zero';if((isBetween(n,0,2))&&n!==0&&n!=2)
return'one';return'other';},'19':function(n){if((isBetween(n,2,10)))
return'few';if((isBetween(n,0,1)))
return'one';return'other';},'20':function(n){if((isBetween((n%10),3,4)||((n%10)==9))&&!(isBetween((n%100),10,19)||isBetween((n%100),70,79)||isBetween((n%100),90,99)))
return'few';if((n%1000000)===0&&n!==0)
return'many';if((n%10)==2&&!isIn((n%100),[12,72,92]))
return'two';if((n%10)==1&&!isIn((n%100),[11,71,91]))
return'one';return'other';},'21':function(n){if(n===0)
return'zero';if(n==1)
return'one';return'other';},'22':function(n){if((isBetween(n,0,1))||(isBetween(n,11,99)))
return'one';return'other';},'23':function(n){if((isBetween((n%10),1,2))||(n%20)===0)
return'one';return'other';},'24':function(n){if((isBetween(n,3,10)||isBetween(n,13,19)))
return'few';if(isIn(n,[2,12]))
return'two';if(isIn(n,[1,11]))
return'one';return'other';}};var index=locales2rules[lang.replace(/-.*$/,'')];if(!(index in pluralRules)){consoleWarn('plural form unknown for ['+lang+']');return function(){return'other';};}
return pluralRules[index];}
gMacros.plural=function(str,param,key,prop){var n=parseFloat(param);if(isNaN(n))
return str;if(prop!=gTextProp)
return str;if(!gMacros._pluralRules){gMacros._pluralRules=getPluralRules(gLanguage);}
var index='['+gMacros._pluralRules(n)+']';if(n===0&&(key+'[zero]')in gL10nData){str=gL10nData[key+'[zero]'][prop];}else if(n==1&&(key+'[one]')in gL10nData){str=gL10nData[key+'[one]'][prop];}else if(n==2&&(key+'[two]')in gL10nData){str=gL10nData[key+'[two]'][prop];}else if((key+index)in gL10nData){str=gL10nData[key+index][prop];}else if((key+'[other]')in gL10nData){str=gL10nData[key+'[other]'][prop];}
return str;};function getL10nData(key,args){var data=gL10nData[key];if(!data){consoleWarn('#'+key+' is undefined.');}
var rv={};for(var prop in data){var str=data[prop];str=substIndexes(str,args,key,prop);str=substArguments(str,args,key);rv[prop]=str;}
return rv;}
function substIndexes(str,args,key,prop){var reIndex=/\{\[\s*([a-zA-Z]+)\(([a-zA-Z]+)\)\s*\]\}/;var reMatch=reIndex.exec(str);if(!reMatch||!reMatch.length)
return str;var macroName=reMatch[1];var paramName=reMatch[2];var param;if(args&&paramName in args){param=args[paramName];}else if(paramName in gL10nData){param=gL10nData[paramName];}
if(macroName in gMacros){var macro=gMacros[macroName];str=macro(str,param,key,prop);}
return str;}
function substArguments(str,args,key){var reArgs=/\{\{\s*(.+?)\s*\}\}/;var match=reArgs.exec(str);while(match){if(!match||match.length<2)
return str;var arg=match[1];var sub='';if(args&&arg in args){sub=args[arg];}else if(arg in gL10nData){sub=gL10nData[arg][gTextProp];}else{consoleLog('argument {{'+arg+'}} for #'+key+' is undefined.');return str;}
str=str.substring(0,match.index)+sub+
str.substr(match.index+match[0].length);match=reArgs.exec(str);}
return str;}
function translateElement(element){var l10n=getL10nAttributes(element);if(!l10n.id){return;}
var data=getL10nData(l10n.id,l10n.args);if(!data){consoleWarn('#'+l10n.id+' is undefined.');return;}
if(data[gTextProp]){if(element.children.length===0){element[gTextProp]=data[gTextProp];}else{var children=element.childNodes;var found=false;for(var i=0,l=children.length;i<l;i++){if(children[i].nodeType===3&&/\S/.test(children[i].nodeValue)){if(found){children[i].nodeValue='';}else{children[i].nodeValue=data[gTextProp];found=true;}}}
if(!found){var textNode=document.createTextNode(data[gTextProp]);element.insertBefore(textNode,element.firstChild);}}
delete data[gTextProp];}
for(var k in data){element[k]=data[k];}}
function translateFragment(element){element=element||document.documentElement;var children=getTranslatableChildren(element);var elementCount=children.length;for(var i=0;i<elementCount;i++){translateElement(children[i]);}
translateElement(element);}
function l10nStartup(){gReadyState='interactive';consoleLog('loading ['+navigator.language+'] resources, '+
(gAsyncResourceLoading?'asynchronously.':'synchronously.'));if(document.documentElement.lang===navigator.language){loadLocale(navigator.language);}else{loadLocale(navigator.language,translateFragment);}}
if(typeof(document)!=='undefined'){if(document.readyState==='complete'||document.readyState==='interactive'){window.setTimeout(l10nStartup);}else{document.addEventListener('DOMContentLoaded',l10nStartup);}}
if('mozSettings'in navigator&&navigator.mozSettings){navigator.mozSettings.addObserver('language.current',function(event){loadLocale(event.settingValue,translateFragment);});}
navigator.mozL10n={get:function l10n_get(key,args,fallback){var data=getL10nData(key,args)||fallback;if(data){return'textContent'in data?data.textContent:'';}
return'{{'+key+'}}';},get language(){return{get code(){return gLanguage;},set code(lang){loadLocale(lang,translateFragment);},get direction(){var rtlList=['ar','he','fa','ps','ur'];return(rtlList.indexOf(gLanguage)>=0)?'rtl':'ltr';}};},translate:translateFragment,get dictionary(){return JSON.parse(JSON.stringify(gL10nData));},get readyState(){return gReadyState;},ready:function l10n_ready(callback){if(!callback)
return;if(gReadyState=='complete'){window.setTimeout(callback);}else{window.addEventListener('localized',callback);}}};consoleLog('library loaded.');})(this);;'use strict';(function(){if(MouseEventShim)
return;try{document.createEvent('TouchEvent');}catch(e){return;}
var starttouch;var target;var emitclick;window.addEventListener('mousedown',discardEvent,true);window.addEventListener('mouseup',discardEvent,true);window.addEventListener('mousemove',discardEvent,true);window.addEventListener('click',discardEvent,true);function discardEvent(e){if(e.isTrusted){e.stopImmediatePropagation();if(e.type==='click')
e.preventDefault();}}
window.addEventListener('touchstart',handleTouchStart);window.addEventListener('touchmove',handleTouchMove);window.addEventListener('touchend',handleTouchEnd);window.addEventListener('touchcancel',handleTouchEnd);function handleTouchStart(e){if(starttouch)
return;if(e.defaultPrevented)
return;try{e.changedTouches[0].target.ownerDocument;}
catch(e){return;}
starttouch=e.changedTouches[0];target=starttouch.target;emitclick=true;emitEvent('mousemove',target,starttouch);var result=emitEvent('mousedown',target,starttouch);if(!result){e.preventDefault();emitclick=false;}}
function handleTouchEnd(e){if(!starttouch)
return;if(MouseEventShim.capturing){MouseEventShim.capturing=false;MouseEventShim.captureTarget=null;}
for(var i=0;i<e.changedTouches.length;i++){var touch=e.changedTouches[i];if(touch.identifier!==starttouch.identifier)
continue;emitEvent('mouseup',target,touch);if(emitclick)
emitEvent('click',starttouch.target,touch);starttouch=null;return;}}
function handleTouchMove(e){if(!starttouch)
return;for(var i=0;i<e.changedTouches.length;i++){var touch=e.changedTouches[i];if(touch.identifier!==starttouch.identifier)
continue;if(e.defaultPrevented)
return;var dx=Math.abs(touch.screenX-starttouch.screenX);var dy=Math.abs(touch.screenY-starttouch.screenY);if(dx>MouseEventShim.dragThresholdX||dy>MouseEventShim.dragThresholdY){emitclick=false;}
var tracking=MouseEventShim.trackMouseMoves&&!MouseEventShim.capturing;if(tracking){var oldtarget=target;var newtarget=document.elementFromPoint(touch.clientX,touch.clientY);if(newtarget===null){newtarget=oldtarget;}
if(newtarget!==oldtarget){leave(oldtarget,newtarget,touch);target=newtarget;}}
else if(MouseEventShim.captureTarget){target=MouseEventShim.captureTarget;}
emitEvent('mousemove',target,touch);if(tracking&&newtarget!==oldtarget){enter(newtarget,oldtarget,touch);}}}
function contains(a,b){return(a.compareDocumentPosition(b)&16)!==0;}
function leave(oldtarget,newtarget,touch){emitEvent('mouseout',oldtarget,touch,newtarget);for(var e=oldtarget;!contains(e,newtarget);e=e.parentNode){emitEvent('mouseleave',e,touch,newtarget);}}
function enter(newtarget,oldtarget,touch){emitEvent('mouseover',newtarget,touch,oldtarget);for(var e=newtarget;!contains(e,oldtarget);e=e.parentNode){emitEvent('mouseenter',e,touch,oldtarget);}}
function emitEvent(type,target,touch,relatedTarget){var synthetic=document.createEvent('MouseEvents');var bubbles=(type!=='mouseenter'&&type!=='mouseleave');var count=(type==='mousedown'||type==='mouseup'||type==='click')?1:0;synthetic.initMouseEvent(type,bubbles,true,window,count,touch.screenX,touch.screenY,touch.clientX,touch.clientY,false,false,false,false,0,relatedTarget||null);try{return target.dispatchEvent(synthetic);}
catch(e){console.warn('Exception calling dispatchEvent',type,e);return true;}}}());var MouseEventShim={getEventTimestamp:function(e){if(e.isTrusted)
return e.timeStamp;else
return e.timeStamp/1000;},trackMouseMoves:true,setCapture:function(target){this.capturing=true;if(target)
this.captureTarget=target;},capturing:false,dragThresholdX:25,dragThresholdY:25};;'use strict';var MediaDB=(function(){function MediaDB(mediaType,metadataParser,options){this.mediaType=mediaType;this.metadataParser=metadataParser;if(!options)
options={};this.indexes=options.indexes||[];this.version=options.version||1;this.mimeTypes=options.mimeTypes;this.autoscan=(options.autoscan!==undefined)?options.autoscan:true;this.state=MediaDB.OPENING;this.scanning=false;this.batchHoldTime=options.batchHoldTime||100;this.batchSize=options.batchSize||0;this.dbname='MediaDB/'+this.mediaType+'/';var media=this;this.details={eventListeners:{},pendingInsertions:[],pendingDeletions:[],whenDoneProcessing:[],pendingCreateNotifications:[],pendingDeleteNotifications:[],pendingNotificationTimer:null,newestFileModTime:0};if(!this.metadataParser){this.metadataParser=function(file,callback){setTimeout(function(){callback({});},0);};}
var openRequest=indexedDB.open(this.dbname,this.version*MediaDB.VERSION);openRequest.onerror=function(e){console.error('MediaDB():',openRequest.error.name);};openRequest.onblocked=function(e){console.error('indexedDB.open() is blocked in MediaDB()');};openRequest.onupgradeneeded=function(e){var db=openRequest.result;var existingStoreNames=db.objectStoreNames;for(var i=0;i<existingStoreNames.length;i++){db.deleteObjectStore(existingStoreNames[i]);}
var filestore=db.createObjectStore('files',{keyPath:'name'});filestore.createIndex('date','date');media.indexes.forEach(function(indexName){if(indexName==='name'||indexName==='date')
return;filestore.createIndex(indexName,indexName);});};openRequest.onsuccess=function(e){media.db=openRequest.result;media.db.onerror=function(event){console.error('MediaDB: ',event.target.error&&event.target.error.name);};var cursorRequest=media.db.transaction('files','readonly').objectStore('files').index('date').openCursor(null,'prev');cursorRequest.onerror=function(){console.error('MediaDB initialization error',cursorRequest.error);};cursorRequest.onsuccess=function(){var cursor=cursorRequest.result;if(cursor){media.details.newestFileModTime=cursor.value.date;}
else{media.details.newestFileModTime=0;}
initDeviceStorage();};};function initDeviceStorage(){var details=media.details;media.storage=navigator.getDeviceStorage(mediaType);details.storages=navigator.getDeviceStorages(mediaType);details.availability={};getStorageAvailability();function getStorageAvailability(){var next=0;getNextAvailability();function getNextAvailability(){if(next>=details.storages.length){setupHandlers();return;}
var s=details.storages[next++];var name=s.storageName;var req=s.available();req.onsuccess=function(e){details.availability[name]=req.result;getNextAvailability();};req.onerror=function(e){details.availability[name]='unavailable';getNextAvailability();};}}
function setupHandlers(){for(var i=0;i<details.storages.length;i++)
details.storages[i].addEventListener('change',changeHandler);details.dsEventListener=changeHandler;sendInitialEvent();}
function sendInitialEvent(){var state=getState(details.availability);changeState(media,state);if(media.autoscan)
scan(media);}
function getState(availability){var n=0;var a=0;var u=0;var s=0;for(var name in availability){n++;switch(availability[name]){case'available':a++;break;case'unavailable':u++;break;case'shared':s++;break;}}
if(s>0)
return MediaDB.UNMOUNTED;if(u===n)
return MediaDB.NOCARD;return MediaDB.READY;}
function changeHandler(e){switch(e.reason){case'modified':case'deleted':fileChangeHandler(e);return;case'available':case'unavailable':case'shared':volumeChangeHandler(e);return;default:return;}}
function volumeChangeHandler(e){var storageName=e.target.storageName;if(details.availability[storageName]===e.reason)
return;var oldState=media.state;details.availability[storageName]=e.reason;var newState=getState(details.availability);if(newState!==oldState){changeState(media,newState);if(newState===MediaDB.READY){if(media.autoscan)
scan(media);}
else{endscan(media);}}
else if(newState===MediaDB.READY){if(e.reason==='available'){dispatchEvent(media,'ready');if(media.autoscan)
scan(media);}
else if(e.reason==='unavailable'){dispatchEvent(media,'cardremoved');deleteAllFiles(storageName);}}}
function fileChangeHandler(e){var filename=e.path;if(ignoreName(filename))
return;if(e.reason==='modified')
insertRecord(media,filename);else
deleteRecord(media,filename);}
function deleteAllFiles(storageName){var storagePrefix=storageName?'/'+storageName+'/':'';var store=media.db.transaction('files').objectStore('files');var cursorRequest=store.openCursor();cursorRequest.onsuccess=function(){var cursor=cursorRequest.result;if(cursor){if(cursor.value.name.startsWith(storagePrefix)){deleteRecord(media,cursor.value.name);}
cursor.continue();}};}}}
MediaDB.prototype={close:function close(){this.db.close();for(var i=0;i<this.details.storages.length;i++){var s=this.details.storages[i];s.removeEventListener('change',this.details.dsEventListener);}
changeState(this,MediaDB.CLOSED);},addEventListener:function addEventListener(type,listener){if(!this.details.eventListeners.hasOwnProperty(type))
this.details.eventListeners[type]=[];var listeners=this.details.eventListeners[type];if(listeners.indexOf(listener)!==-1)
return;listeners.push(listener);},removeEventListener:function removeEventListener(type,listener){if(!this.details.eventListeners.hasOwnProperty(type))
return;var listeners=this.details.eventListeners[type];var position=listeners.indexOf(listener);if(position===-1)
return;listeners.splice(position,1);},getFile:function getFile(filename,callback,errback){if(this.state!==MediaDB.READY)
throw Error('MediaDB is not ready. State: '+this.state);var getRequest=this.storage.get(filename);getRequest.onsuccess=function(){callback(getRequest.result);};getRequest.onerror=function(){var errmsg=getRequest.error&&getRequest.error.name;if(errback)
errback(errmsg);else
console.error('MediaDB.getFile:',errmsg);};},deleteFile:function deleteFile(filename){if(this.state!==MediaDB.READY)
throw Error('MediaDB is not ready. State: '+this.state);this.storage.delete(filename).onerror=function(e){console.error('MediaDB.deleteFile(): Failed to delete',filename,'from DeviceStorage:',e.target.error);};},addFile:function addFile(filename,file){if(this.state!==MediaDB.READY)
throw Error('MediaDB is not ready. State: '+this.state);var media=this;var deletereq=media.storage.delete(filename);deletereq.onsuccess=deletereq.onerror=save;function save(){var request=media.storage.addNamed(file,filename);request.onerror=function(){console.error('MediaDB: Failed to store',filename,'in DeviceStorage:',request.error);};}},updateMetadata:function(filename,metadata,callback){if(this.state===MediaDB.OPENING)
throw Error('MediaDB is not ready. State: '+this.state);var media=this;var read=media.db.transaction('files','readonly').objectStore('files').get(filename);read.onerror=function(){console.error('MediaDB.updateMetadata called with unknown filename');};read.onsuccess=function(){var fileinfo=read.result;Object.keys(metadata).forEach(function(key){fileinfo.metadata[key]=metadata[key];});var write=media.db.transaction('files','readwrite').objectStore('files').put(fileinfo);write.onerror=function(){console.error('MediaDB.updateMetadata: database write failed',write.error&&write.error.name);};if(callback){write.onsuccess=function(){callback();};}};},count:function(key,range,callback){if(this.state!==MediaDB.READY)
throw Error('MediaDB is not ready. State: '+this.state);if(arguments.length===1){callback=key;range=undefined;key=undefined;}
else if(arguments.length===2){callback=range;range=key;key=undefined;}
var store=this.db.transaction('files').objectStore('files');if(key&&key!=='name')
store=store.index(key);var countRequest=store.count(range||null);countRequest.onerror=function(){console.error('MediaDB.count() failed with',countRequest.error);};countRequest.onsuccess=function(e){callback(e.target.result);};},enumerate:function enumerate(key,range,direction,callback){if(this.state!==MediaDB.READY)
throw Error('MediaDB is not ready. State: '+this.state);var handle={state:'enumerating'};if(arguments.length===1){callback=key;key=undefined;}
else if(arguments.length===2){callback=range;range=undefined;}
else if(arguments.length===3){callback=direction;direction=undefined;}
var store=this.db.transaction('files').objectStore('files');if(key&&key!=='name')
store=store.index(key);var cursorRequest=store.openCursor(range||null,direction||'next');cursorRequest.onerror=function(){console.error('MediaDB.enumerate() failed with',cursorRequest.error);handle.state='error';};cursorRequest.onsuccess=function(){if(handle.state==='cancelling'){handle.state='cancelled';return;}
var cursor=cursorRequest.result;if(cursor){try{if(!cursor.value.fail)
callback(cursor.value);}
catch(e){console.warn('MediaDB.enumerate(): callback threw',e);}
cursor.continue();}
else{handle.state='complete';callback(null);}};return handle;},enumerateAll:function enumerateAll(key,range,direction,callback){var batch=[];if(arguments.length===1){callback=key;key=undefined;}
else if(arguments.length===2){callback=range;range=undefined;}
else if(arguments.length===3){callback=direction;direction=undefined;}
return this.enumerate(key,range,direction,function(fileinfo){if(fileinfo!==null)
batch.push(fileinfo);else
callback(batch);});},cancelEnumeration:function cancelEnumeration(handle){if(handle.state==='enumerating')
handle.state='cancelling';},getAll:function getAll(callback){if(this.state!==MediaDB.READY)
throw Error('MediaDB is not ready. State: '+this.state);var store=this.db.transaction('files').objectStore('files');var request=store.mozGetAll();request.onerror=function(){console.error('MediaDB.getAll() failed with',request.error);};request.onsuccess=function(){var all=request.result;var good=all.filter(function(fileinfo){return!fileinfo.fail;});callback(good);};},scan:function(){scan(this);},freeSpace:function freeSpace(callback){if(this.state!==MediaDB.READY)
throw Error('MediaDB is not ready. State: '+this.state);var freereq=this.storage.freeSpace();freereq.onsuccess=function(){callback(freereq.result);};}};MediaDB.VERSION=2;MediaDB.OPENING='opening';MediaDB.READY='ready';MediaDB.NOCARD='nocard';MediaDB.UNMOUNTED='unmounted';MediaDB.CLOSED='closed';function ignore(media,file){if(ignoreName(file.name))
return true;if(media.mimeTypes&&media.mimeTypes.indexOf(file.type)===-1)
return true;return false;}
function ignoreName(filename){return(filename[0]==='.'||filename.indexOf('/.')!==-1);}
function scan(media){media.scanning=true;dispatchEvent(media,'scanstart');quickScan(media.details.newestFileModTime);function quickScan(timestamp){var cursor;if(timestamp>0){media.details.firstscan=false;cursor=media.storage.enumerate('',{since:new Date(timestamp+1)});}
else{media.details.firstscan=true;media.details.records=[];cursor=media.storage.enumerate('');}
cursor.onsuccess=function(){if(!media.scanning)
return;var file=cursor.result;if(file){if(!ignore(media,file))
insertRecord(media,file);cursor.continue();}
else{whenDoneProcessing(media,function(){sendNotifications(media);if(media.details.firstscan){endscan(media);}
else{fullScan();}});}};cursor.onerror=function(){console.warning('Error while scanning',cursor.error);endscan(media);};}
function fullScan(){if(media.state!==MediaDB.READY){endscan(media);return;}
var dsfiles=[];var cursor=media.storage.enumerate('');cursor.onsuccess=function(){if(!media.scanning)
return;var file=cursor.result;if(file){if(!ignore(media,file)){dsfiles.push(file);}
cursor.continue();}
else{getDBFiles();}};cursor.onerror=function(){console.warning('Error while scanning',cursor.error);endscan(media);};function getDBFiles(){var store=media.db.transaction('files').objectStore('files');var getAllRequest=store.mozGetAll();getAllRequest.onsuccess=function(){if(!media.scanning)
return;var dbfiles=getAllRequest.result;compareLists(dbfiles,dsfiles);};}
function compareLists(dbfiles,dsfiles){dsfiles.sort(function(a,b){if(a.name<b.name)
return-1;else
return 1;});var dsindex=0,dbindex=0;while(true){var dsfile;if(dsindex<dsfiles.length)
dsfile=dsfiles[dsindex];else
dsfile=null;var dbfile;if(dbindex<dbfiles.length)
dbfile=dbfiles[dbindex];else
dbfile=null;if(dsfile===null&&dbfile===null)
break;if(dbfile===null){insertRecord(media,dsfile);dsindex++;continue;}
if(dsfile===null){deleteRecord(media,dbfile.name);dbindex++;continue;}
if(dsfile.name===dbfile.name){var lastModified=dsfile.lastModifiedDate;if((lastModified&&lastModified.getTime()!==dbfile.date)||dsfile.size!==dbfile.size){deleteRecord(media,dbfile.name);insertRecord(media,dsfile);}
dsindex++;dbindex++;continue;}
if(dsfile.name<dbfile.name){insertRecord(media,dsfile);dsindex++;continue;}
if(dsfile.name>dbfile.name){deleteRecord(media,dbfile.name);dbindex++;continue;}
console.error('Assertion failed');}
insertRecord(media,null);}}}
function endscan(media){if(media.scanning){media.scanning=false;dispatchEvent(media,'scanend');}}
function insertRecord(media,fileOrName){var details=media.details;details.pendingInsertions.push(fileOrName);if(details.processingQueue)
return;processQueue(media);}
function deleteRecord(media,filename){var details=media.details;details.pendingDeletions.push(filename);if(details.processingQueue)
return;processQueue(media);}
function whenDoneProcessing(media,f){var details=media.details;if(details.processingQueue)
details.whenDoneProcessing.push(f);else
f();}
function processQueue(media){var details=media.details;details.processingQueue=true;next();function next(){if(details.pendingDeletions.length>0){deleteFiles();}
else if(details.pendingInsertions.length>0){insertFile(details.pendingInsertions.shift());}
else{details.processingQueue=false;if(details.whenDoneProcessing.length>0){var functions=details.whenDoneProcessing;details.whenDoneProcessing=[];functions.forEach(function(f){f();});}}}
function deleteFiles(){var transaction=media.db.transaction('files','readwrite');var store=transaction.objectStore('files');deleteNextFile();function deleteNextFile(){if(details.pendingDeletions.length===0){next();return;}
var filename=details.pendingDeletions.shift();var request=store.delete(filename);request.onerror=function(){console.warn('MediaDB: Unknown file in deleteRecord:',filename,getreq.error);deleteNextFile();};request.onsuccess=function(){queueDeleteNotification(media,filename);deleteNextFile();};}}
function insertFile(f){if(f===null){sendNotifications(media);endscan(media);next();return;}
if(typeof f==='string'){var getreq=media.storage.get(f);getreq.onerror=function(){console.warn('MediaDB: Unknown file in insertRecord:',f,getreq.error);next();};getreq.onsuccess=function(){if(media.mimeTypes&&ignore(media,getreq.result))
next();else
parseMetadata(getreq.result,f);};}
else{parseMetadata(f,f.name);}}
function parseMetadata(file,filename){if(!file.lastModifiedDate){console.warn('MediaDB: parseMetadata: no lastModifiedDate for',filename,'using Date.now() until #793955 is fixed');}
var fileinfo={name:filename,type:file.type,size:file.size,date:file.lastModifiedDate?file.lastModifiedDate.getTime():Date.now()};if(fileinfo.date>details.newestFileModTime)
details.newestFileModTime=fileinfo.date;media.metadataParser(file,gotMetadata,metadataError);function metadataError(e){console.warn('MediaDB: error parsing metadata for',filename,':',e);fileinfo.fail=true;storeRecord(fileinfo);}
function gotMetadata(metadata){fileinfo.metadata=metadata;storeRecord(fileinfo);}}
function storeRecord(fileinfo){if(media.details.firstscan){media.details.records.push(fileinfo);if(!fileinfo.fail){queueCreateNotification(media,fileinfo);}
next();}
else{var transaction=media.db.transaction('files','readwrite');var store=transaction.objectStore('files');var request=store.add(fileinfo);request.onsuccess=function(){if(!fileinfo.fail)
queueCreateNotification(media,fileinfo);next();};request.onerror=function(event){if(request.error.name==='ConstraintError'){event.stopPropagation();event.preventDefault();var putrequest=store.put(fileinfo);putrequest.onsuccess=function(){queueDeleteNotification(media,fileinfo.name);if(!fileinfo.fail)
queueCreateNotification(media,fileinfo);next();};putrequest.onerror=function(){console.error('MediaDB: unexpected ConstraintError','in insertRecord for file:',fileinfo.name);next();};}
else{console.error('MediaDB: unexpected error in insertRecord:',request.error,'for file:',fileinfo.name);next();}};}}}
function queueCreateNotification(media,fileinfo){var creates=media.details.pendingCreateNotifications;creates.push(fileinfo);if(media.batchSize&&creates.length>=media.batchSize)
sendNotifications(media);else
resetNotificationTimer(media);}
function queueDeleteNotification(media,filename){var deletes=media.details.pendingDeleteNotifications;deletes.push(filename);if(media.batchSize&&deletes.length>=media.batchSize)
sendNotifications(media);else
resetNotificationTimer(media);}
function resetNotificationTimer(media){var details=media.details;if(details.pendingNotificationTimer)
clearTimeout(details.pendingNotificationTimer);details.pendingNotificationTimer=setTimeout(function(){sendNotifications(media);},media.batchHoldTime);}
function sendNotifications(media){var details=media.details;if(details.pendingNotificationTimer){clearTimeout(details.pendingNotificationTimer);details.pendingNotificationTimer=null;}
if(details.pendingDeleteNotifications.length>0){var deletions=details.pendingDeleteNotifications;details.pendingDeleteNotifications=[];dispatchEvent(media,'deleted',deletions);}
if(details.pendingCreateNotifications.length>0){if(details.firstscan&&details.records.length>0){var transaction=media.db.transaction('files','readwrite');var store=transaction.objectStore('files');for(var i=0;i<details.records.length;i++)
store.add(details.records[i]);details.records.length=0;}
var creations=details.pendingCreateNotifications;details.pendingCreateNotifications=[];dispatchEvent(media,'created',creations);}}
function dispatchEvent(media,type,detail){var handler=media['on'+type];var listeners=media.details.eventListeners[type];if(!handler&&(!listeners||listeners.length==0))
return;var event={type:type,target:media,currentTarget:media,timestamp:Date.now(),detail:detail};if(typeof handler==='function'){try{handler.call(media,event);}
catch(e){console.warn('MediaDB: ','on'+type,'event handler threw',e);}}
if(!listeners)
return;for(var i=0;i<listeners.length;i++){try{var listener=listeners[i];if(typeof listener==='function'){listener.call(media,event);}
else{listener.handleEvent(event);}}
catch(e){console.warn('MediaDB: ',type,'event listener threw',e);}}}
function changeState(media,state){if(media.state!==state){media.state=state;if(state===MediaDB.READY)
dispatchEvent(media,'ready');else
dispatchEvent(media,'unavailable',state);}}
return MediaDB;}());;'use strict';var LazyLoader=(function(){function LazyLoader(){this._loaded={};this._isLoading={};}
LazyLoader.prototype={_js:function(file,callback){var script=document.createElement('script');script.src=file;script.addEventListener('load',callback);document.head.appendChild(script);this._isLoading[file]=script;},_css:function(file,callback){var style=document.createElement('link');style.type='text/css';style.rel='stylesheet';style.href=file;document.head.appendChild(style);callback();},_html:function(domNode,callback){for(var i=0;i<domNode.childNodes.length;i++){if(domNode.childNodes[i].nodeType==document.COMMENT_NODE){domNode.innerHTML=domNode.childNodes[i].nodeValue;break;}}
callback();},load:function(files,callback){if(!Array.isArray(files))
files=[files];var loadsRemaining=files.length,self=this;function perFileCallback(file){if(self._isLoading[file])
delete self._isLoading[file];self._loaded[file]=true;if(--loadsRemaining===0){if(callback)
callback();}}
for(var i=0;i<files.length;i++){var file=files[i];if(this._loaded[file]){perFileCallback(file);}else if(this._isLoading[file]){this._isLoading[file].addEventListener('load',perFileCallback.bind(null,file));}else{var method,idx;if(typeof file==='string'){method=file.match(/\.(.*?)$/)[1];idx=file;}else{method='html';idx=file.id;}
this['_'+method](file,perFileCallback.bind(null,idx));}}}};return new LazyLoader();}());;'use strict';this.asyncStorage=(function(){var DBNAME='asyncStorage';var DBVERSION=1;var STORENAME='keyvaluepairs';var db=null;function withStore(type,f){if(db){f(db.transaction(STORENAME,type).objectStore(STORENAME));}else{var openreq=indexedDB.open(DBNAME,DBVERSION);openreq.onerror=function withStoreOnError(){console.error("asyncStorage: can't open database:",openreq.error.name);};openreq.onupgradeneeded=function withStoreOnUpgradeNeeded(){openreq.result.createObjectStore(STORENAME);};openreq.onsuccess=function withStoreOnSuccess(){db=openreq.result;f(db.transaction(STORENAME,type).objectStore(STORENAME));};}}
function getItem(key,callback){withStore('readonly',function getItemBody(store){var req=store.get(key);req.onsuccess=function getItemOnSuccess(){var value=req.result;if(value===undefined)
value=null;callback(value);};req.onerror=function getItemOnError(){console.error('Error in asyncStorage.getItem(): ',req.error.name);};});}
function setItem(key,value,callback){withStore('readwrite',function setItemBody(store){var req=store.put(value,key);if(callback){req.onsuccess=function setItemOnSuccess(){callback();};}
req.onerror=function setItemOnError(){console.error('Error in asyncStorage.setItem(): ',req.error.name);};});}
function removeItem(key,callback){withStore('readwrite',function removeItemBody(store){var req=store.delete(key);if(callback){req.onsuccess=function removeItemOnSuccess(){callback();};}
req.onerror=function removeItemOnError(){console.error('Error in asyncStorage.removeItem(): ',req.error.name);};});}
function clear(callback){withStore('readwrite',function clearBody(store){var req=store.clear();if(callback){req.onsuccess=function clearOnSuccess(){callback();};}
req.onerror=function clearOnError(){console.error('Error in asyncStorage.clear(): ',req.error.name);};});}
function length(callback){withStore('readonly',function lengthBody(store){var req=store.count();req.onsuccess=function lengthOnSuccess(){callback(req.result);};req.onerror=function lengthOnError(){console.error('Error in asyncStorage.length(): ',req.error.name);};});}
function key(n,callback){if(n<0){callback(null);return;}
withStore('readonly',function keyBody(store){var advanced=false;var req=store.openCursor();req.onsuccess=function keyOnSuccess(){var cursor=req.result;if(!cursor){callback(null);return;}
if(n===0){callback(cursor.key);}else{if(!advanced){advanced=true;cursor.advance(n);}else{callback(cursor.key);}}};req.onerror=function keyOnError(){console.error('Error in asyncStorage.key(): ',req.error.name);};});}
return{getItem:getItem,setItem:setItem,removeItem:removeItem,clear:clear,length:length,key:key};}());;'use strict';var Normalizer={initAsciiNormalizer:function normalizer_init(){var equivalentChars={'a':'áăǎâäȧạȁàảȃāąåḁⱥãǽǣæ','A':'ÁĂǍÂÄȦẠȀÀẢȂĀĄÅḀȺÃǼǢÆ','b':'ḃḅɓḇƀƃ','B':'ḂḄƁḆɃƂ','c':'ćčçĉċƈȼ','C':'ĆČÇĈĊƇȻ','d':'ďḑḓḋḍɗḏđƌð','D':'ĎḐḒḊḌƊḎĐƋ','e':'éĕěȩêḙëėẹȅèẻȇēę','E':'ÉĔĚȨÊḘËĖẸȄÈẺȆĒĘ','f':'ḟƒ','F':'ḞƑ','g':'ǵğǧģĝġɠḡǥ','G':'ǴĞǦĢĜĠƓḠǤ','h':'ḫȟḩĥⱨḧḣḥħ','H':'ḪȞḨĤⱧḦḢḤĦ','i':'íĭǐîïịȉìỉȋīįɨĩḭı','I':'ÍĬǏÎÏỊȈÌỈȊĪĮƗĨḬ','j':'ĵɉ','J':'ĴɈ','k':'ḱǩķⱪꝃḳƙḵꝁ','K':'ḰǨĶⱩꝂḲƘḴꝀ','l':'ĺƚľļḽḷⱡꝉḻŀɫł','L':'ĹȽĽĻḼḶⱠꝈḺĿⱢŁ','m':'ḿṁṃɱ','M':'ḾṀṂⱮ','n':'ńňņṋṅṇǹɲṉƞñ','N':'ŃŇŅṊṄṆǸƝṈȠÑ','o':'óŏǒôöȯọőȍòỏơȏꝋꝍōǫøõœ','O':'ÓŎǑÔÖȮỌŐȌÒỎƠȎꝊꝌŌǪØÕŒ','p':'ṕṗꝓƥᵽꝑ','P':'ṔṖꝒƤⱣꝐ','q':'ꝗ','Q':'Ꝗ','r':'ŕřŗṙṛȑȓṟɍɽ','R':'ŔŘŖṘṚȐȒṞɌⱤ','s':'śšşŝșṡṣß$','S':'ŚŠŞŜȘṠṢ','t':'ťţṱțⱦṫṭƭṯʈŧ','T':'ŤŢṰȚȾṪṬƬṮƮŦ','u':'úŭǔûṷüṳụűȕùủưȗūųůũṵ','U':'ÚŬǓÛṶÜṲỤŰȔÙỦƯȖŪŲŮŨṴ','v':'ṿʋṽ','V':'ṾƲṼ','w':'ẃŵẅẇẉẁⱳ','W':'ẂŴẄẆẈẀⱲ','x':'ẍẋ','X':'ẌẊ','y':'ýŷÿẏỵỳƴỷỿȳɏỹ','Y':'ÝŶŸẎỴỲƳỶỾȲɎỸ','z':'źžẑⱬżẓȥẕƶ','Z':'ŹŽẐⱫŻẒȤẔƵ'};this._toAsciiForm={};for(var letter in equivalentChars){var accentedForms=equivalentChars[letter];for(var i=accentedForms.length-1;i>=0;i--)
this._toAsciiForm[accentedForms[i]]=letter;}},toAscii:function normalizer_toAscii(str){if(!str||typeof str!='string')
return'';if(!this._toAsciiForm)
Normalizer.initAsciiNormalizer();var result='';for(var i=0,len=str.length;i<len;i++)
result+=this._toAsciiForm[str.charAt(i)]||str.charAt(i);return result;},escapeHTML:function normalizer_escapeHTML(str,escapeQuotes){if(Array.isArray(str)){return Normalizer.escapeHTML(str.join(' '),escapeQuotes);}
if(!str||typeof str!='string')
return'';var escaped=str.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');if(escapeQuotes)
return escaped.replace(/"/g,'&quot;').replace(/'/g,'&#x27;');return escaped;},escapeRegExp:function normalizer_escapeRegExp(str){return str.replace(/[\-\[\]\/\{\}\(\)\*\+\?\.\\\^\$\|]/g,'\\$&');}};;'use strict';function escapeHTML(str,escapeQuotes){var span=document.createElement('span');span.textContent=str;if(escapeQuotes)
return span.innerHTML.replace(/"/g,'&quot;').replace(/'/g,'&#x27;');return span.innerHTML;}
function formatTime(secs){if(isNaN(secs))
return;secs=Math.floor(secs);var formatedTime;var seconds=secs%60;var minutes=Math.floor(secs/60)%60;var hours=Math.floor(secs/3600);if(hours===0){formatedTime=(minutes<10?'0'+minutes:minutes)+':'+
(seconds<10?'0'+seconds:seconds);}else{formatedTime=(hours<10?'0'+hours:hours)+':'+
(minutes<10?'0'+minutes:minutes)+':'+
(seconds<10?'0'+seconds:seconds);}
return formatedTime;}
function cropImage(evt){var image=evt.target;var style=image.style;var parentWidth=image.parentElement.clientWidth;var parentHeight=image.parentElement.clientHeight;var childRatio=image.naturalWidth/image.naturalHeight;var parentRatio=parentWidth/parentHeight;if(childRatio>parentRatio){style.width='auto';style.height=parentHeight+'px';style.left=-(parentHeight*childRatio-parentWidth)/2+'px';}else{style.width=parentWidth+'px';style.height='auto';style.top=-(parentWidth/childRatio-parentHeight)/2+'px';}}
function displayAlbumArt(img,fileinfo){getThumbnailURL(fileinfo,function(url){if(!url)
return;img.src=url;img.addEventListener('load',function revoke(event){img.removeEventListener('load',revoke);cropImage(event);});});};'use strict';var musicTitle;var playlistTitle;var artistTitle;var albumTitle;var songTitle;var pickerTitle;var unknownAlbum;var unknownArtist;var unknownTitle;var shuffleAllTitle;var highestRatedTitle;var recentlyAddedTitle;var mostPlayedTitle;var leastPlayedTitle;var unknownTitleL10nId='unknownTitle';var unknownArtistL10nId='unknownArtist';var unknownAlbumL10nId='unknownAlbum';var shuffleAllTitleL10nId='playlists-shuffle-all';var highestRatedTitleL10nId='playlists-highest-rated';var recentlyAddedTitleL10nId='playlists-recently-added';var mostPlayedTitleL10nId='playlists-most-played';var leastPlayedTitleL10nId='playlists-least-played';var musicdb;var pendingPick;window.addEventListener('localized',function onlocalized(){document.documentElement.lang=navigator.mozL10n.language.code;document.documentElement.dir=navigator.mozL10n.language.direction;musicTitle=navigator.mozL10n.get('music');playlistTitle=navigator.mozL10n.get('playlists');artistTitle=navigator.mozL10n.get('artists');albumTitle=navigator.mozL10n.get('albums');songTitle=navigator.mozL10n.get('songs');pickerTitle=navigator.mozL10n.get('picker-title');unknownAlbum=navigator.mozL10n.get(unknownAlbumL10nId);unknownArtist=navigator.mozL10n.get(unknownArtistL10nId);unknownTitle=navigator.mozL10n.get(unknownTitleL10nId);shuffleAllTitle=navigator.mozL10n.get(shuffleAllTitleL10nId);highestRatedTitle=navigator.mozL10n.get(highestRatedTitleL10nId);recentlyAddedTitle=navigator.mozL10n.get(recentlyAddedTitleL10nId);mostPlayedTitle=navigator.mozL10n.get(mostPlayedTitleL10nId);leastPlayedTitle=navigator.mozL10n.get(leastPlayedTitleL10nId);if(!musicdb){init();TitleBar.init();TilesView.init();ListView.init();SubListView.init();SearchView.init();TabBar.init();if(document.URL.indexOf('#pick')!==-1){navigator.mozSetMessageHandler('activity',function activityHandler(a){var activityName=a.source.name;if(activityName==='pick'){pendingPick=a;}});TabBar.option='title';ModeManager.start(MODE_PICKER);}else{TabBar.option='mix';ModeManager.start(MODE_TILES);var doneButton=document.getElementById('title-done');doneButton.parentNode.removeChild(doneButton);}}else{ModeManager.updateTitle();}
TabBar.playlistArray.localize();});var displayingScanProgress=false;function init(){musicdb=new MediaDB('music',metadataParserWrapper,{indexes:['metadata.album','metadata.artist','metadata.title','metadata.rated','metadata.played','date'],batchSize:1,autoscan:false,version:2});function metadataParserWrapper(file,onsuccess,onerror){LazyLoader.load('js/metadata_scripts.js',function(){parseAudioMetadata(file,onsuccess,onerror);});}
musicdb.onunavailable=function(event){stopPlayingAndReset();var why=event.detail;if(why===MediaDB.NOCARD)
showOverlay('nocard');else if(why===MediaDB.UNMOUNTED)
showOverlay('pluggedin');};musicdb.oncardremoved=stopPlayingAndReset;function stopPlayingAndReset(){if(typeof PlayerView!=='undefined'){PlayerView.stop();PlayerView.clean();}
ModeManager.start(MODE_TILES);ModeManager.playerTitle=null;ModeManager.updateTitle();TilesView.hideSearch();};musicdb.onready=function(){if(currentOverlay==='nocard'||currentOverlay==='pluggedin')
showOverlay(null);showCurrentView(function(){document.getElementById('spinner-overlay').classList.add('hidden');});musicdb.scan();};var filesDeletedWhileScanning=0;var filesFoundWhileScanning=0;var filesFoundBatch=0;var scanning=false;var SCAN_UPDATE_BATCH_SIZE=25;var DELETE_BATCH_TIMEOUT=500;var deleteTimer=null;var scanProgress=document.getElementById('scan-progress');var scanCount=document.getElementById('scan-count');var scanArtist=document.getElementById('scan-artist');var scanTitle=document.getElementById('scan-title');musicdb.onscanstart=function(){scanning=true;displayingScanProgress=false;filesFoundWhileScanning=0;filesFoundBatch=0;filesDeletedWhileScanning=0;};musicdb.onscanend=function(){scanning=false;if(displayingScanProgress){scanProgress.classList.add('hidden');displayingScanProgress=false;}
if(filesFoundBatch>0||filesDeletedWhileScanning>0){filesFoundWhileScanning=0;filesFoundBatch=0;filesDeletedWhileScanning=0;showCurrentView();}};musicdb.oncreated=function(event){if(scanning){var currentMode=ModeManager.currentMode;if(!displayingScanProgress&&(currentMode===MODE_TILES||currentMode===MODE_LIST||currentMode===MODE_PICKER))
{displayingScanProgress=true;scanProgress.classList.remove('hidden');}
var n=event.detail.length;filesFoundWhileScanning+=n;filesFoundBatch+=n;scanCount.textContent=filesFoundWhileScanning;var metadata=event.detail[0].metadata;scanArtist.textContent=metadata.artist||'';scanTitle.textContent=metadata.title||'';if(filesFoundBatch>SCAN_UPDATE_BATCH_SIZE){filesFoundBatch=0;showCurrentView();}}
else{showCurrentView();}};musicdb.ondeleted=function(event){if(scanning){filesDeletedWhileScanning+=event.detail.length;}
else{if(deleteTimer)
clearTimeout(deleteTimer);deleteTimer=setTimeout(function(){deleteTimer=null;showCurrentView();},DELETE_BATCH_TIMEOUT);}};}
function shareFile(filename){musicdb.getFile(filename,function(file){var name=filename.substring(filename.lastIndexOf('/')+1);var a=new MozActivity({name:'share',data:{type:file.type,number:1,blobs:[file],filenames:[name],filepaths:[filename]}});a.onerror=function(e){console.warn('share activity error:',a.error.name);};});}
var currentOverlay;function showOverlay(id){currentOverlay=id;if(id===null){document.getElementById('overlay').classList.add('hidden');return;}
var title=navigator.mozL10n.get(id+'-title');var text=navigator.mozL10n.get(id+'-text');var titleElement=document.getElementById('overlay-title');var textElement=document.getElementById('overlay-text');titleElement.textContent=title;titleElement.dataset.l10nId=id+'-title';textElement.textContent=text;textElement.dataset.l10nId=id+'-text';document.getElementById('overlay').classList.remove('hidden');}
var knownSongs=[];function showCorrectOverlay(){if(knownSongs.length>0){if(currentOverlay==='empty')
showOverlay(null);}else{showOverlay('empty');}}
var tilesHandle=null;var listHandle=null;var sublistHandle=null;var playerHandle=null;function showCurrentView(callback){LazyLoader.load('js/metadata_scripts.js',function(){if(pendingPick){ListView.clean();knownSongs.length=0;listHandle=musicdb.enumerate('metadata.'+TabBar.option,null,'nextunique',function(song){ListView.update(TabBar.option,song);knownSongs.push(song);});if(callback)
callback();return;}
if(ModeManager.currentMode===MODE_LIST&&TabBar.option!=='playlist')
{ListView.clean();listHandle=musicdb.enumerate('metadata.'+TabBar.option,null,'nextunique',function(song){ListView.update(TabBar.option,song);});}
tilesHandle=musicdb.enumerateAll('metadata.album',null,'nextunique',function(songs){songs.push(null);TilesView.clean();knownSongs.length=0;songs.forEach(function(song){TilesView.update(song);knownSongs.push(song);});if(callback)
callback();});});}
var MODE_TILES=1;var MODE_LIST=2;var MODE_SUBLIST=3;var MODE_PLAYER=4;var MODE_SEARCH_FROM_TILES=5;var MODE_SEARCH_FROM_LIST=6;var MODE_PICKER=7;var ModeManager={_modeStack:[],playerTitle:null,get currentMode(){return this._modeStack[this._modeStack.length-1];},start:function(mode,callback){this._modeStack=[mode];this._updateMode(callback);},push:function(mode,callback){this._modeStack.push(mode);this._updateMode(callback);},pop:function(){if(this._modeStack.length<=1)
return;this._modeStack.pop();this._updateMode();},updateTitle:function(){var title;switch(this.currentMode){case MODE_TILES:title=this.playerTitle||musicTitle;break;case MODE_LIST:case MODE_SUBLIST:switch(TabBar.option){case'playlist':title=playlistTitle;break;case'artist':title=artistTitle;break;case'album':title=albumTitle;break;case'title':title=songTitle;break;}
break;case MODE_PLAYER:title=this.playerTitle||unknownTitle;break;case MODE_PICKER:title=pickerTitle;break;}
if(title)
TitleBar.changeTitleText(title);},_updateMode:function(callback){var mode=this.currentMode;var playerLoaded=(typeof PlayerView!='undefined');this.updateTitle();if(mode===MODE_PLAYER){document.getElementById('views-player').classList.remove('hidden');LazyLoader.load('js/Player.js',function(){if(!playerLoaded)
PlayerView.init(true);if(callback)
callback();});}else{if(mode===MODE_LIST||mode===MODE_PICKER)
document.getElementById('views-list').classList.remove('hidden');else if(mode===MODE_SUBLIST)
document.getElementById('views-sublist').classList.remove('hidden');else if(mode===MODE_SEARCH_FROM_TILES||mode===MODE_SEARCH_FROM_LIST)
document.getElementById('search').classList.remove('hidden');if(callback)
callback();}
if(pendingPick)
document.getElementById('title-done').hidden=(mode!==MODE_PLAYER);var modeClasses=['tiles-mode','list-mode','sublist-mode','player-mode','search-from-tiles-mode','search-from-list-mode','picker-mode'];modeClasses.forEach(function resetMode(targetClass){document.body.classList.remove(targetClass);});document.body.classList.add(modeClasses[mode-1]);if(displayingScanProgress&&(mode===MODE_SUBLIST||mode===MODE_PLAYER)){document.getElementById('scan-progress').classList.add('hidden');displayingScanProgress=false;}}};var TitleBar={get view(){delete this._view;return this._view=document.getElementById('title');},get titleText(){delete this._titleText;return this._titleText=document.getElementById('title-text');},get playerIcon(){delete this._playerIcon;return this._playerIcon=document.getElementById('title-player');},init:function tb_init(){this.view.addEventListener('click',this);},changeTitleText:function tb_changeTitleText(content){this.titleText.textContent=content;},handleEvent:function tb_handleEvent(evt){var target=evt.target;function cleanupPick(){PlayerView.stop();PlayerView.clean();ModeManager.playerTitle=null;}
switch(evt.type){case'click':if(!target)
return;switch(target.id){case'title-back':if(pendingPick){if(ModeManager.currentMode===MODE_PICKER){pendingPick.postError('pick cancelled');return;}
cleanupPick();}
ModeManager.pop();break;case'title-player':if(PlayerView.dataSource.length!=0)
ModeManager.push(MODE_PLAYER);break;case'title-done':pendingPick.postResult({type:PlayerView.playingBlob.type,blob:PlayerView.playingBlob});cleanupPick();break;}
break;default:return;}}};var TilesView={get view(){delete this._view;return this._view=document.getElementById('views-tiles');},get anchor(){delete this._anchor;return this._anchor=document.getElementById('views-tiles-anchor');},get searchBox(){delete this._searchBox;return this._searchBox=document.getElementById('views-tiles-search');},get searchInput(){delete this._searchInput;return this._searchInput=document.getElementById('views-tiles-search-input');},get dataSource(){return this._dataSource;},set dataSource(source){this._dataSource=source;},init:function tv_init(){this.dataSource=[];this.index=0;this.view.addEventListener('click',this);this.view.addEventListener('input',this);this.searchInput.addEventListener('focus',this);},clean:function tv_clean(){if(tilesHandle)
musicdb.cancelEnumeration(tilesHandle);this.dataSource=[];this.index=0;this.anchor.innerHTML='';this.view.scrollTop=0;this.hideSearch();},hideSearch:function tv_hideSearch(){this.searchInput.value='';if(this.view.scrollTop<this.searchBox.offsetHeight)
this.view.scrollTop=this.searchBox.offsetHeight;},update:function tv_update(result){TabBar.setDisabled(!this.dataSource.length);if(result===null){showCorrectOverlay();document.getElementById('views-tiles').classList.remove('hidden');window.setTimeout(this.hideSearch.bind(this),1000);return;}
this.dataSource.push(result);var tile=document.createElement('div');tile.className='tile';var container=document.createElement('div');container.className='tile-container';var titleBar=document.createElement('div');titleBar.className='tile-title-bar';var artistName=document.createElement('div');artistName.className='tile-title-artist';var albumName=document.createElement('div');albumName.className='tile-title-album';artistName.textContent=result.metadata.artist||unknownArtist;artistName.dataset.l10nId=result.metadata.artist?'':unknownArtistL10nId;albumName.textContent=result.metadata.album||unknownAlbum;albumName.dataset.l10nId=result.metadata.album?'':unknownAlbumL10nId;titleBar.appendChild(artistName);if(this.index%6===0){tile.classList.add('main-tile');artistName.classList.add('main-tile-title');titleBar.appendChild(albumName);}else{tile.classList.add('sub-tile');artistName.classList.add('sub-tile-title');}
if(Math.floor(this.index/6)%2===0){tile.classList.add('float-left');}else{tile.classList.add('float-right');}
var NUM_INITIALLY_VISIBLE_TILES=8;var INITIALLY_HIDDEN_TILE_WAIT_TIME_MS=1000;var placeholderBackgroundClass='default-album-'+this.index%10;var setTileBackgroundClosure=function(url){if(url){tile.style.backgroundImage='url('+url+')';}else{tile.classList.add(placeholderBackgroundClass);}};if(this.index<=NUM_INITIALLY_VISIBLE_TILES){getThumbnailURL(result,setTileBackgroundClosure);}else{setTimeout(function(){getThumbnailURL(result,setTileBackgroundClosure);},INITIALLY_HIDDEN_TILE_WAIT_TIME_MS);}
container.dataset.index=this.index;if(!result.metadata.picture)
container.appendChild(titleBar);tile.appendChild(container);this.anchor.appendChild(tile);this.index++;},handleEvent:function tv_handleEvent(evt){var target=evt.target;switch(evt.type){case'click':if(!target)
return;if(target.id==='views-tiles-search-clear'){SearchView.clearSearch();return;}
if(target.id==='views-tiles-search-close'){if(ModeManager.currentMode===MODE_SEARCH_FROM_TILES){ModeManager.pop();}
this.hideSearch();evt.preventDefault();}else if(target.dataset.index){var handler;var index=target.dataset.index;var data=this.dataSource[index];handler=tv_playAlbum.bind(this,data,index);target.addEventListener('transitionend',handler);}
break;case'focus':if(target.id==='views-tiles-search-input'){if(ModeManager.currentMode!==MODE_SEARCH_FROM_TILES){ModeManager.push(MODE_SEARCH_FROM_TILES);SearchView.search(target.value);}}
break;case'input':if(target.id==='views-tiles-search-input'){SearchView.search(target.value);}
break;default:return;}
function tv_playAlbum(data,index){var backgroundIndex=index%10;var key='metadata.album';var range=IDBKeyRange.only(data.metadata.album);var direction='next';ModeManager.push(MODE_PLAYER,function(){PlayerView.clean();playerHandle=musicdb.enumerateAll(key,range,direction,function tv_enumerateAll(dataArray){PlayerView.setSourceType(TYPE_LIST);PlayerView.dataSource=dataArray;if(PlayerView.shuffleOption){PlayerView.setShuffle(true);PlayerView.play(PlayerView.shuffledList[0],backgroundIndex);}else{PlayerView.play(0,backgroundIndex);}});});target.removeEventListener('transitionend',handler);}}};function createListElement(option,data,index,highlight){var li=document.createElement('li');li.className='list-item';var a=document.createElement('a');a.href='#';a.dataset.index=index;a.dataset.option=option;li.appendChild(a);function highlightText(result,text){var textContent=result.textContent;var textLowerCased=textContent.toLocaleLowerCase();var index=Normalizer.toAscii(textLowerCased).indexOf(text);if(index>=0){var innerHTML=textContent.substring(0,index)+'<span class="search-highlight">'+
textContent.substring(index,index+text.length)+'</span>'+
textContent.substring(index+text.length);result.innerHTML=innerHTML;}}
switch(option){case'playlist':var titleSpan=document.createElement('span');titleSpan.className='list-playlist-title';if(data.metadata.l10nId){titleSpan.textContent=data.metadata.title;titleSpan.dataset.l10nId=data.metadata.l10nId;}else{titleSpan.textContent=data.metadata.title||unknownTitle;titleSpan.dataset.l10nId=data.metadata.title?'':unknownTitleL10nId;}
a.dataset.keyRange='all';a.dataset.option=data.option;li.appendChild(titleSpan);if(index===0){var shuffleIcon=document.createElement('div');shuffleIcon.className='list-playlist-icon';li.appendChild(shuffleIcon);}
break;case'artist':case'album':case'title':var parent=document.createElement('div');parent.className='list-image-parent';parent.classList.add('default-album-'+index%10);var img=document.createElement('img');img.className='list-image';if(data.metadata.picture){parent.appendChild(img);displayAlbumArt(img,data);}
if(option==='artist'){var artistSpan=document.createElement('span');artistSpan.className='list-single-title';artistSpan.textContent=data.metadata.artist||unknownArtist;artistSpan.dataset.l10nId=data.metadata.artist?'':unknownArtistL10nId;if(highlight)
highlightText(artistSpan,highlight);li.appendChild(artistSpan);}else{var albumOrTitleSpan=document.createElement('span');var artistSpan=document.createElement('span');albumOrTitleSpan.className='list-main-title';artistSpan.className='list-sub-title';if(option==='album'){albumOrTitleSpan.textContent=data.metadata.album||unknownAlbum;albumOrTitleSpan.dataset.l10nId=data.metadata.album?'':unknownAlbumL10nId;}else{albumOrTitleSpan.textContent=data.metadata.title||unknownTitle;albumOrTitleSpan.dataset.l10nId=data.metadata.title?'':unknownTitleL10nId;}
artistSpan.textContent=data.metadata.artist||unknownArtist;artistSpan.dataset.l10nId=data.metadata.artist?'':unknownArtistL10nId;if(highlight)
highlightText(albumOrTitleSpan,highlight);li.appendChild(albumOrTitleSpan);li.appendChild(artistSpan);}
li.appendChild(parent);a.dataset.keyRange=data.metadata[option];a.dataset.option=option;break;case'song':var songTitle=data.metadata.title||unknownTitle;var indexSpan=document.createElement('span');indexSpan.className='list-song-index';indexSpan.textContent=index+1;var titleSpan=document.createElement('span');titleSpan.className='list-song-title';titleSpan.textContent=songTitle;titleSpan.dataset.l10nId=data.metadata.title?'':unknownTitleL10nId;var lengthSpan=document.createElement('span');lengthSpan.className='list-song-length';li.appendChild(indexSpan);li.appendChild(titleSpan);li.appendChild(lengthSpan);break;}
return li;}
var ListView={get view(){delete this._view;return this._view=document.getElementById('views-list');},get anchor(){delete this._anchor;return this._anchor=document.getElementById('views-list-anchor');},get searchBox(){delete this._searchBox;return this._searchBox=document.getElementById('views-list-search');},get searchInput(){delete this._searchInput;return this._searchInput=document.getElementById('views-list-search-input');},get dataSource(){return this._dataSource;},set dataSource(source){this._dataSource=source;},init:function lv_init(){this.dataSource=[];this.index=0;this.lastFirstLetter=null;this.view.addEventListener('click',this);this.view.addEventListener('input',this);this.searchInput.addEventListener('focus',this);},clean:function lv_clean(){if(listHandle)
musicdb.cancelEnumeration(listHandle);this.dataSource=[];this.index=0;this.lastFirstLetter=null;this.anchor.innerHTML='';this.view.scrollTop=0;this.hideSearch();},hideSearch:function lv_hideSearch(){this.searchInput.value='';if(this.view.scrollTop<this.searchBox.offsetHeight)
this.view.scrollTop=this.searchBox.offsetHeight;},update:function lv_update(option,result){if(result===null){showCorrectOverlay();return;}
this.dataSource.push(result);if(option!=='playlist'){var firstLetter=result.metadata[option].charAt(0);if(this.lastFirstLetter!=firstLetter){this.lastFirstLetter=firstLetter;var headerLi=document.createElement('li');headerLi.className='list-header';headerLi.textContent=this.lastFirstLetter||'?';this.anchor.appendChild(headerLi);}}
this.anchor.appendChild(createListElement(option,result,this.index));this.index++;},handleEvent:function lv_handleEvent(evt){var target=evt.target;switch(evt.type){case'click':if(!target)
return;if(target.id==='views-list-search-clear'){SearchView.clearSearch();return;}
if(target.id==='views-list-search-close'){if(ModeManager.currentMode===MODE_SEARCH_FROM_LIST){ModeManager.pop();}
this.hideSearch();evt.preventDefault();}else{var option=target.dataset.option;if(option==='shuffleAll'){musicdb.getAll(function lv_getAll(dataArray){ModeManager.push(MODE_PLAYER,function(){PlayerView.setSourceType(TYPE_MIX);PlayerView.dataSource=dataArray;PlayerView.setShuffle(true);PlayerView.play(PlayerView.shuffledList[0]);});});}else if(option==='title'){ModeManager.push(MODE_PLAYER,function(){var targetIndex=parseInt(target.dataset.index);PlayerView.setSourceType(TYPE_MIX);PlayerView.dataSource=this.dataSource;PlayerView.play(targetIndex);}.bind(this));}else if(option){var index=target.dataset.index;var data=this.dataSource[index];var keyRange=(target.dataset.keyRange!='all')?IDBKeyRange.only(target.dataset.keyRange):null;var direction=(data.metadata.title===mostPlayedTitle||data.metadata.title===recentlyAddedTitle||data.metadata.title===highestRatedTitle)?'prev':'next';SubListView.activate(option,data,index,keyRange,direction,function(){ModeManager.push(MODE_SUBLIST);});}}
break;case'focus':if(target.id==='views-list-search-input'){if(ModeManager.currentMode!==MODE_SEARCH_FROM_LIST){ModeManager.push(MODE_SEARCH_FROM_LIST);SearchView.search(target.value);}}
break;case'input':if(target.id==='views-list-search-input'){SearchView.search(target.value);}
break;default:return;}}};var SubListView={get view(){delete this._view;return this._view=document.getElementById('views-sublist');},get dataSource(){return this._dataSource;},get anchor(){delete this._anchor;return this._anchor=document.getElementById('views-sublist-anchor');},set dataSource(source){this._dataSource=source;this.shuffleButton.disabled=(this._dataSource.length<2);},init:function slv_init(){this.albumDefault=document.getElementById('views-sublist-header-default');this.albumImage=document.getElementById('views-sublist-header-image');this.albumName=document.getElementById('views-sublist-header-name');this.playAllButton=document.getElementById('views-sublist-controls-play');this.shuffleButton=document.getElementById('views-sublist-controls-shuffle');this.dataSource=[];this.index=0;this.backgroundIndex=0;this.isContextmenu=false;this.view.addEventListener('click',this);this.view.addEventListener('contextmenu',this);},clean:function slv_clean(){if(sublistHandle)
musicdb.cancelEnumeration(sublistHandle);this.dataSource=[];this.index=0;this.albumImage.src='';this.anchor.innerHTML='';this.view.scrollTop=0;},setAlbumDefault:function slv_setAlbumDefault(index){var realIndex=index%10;this.albumDefault.classList.remove('default-album-'+this.backgroundIndex);this.albumDefault.classList.add('default-album-'+realIndex);this.backgroundIndex=realIndex;},setAlbumSrc:function slv_setAlbumSrc(fileinfo){displayAlbumArt(this.albumImage,fileinfo);this.albumImage.classList.remove('fadeIn');this.albumImage.addEventListener('load',slv_showImage.bind(this));function slv_showImage(evt){evt.target.removeEventListener('load',slv_showImage);this.albumImage.classList.add('fadeIn');};},setAlbumName:function slv_setAlbumName(name,l10nId){this.albumName.textContent=name;this.albumName.dataset.l10nId=l10nId;},activate:function(option,data,index,keyRange,direction,callback){var targetOption=(option==='date')?option:'metadata.'+option;SubListView.clean();sublistHandle=musicdb.enumerateAll(targetOption,keyRange,direction,function lv_enumerateAll(dataArray){var albumName;var albumNameL10nId;if(option==='artist'){albumName=data.metadata.artist||unknownArtist;albumNameL10nId=data.metadata.artist?'':unknownArtistL10nId;}else if(option==='album'){albumName=data.metadata.album||unknownAlbum;albumNameL10nId=data.metadata.album?'':unknownAlbumL10nId;}else{albumName=data.metadata.title||unknownTitle;albumNameL10nId=data.metadata.title?'':unknownTitleL10nId;}
if(data.metadata.l10nId)
albumNameL10nId=data.metadata.l10nId;SubListView.setAlbumName(albumName,albumNameL10nId);SubListView.setAlbumDefault(index);SubListView.dataSource=dataArray;if(data.metadata.picture)
SubListView.setAlbumSrc(data);dataArray.forEach(function(songData){SubListView.update(songData);});if(callback)
callback();});},update:function slv_update(result){if(result===null)
return;this.anchor.appendChild(createListElement('song',result,this.index));this.index++;},handleEvent:function slv_handleEvent(evt){var target=evt.target;if(!target)
return;switch(evt.type){case'click':if(this.isContextmenu){this.isContextmenu=false;return;}
if(target===this.shuffleButton){ModeManager.push(MODE_PLAYER,function(){PlayerView.setSourceType(TYPE_LIST);PlayerView.dataSource=this.dataSource;PlayerView.setShuffle(true);PlayerView.play(PlayerView.shuffledList[0],this.backgroundIndex);}.bind(this));return;}
if(target.dataset.index||target===this.playAllButton){ModeManager.push(MODE_PLAYER,function(){PlayerView.setSourceType(TYPE_LIST);PlayerView.dataSource=this.dataSource;if(target===this.playAllButton){target=this.view.querySelector('li > a[data-index="0"]');PlayerView.setShuffle(false);}
var targetIndex=parseInt(target.dataset.index);if(PlayerView.shuffleOption){PlayerView.shuffleList(targetIndex);PlayerView.play(PlayerView.shuffledList[0],this.backgroundIndex);}else{PlayerView.play(targetIndex,this.backgroundIndex);}}.bind(this));}
break;case'contextmenu':this.isContextmenu=true;var targetIndex=parseInt(target.dataset.index);var songData=this.dataSource[targetIndex];shareFile(songData.name);break;default:return;}}};var SearchView={get view(){delete this._view;return this._view=document.getElementById('search');},get searchArtistsView(){delete this._searchArtists;return this._searchArtists=document.getElementById('views-search-artists');},get searchAlbumsView(){delete this._searchAlbums;return this._searchAlbums=document.getElementById('views-search-albums');},get searchTitlesView(){delete this._searchTitles;return this._searchTitles=document.getElementById('views-search-titles');},init:function sv_init(){this.dataSource=[];this.searchHandles={artist:null,album:null,title:null};this.view.addEventListener('click',this);},search:function sv_search(query){this.clearSearch();if(!query)
return;var queryLowerCased=query.toLocaleLowerCase();query=Normalizer.toAscii(queryLowerCased);var lists={artist:this.searchArtistsView,album:this.searchAlbumsView,title:this.searchTitlesView};var numResults={artist:0,album:0,title:0};function sv_showResult(option,result){if(result===null){this.searchHandles[option]=null;return;}
var resultLowerCased=result.metadata[option].toLocaleLowerCase();if(Normalizer.toAscii(resultLowerCased).indexOf(query)!==-1){this.dataSource.push(result);numResults[option]++;lists[option].classList.remove('hidden');lists[option].getElementsByClassName('search-result-count')[0].textContent=numResults[option];lists[option].getElementsByClassName('search-results')[0].appendChild(createListElement(option,result,this.dataSource.length-1,query));}}
if(!pendingPick){this.searchHandles.artist=musicdb.enumerate('metadata.artist',null,'nextunique',sv_showResult.bind(this,'artist'));this.searchHandles.album=musicdb.enumerate('metadata.album',null,'nextunique',sv_showResult.bind(this,'album'));}
this.searchHandles.title=musicdb.enumerate('metadata.title',sv_showResult.bind(this,'title'));},clearSearch:function sv_clearSearch(){for(var option in this.searchHandles){var handle=this.searchHandles[option];if(handle)
musicdb.cancelEnumeration(handle);}
var views=[this.searchArtistsView,this.searchAlbumsView,this.searchTitlesView];views.forEach(function(view){view.getElementsByClassName('search-results')[0].innerHTML='';view.classList.add('hidden');});this.dataSource=[];},handleEvent:function sv_handleEvent(evt){var target=evt.target;switch(evt.type){case'click':if(!target)
return;if(target.dataset.index){var handler;var index=target.dataset.index;var option=target.dataset.option;var keyRange=target.dataset.keyRange;var data=this.dataSource[index];handler=sv_openResult.bind(this,option,data,index,keyRange);target.addEventListener('transitionend',handler);}
break;default:return;}
function sv_openResult(option,data,index,keyRange){if(option==='title'){ModeManager.push(MODE_PLAYER,function(){PlayerView.setSourceType(TYPE_LIST);PlayerView.dataSource=[data];PlayerView.play(0,index%10);});}else{SubListView.activate(option,data,index,keyRange,'next',function(){ModeManager.push(MODE_SUBLIST);});}
target.removeEventListener('transitionend',handler);}}};var TabBar={playlistArray:[{metadata:{title:shuffleAllTitle,l10nId:shuffleAllTitleL10nId},option:'shuffleAll'},{metadata:{title:highestRatedTitle,l10nId:highestRatedTitleL10nId},option:'rated'},{metadata:{title:recentlyAddedTitle,l10nId:recentlyAddedTitleL10nId},option:'date'},{metadata:{title:mostPlayedTitle,l10nId:mostPlayedTitleL10nId},option:'played'},{metadata:{title:leastPlayedTitle,l10nId:leastPlayedTitleL10nId},option:'played'},null],get view(){delete this._view;return this._view=document.getElementById('tabs');},init:function tab_init(){this.option='';this.view.addEventListener('click',this);this.playlistArray.localize=function(){this.forEach(function(playList){if(playList){var metadata=playList.metadata;if(metadata&&metadata.l10nId){metadata.title=navigator.mozL10n.get(metadata.l10nId);}}});};},setDisabled:function tab_setDisabled(option){this.disabled=option;},handleEvent:function tab_handleEvent(evt){if(this.disabled)
return;switch(evt.type){case'click':var target=evt.target;if(!target)
return;if(this.option===target.dataset.option){return;}else{this.option=target.dataset.option;}
switch(target.id){case'tabs-mix':ModeManager.start(MODE_TILES);TilesView.hideSearch();break;case'tabs-playlists':ModeManager.start(MODE_LIST);ListView.clean();this.playlistArray.forEach(function(playlist){ListView.update(this.option,playlist);}.bind(this));break;case'tabs-artists':case'tabs-albums':case'tabs-songs':ModeManager.start(MODE_LIST);ListView.clean();listHandle=musicdb.enumerate('metadata.'+this.option,null,'nextunique',ListView.update.bind(ListView,this.option));break;}
break;default:return;}}};